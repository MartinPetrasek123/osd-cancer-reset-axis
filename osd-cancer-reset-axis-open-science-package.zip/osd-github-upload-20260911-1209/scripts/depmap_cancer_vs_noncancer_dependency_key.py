#!/usr/bin/env python3
import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent
MIN_CANCER_N = 500
MIN_NONCANCER_N = 8
MIN_LINEAGE_N = 12


def gene_symbol(header_name):
    return header_name.split(" (", 1)[0]


def bh_fdr(pvals):
    p = np.asarray(pvals, dtype=float)
    q = np.full(p.shape, np.nan)
    mask = np.isfinite(p)
    vals = p[mask]
    order = np.argsort(vals)
    ranked = vals[order]
    n = len(ranked)
    adj = np.empty(n)
    prev = 1.0
    for i in range(n - 1, -1, -1):
        val = min(prev, ranked[i] * n / (i + 1))
        adj[i] = val
        prev = val
    restored = np.empty(n)
    restored[order] = adj
    q[mask] = restored
    return q


def load_model_labels():
    labels = {}
    with open(ROOT / "Model.csv", newline="") as f:
        for row in csv.DictReader(f):
            disease = row.get("OncotreePrimaryDisease") or ""
            lineage = row.get("OncotreeLineage") or "Unknown"
            is_noncancer = disease == "Non-Cancerous" or lineage == "Normal"
            labels[row["ModelID"]] = {
                "is_cancer": not is_noncancer,
                "disease": disease,
                "lineage": lineage,
            }
    return labels


def cohens_d(a, b):
    a = a[np.isfinite(a)]
    b = b[np.isfinite(b)]
    if len(a) < 2 or len(b) < 2:
        return math.nan
    pooled = math.sqrt(((len(a) - 1) * np.var(a, ddof=1) + (len(b) - 1) * np.var(b, ddof=1)) / (len(a) + len(b) - 2))
    if pooled == 0:
        return math.nan
    return float((np.mean(a) - np.mean(b)) / pooled)


def main():
    labels = load_model_labels()
    with open(ROOT / "CRISPRGeneEffect.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        genes = [gene_symbol(h) for h in header[1:]]
        model_ids = []
        rows = []
        meta = []
        for row in reader:
            mid = row[0]
            if mid not in labels:
                continue
            try:
                vals = np.array([float(x) if x else np.nan for x in row[1:]], dtype=float)
            except Exception:
                continue
            model_ids.append(mid)
            rows.append(vals)
            meta.append(labels[mid])
    effect = np.vstack(rows)
    dependency = -effect
    is_cancer = np.array([m["is_cancer"] for m in meta], dtype=bool)
    lineages = np.array([m["lineage"] for m in meta])

    cancer_lineages = sorted({
        lin for lin in set(lineages[is_cancer])
        if np.sum(is_cancer & (lineages == lin)) >= MIN_LINEAGE_N
    })

    results = []
    for j, gene in enumerate(genes):
        dep = dependency[:, j]
        cancer = dep[is_cancer & np.isfinite(dep)]
        nonc = dep[(~is_cancer) & np.isfinite(dep)]
        if len(cancer) < MIN_CANCER_N or len(nonc) < MIN_NONCANCER_N:
            continue
        t, p = stats.ttest_ind(cancer, nonc, equal_var=False)
        d = cohens_d(cancer, nonc)
        diff = float(np.mean(cancer) - np.mean(nonc))
        lineage_hits = 0
        lineage_tested = 0
        lineage_details = []
        nonc_mean = float(np.mean(nonc))
        for lin in cancer_lineages:
            vals = dep[is_cancer & (lineages == lin) & np.isfinite(dep)]
            if len(vals) < MIN_LINEAGE_N:
                continue
            lineage_tested += 1
            ld = float(np.mean(vals) - nonc_mean)
            if ld > 0:
                lineage_hits += 1
            lineage_details.append({"lineage": lin, "n": int(len(vals)), "mean_dependency_minus_noncancer": ld})
        results.append({
            "gene": gene,
            "n_cancer": int(len(cancer)),
            "n_noncancer": int(len(nonc)),
            "mean_dependency_cancer": float(np.mean(cancer)),
            "mean_dependency_noncancer": float(np.mean(nonc)),
            "cancer_minus_noncancer_dependency": diff,
            "cohens_d": d,
            "welch_p": float(p),
            "cancer_lineages_positive": int(lineage_hits),
            "cancer_lineages_tested": int(lineage_tested),
            "fraction_lineages_positive": float(lineage_hits / lineage_tested) if lineage_tested else math.nan,
            "top_lineage_differences": sorted(lineage_details, key=lambda x: x["mean_dependency_minus_noncancer"], reverse=True)[:8],
            "bottom_lineage_differences": sorted(lineage_details, key=lambda x: x["mean_dependency_minus_noncancer"])[:8],
        })

    qs = bh_fdr([r["welch_p"] for r in results])
    for r, q in zip(results, qs):
        r["bh_fdr"] = float(q)

    stronger = [
        r for r in results
        if r["cancer_minus_noncancer_dependency"] > 0
        and r["bh_fdr"] < 0.05
        and r["fraction_lineages_positive"] >= 0.75
    ]
    weaker = [
        r for r in results
        if r["cancer_minus_noncancer_dependency"] < 0
        and r["bh_fdr"] < 0.05
        and r["fraction_lineages_positive"] <= 0.25
    ]
    stronger.sort(key=lambda r: (-r["fraction_lineages_positive"], -r["cancer_minus_noncancer_dependency"]))
    weaker.sort(key=lambda r: (r["fraction_lineages_positive"], r["cancer_minus_noncancer_dependency"]))

    out = {
        "question": "Which CRISPR dependencies distinguish cancer models from non-cancerous DepMap models broadly across cancer lineages?",
        "data_source": "DepMap 24Q4 Public Model.csv and CRISPRGeneEffect.csv.",
        "interpretation_warning": "DepMap non-cancerous models are not a full normal-tissue safety atlas; this is a first discriminator, not clinical selectivity.",
        "n_models_total": int(len(model_ids)),
        "n_cancer_models": int(np.sum(is_cancer)),
        "n_noncancer_models": int(np.sum(~is_cancer)),
        "n_cancer_lineages_testable": int(len(cancer_lineages)),
        "n_genes_tested": int(len(results)),
        "criteria_for_candidate_key": "Cancer dependency > non-cancer dependency, BH-FDR < 0.05, and positive in at least 75% of cancer lineages.",
        "n_candidate_keys": int(len(stronger)),
        "top_candidate_keys": stronger[:80],
        "top_noncancer_stronger_dependencies": weaker[:40],
    }
    (ROOT / "depmap_cancer_vs_noncancer_dependency_key_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
