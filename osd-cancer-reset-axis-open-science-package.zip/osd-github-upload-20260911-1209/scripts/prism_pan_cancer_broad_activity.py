#!/usr/bin/env python3
import csv
import json
import math
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
MIN_TISSUE_N = 10
SENSITIVITY_LFC = -0.5
STRONG_LFC = -1.0


def load_tissues():
    out = {}
    with open(ROOT / "prism_primary_cell_line_info.csv", newline="") as f:
        for row in csv.DictReader(f):
            out[row["row_name"]] = row.get("primary_tissue") or "unknown"
    return out


def load_treatments():
    out = {}
    with open(ROOT / "prism_primary_treatment_info.csv", newline="") as f:
        for row in csv.DictReader(f):
            out[row["column_name"]] = row
    return out


def main():
    tissues_by_model = load_tissues()
    treatments = load_treatments()
    with open(ROOT / "prism_primary_collapsed_lfc.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = [row for row in reader if row[0] in tissues_by_model]

    tissues = np.array([tissues_by_model[row[0]] for row in rows])
    eligible_tissues = {t for t in set(tissues) if np.sum(tissues == t) >= MIN_TISSUE_N}
    keep = np.array([t in eligible_tissues for t in tissues])
    rows = [row for row, ok in zip(rows, keep) if ok]
    tissues = tissues[keep]

    results = []
    for j, col in enumerate(header[1:], start=1):
        vals = []
        tv = {}
        for row, tissue in zip(rows, tissues):
            try:
                v = float(row[j])
            except Exception:
                continue
            if np.isfinite(v):
                vals.append(v)
                tv.setdefault(tissue, []).append(v)
        if len(vals) < 180:
            continue
        vals = np.array(vals)
        tissue_means = {t: float(np.mean(v)) for t, v in tv.items() if len(v) >= MIN_TISSUE_N}
        if len(tissue_means) < 10:
            continue
        frac_sensitive = float(np.mean(vals <= SENSITIVITY_LFC))
        frac_strong = float(np.mean(vals <= STRONG_LFC))
        tissue_frac_sensitive = {
            t: float(np.mean(np.array(v) <= SENSITIVITY_LFC))
            for t, v in tv.items()
            if len(v) >= MIN_TISSUE_N
        }
        broadly_hit_tissues = sum(1 for x in tissue_frac_sensitive.values() if x >= 0.5)
        info = treatments.get(col, {})
        results.append({
            "column_name": col,
            "name": info.get("name"),
            "moa": info.get("moa"),
            "target": info.get("target"),
            "phase": info.get("phase"),
            "dose": info.get("dose"),
            "n": int(len(vals)),
            "mean_log2_fold_change": float(np.mean(vals)),
            "median_log2_fold_change": float(np.median(vals)),
            "fraction_lfc_le_-0.5": frac_sensitive,
            "fraction_lfc_le_-1.0": frac_strong,
            "tissues_tested": len(tissue_means),
            "tissues_with_ge_50pct_sensitive": int(broadly_hit_tissues),
            "tissue_mean_sd": float(np.std(list(tissue_means.values()))),
            "tissue_means": dict(sorted(tissue_means.items(), key=lambda kv: kv[1])[:8]),
        })

    results.sort(key=lambda r: (-r["fraction_lfc_le_-0.5"], r["mean_log2_fold_change"]))
    out = {
        "data_source": "PRISM Repurposing 19Q4 primary replicate-collapsed log-fold-change.",
        "question": "Which compounds show broad pan-cancer growth inhibition across many cancer cell-line tissues?",
        "interpretation_warning": "Broad activity in cancer cell lines is not tumor-selective safety; it often indicates general cytotoxicity that may also harm normal proliferating cells.",
        "thresholds": {"sensitive_log2_fold_change": SENSITIVITY_LFC, "strong_log2_fold_change": STRONG_LFC},
        "n_tissues": int(len(eligible_tissues)),
        "n_compounds_tested": len(results),
        "top_broad_activity": results[:80],
    }
    (ROOT / "prism_pan_cancer_broad_activity_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
