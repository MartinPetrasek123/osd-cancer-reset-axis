#!/usr/bin/env python3
import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent
MIN_LINEAGE_N = 12
MIN_DRUG_N = 180
RNG_SEED = 20260910
N_PERM = 5000

FLOW_DEPENDENCY_MODULES = {
    "polyamine_core": ["AMD1", "SMS", "SRM", "ODC1", "SAT1", "SMOX", "PAOX"],
    "dna_replication": ["PCNA", "MCM2", "MCM3", "MCM4", "MCM5", "MCM6", "MCM7", "RRM1", "RRM2", "TOP1", "TOP2A"],
    "mitotic_execution": ["PLK1", "AURKA", "AURKB", "BUB1B", "CDC20", "CDK1", "KIF11", "TTK"],
    "proteasome_capacity": ["PSMA1", "PSMA2", "PSMA3", "PSMA6", "PSMB1", "PSMB2", "PSMB3", "PSMB5", "PSMC1", "PSMD1"],
    "ribosome_translation": ["RPL17", "RPL21", "RPS3A", "RPS8", "RPS19", "RPS20", "RPS29", "EIF4A3", "EIF3A", "EEF2"],
    "rna_processing": ["SNRPD3", "SNRPF", "SNRPA1", "SF3B1", "SF3B5", "SMU1", "THRAP3", "LDB1"],
    "apoptosis_buffer": ["BCL2L1", "MCL1", "BIRC5", "XIAP", "PIM2"],
}

FLOW_MOA_KEYWORDS = [
    "proteasome inhibitor",
    "protein synthesis inhibitor",
    "topoisomerase inhibitor",
    "cdk inhibitor",
    "hdac inhibitor",
    "pi3k inhibitor",
    "mtor inhibitor",
    "hsp inhibitor",
    "survivin inhibitor",
    "plk inhibitor",
]


def gene_symbol(header_name):
    return header_name.split(" (", 1)[0]


def bh_fdr(pvals):
    p = np.asarray(pvals, dtype=float)
    q = np.full(p.shape, np.nan)
    mask = np.isfinite(p)
    vals = p[mask]
    order = np.argsort(vals)
    ranked = vals[order]
    n = len(ranked)
    adj = np.empty(n)
    prev = 1.0
    for i in range(n - 1, -1, -1):
        val = min(prev, ranked[i] * n / (i + 1))
        adj[i] = val
        prev = val
    restored = np.empty(n)
    restored[order] = adj
    q[mask] = restored
    return q


def rank_norm(x):
    x = np.asarray(x, dtype=float)
    mask = np.isfinite(x)
    out = np.full(x.shape, np.nan)
    if mask.sum() < 3:
        return out
    ranks = stats.rankdata(x[mask], method="average")
    u = (ranks - 0.5) / mask.sum()
    out[mask] = stats.norm.ppf(u)
    return out


def load_models():
    meta = {}
    with open(ROOT / "Model.csv", newline="") as f:
        for row in csv.DictReader(f):
            disease = row.get("OncotreePrimaryDisease") or ""
            lineage = row.get("OncotreeLineage") or "Unknown"
            is_noncancer = disease == "Non-Cancerous" or lineage == "Normal"
            meta[row["ModelID"]] = {"lineage": lineage, "is_cancer": not is_noncancer}
    return meta


def residualize(values, groups):
    values = np.asarray(values, dtype=float)
    groups = np.asarray(groups)
    out = np.full(values.shape, np.nan)
    for g in sorted(set(groups)):
        idx = np.where(groups == g)[0]
        if len(idx) < MIN_LINEAGE_N:
            continue
        v = values[idx]
        m = np.nanmean(v)
        s = np.nanstd(v)
        if np.isfinite(s) and s > 0:
            out[idx] = (v - m) / s
    return out


def residualize_matrix(matrix, groups):
    out = np.full(matrix.shape, np.nan)
    groups = np.asarray(groups)
    for g in sorted(set(groups)):
        idx = np.where(groups == g)[0]
        if len(idx) < MIN_LINEAGE_N:
            continue
        block = matrix[idx, :]
        mu = np.nanmean(block, axis=0)
        sd = np.nanstd(block, axis=0)
        ok = np.isfinite(sd) & (sd > 0)
        out[np.ix_(idx, ok)] = (block[:, ok] - mu[ok]) / sd[ok]
    return out


def safe_spearman(x, y):
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 100:
        return math.nan, math.nan, int(mask.sum())
    r, p = stats.spearmanr(x[mask], y[mask])
    return float(r), float(p), int(mask.sum())


def high_low_delta(marker, sens, groups):
    deltas = []
    n = 0
    for g in sorted(set(groups)):
        idx = np.where(groups == g)[0]
        mask = np.isfinite(marker[idx]) & np.isfinite(sens[idx])
        if mask.sum() < MIN_LINEAGE_N:
            continue
        local = idx[mask]
        split = np.nanmedian(marker[local])
        hi = marker[local] >= split
        lo = marker[local] < split
        if hi.sum() >= 4 and lo.sum() >= 4:
            deltas.append(float(np.nanmean(sens[local][hi]) - np.nanmean(sens[local][lo])))
            n += len(local)
    if not deltas:
        return math.nan, 0, 0
    return float(np.mean(deltas)), int(n), int(len(deltas))


def load_prism_treatments():
    out = {}
    with open(ROOT / "prism_primary_treatment_info.csv", newline="") as f:
        for row in csv.DictReader(f):
            moa = (row.get("moa") or "").lower()
            target = (row.get("target") or "").lower()
            text = moa + " " + target
            out[row["column_name"]] = {
                "name": row.get("name"),
                "moa": row.get("moa"),
                "target": row.get("target"),
                "phase": row.get("phase"),
                "is_flow_collapse_moa": any(k in text for k in FLOW_MOA_KEYWORDS),
            }
    return out


def parse_float(value):
    try:
        return float(value)
    except Exception:
        return math.nan


def main():
    rng = np.random.default_rng(RNG_SEED)
    model_meta = load_models()
    with open(ROOT / "CRISPRGeneEffect.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        all_genes = [gene_symbol(h) for h in header[1:]]
        gene_to_idx = {g: i for i, g in enumerate(all_genes)}
        wanted = sorted({g for genes in FLOW_DEPENDENCY_MODULES.values() for g in genes if g in gene_to_idx})
        wanted_idx = [gene_to_idx[g] for g in wanted]
        model_ids = []
        meta = []
        effect_rows = []
        for row in reader:
            mid = row[0]
            if mid not in model_meta or not model_meta[mid]["is_cancer"]:
                continue
            vals = np.array([float(row[i + 1]) if row[i + 1] else np.nan for i in wanted_idx], dtype=float)
            model_ids.append(mid)
            meta.append(model_meta[mid])
            effect_rows.append(vals)

    dependency = -np.vstack(effect_rows)
    lineages = np.array([m["lineage"] for m in meta])
    dep_z = residualize_matrix(dependency, lineages)
    wanted_to_local = {g: i for i, g in enumerate(wanted)}
    amd1 = dep_z[:, wanted_to_local["AMD1"]]

    module_results = []
    module_scores = {}
    for module, genes in FLOW_DEPENDENCY_MODULES.items():
        found = [g for g in genes if g in wanted_to_local and not (module != "polyamine_core" and g == "AMD1")]
        if not found:
            continue
        score = np.nanmean(dep_z[:, [wanted_to_local[g] for g in found]], axis=1)
        module_scores[module] = score
        r, p, n = safe_spearman(amd1, score)
        d, dn, dt = high_low_delta(amd1, score, lineages)
        module_results.append({
            "module": module,
            "genes_found": found,
            "n": n,
            "spearman_r_with_AMD1_dependency": r,
            "spearman_p": p,
            "high_AMD1_minus_low_AMD1_module_dependency_z": d,
            "delta_n": dn,
            "delta_lineages": dt,
        })
    qs = bh_fdr([r["spearman_p"] for r in module_results])
    for row, q in zip(module_results, qs):
        row["bh_fdr"] = float(q)
    module_results.sort(key=lambda r: r["spearman_p"])

    flow_index = np.nanmean(np.vstack([
        score for name, score in module_scores.items() if name != "polyamine_core"
    ]), axis=0)
    flow_index = residualize(flow_index, lineages)
    amd1_flow_marker = residualize(rank_norm(amd1) + rank_norm(flow_index), lineages)

    prism_treatments = load_prism_treatments()
    prism_models = set(model_ids)
    prism_rows = []
    with open(ROOT / "prism_primary_collapsed_lfc.csv", newline="") as f:
        reader = csv.reader(f)
        prism_header = next(reader)
        model_to_prism = {}
        for row in reader:
            if row[0] in prism_models:
                model_to_prism[row[0]] = row
    common_models = [m for m in model_ids if m in model_to_prism]
    common_idx = np.array([model_ids.index(m) for m in common_models], dtype=int)
    common_lineages = lineages[common_idx]
    common_marker = amd1_flow_marker[common_idx]
    common_amd1 = amd1[common_idx]
    common_flow = flow_index[common_idx]

    flow_deltas = []
    other_deltas = []
    for j, col in enumerate(prism_header[1:], start=1):
        lfc = np.array([parse_float(model_to_prism[m][j]) for m in common_models], dtype=float)
        if np.isfinite(lfc).sum() < MIN_DRUG_N:
            continue
        sens = residualize(-lfc, common_lineages)
        mean_lfc = float(np.nanmean(lfc))
        frac_broad = float(np.nanmean(lfc <= -0.5))
        # Focus on nontrivial but not universally lethal drugs.
        if mean_lfc <= -3.0 or frac_broad >= 0.98:
            continue
        d_marker, n, nt = high_low_delta(common_marker, sens, common_lineages)
        d_amd1, _, _ = high_low_delta(common_amd1, sens, common_lineages)
        d_flow, _, _ = high_low_delta(common_flow, sens, common_lineages)
        if not np.isfinite(d_marker):
            continue
        info = prism_treatments.get(col, {})
        record = {
            "column_name": col,
            "name": info.get("name"),
            "moa": info.get("moa"),
            "target": info.get("target"),
            "phase": info.get("phase"),
            "is_flow_collapse_moa": bool(info.get("is_flow_collapse_moa")),
            "n": n,
            "lineages": nt,
            "mean_lfc": mean_lfc,
            "fraction_lfc_le_-0.5": frac_broad,
            "delta_high_marker_minus_low_sensitivity_z": d_marker,
            "delta_high_AMD1_minus_low_sensitivity_z": d_amd1,
            "delta_high_flow_index_minus_low_sensitivity_z": d_flow,
        }
        prism_rows.append(record)
        if record["is_flow_collapse_moa"]:
            flow_deltas.append(d_marker)
        else:
            other_deltas.append(d_marker)

    flow_deltas = np.asarray(flow_deltas, dtype=float)
    other_deltas = np.asarray(other_deltas, dtype=float)
    t, p = stats.ttest_ind(flow_deltas, other_deltas, equal_var=False)
    observed = float(np.nanmean(flow_deltas) - np.nanmean(other_deltas))
    labels = np.array([r["is_flow_collapse_moa"] for r in prism_rows], dtype=bool)
    deltas = np.array([r["delta_high_marker_minus_low_sensitivity_z"] for r in prism_rows], dtype=float)
    hits = 0
    for _ in range(N_PERM):
        perm = rng.permutation(labels)
        diff = np.nanmean(deltas[perm]) - np.nanmean(deltas[~perm])
        if abs(diff) >= abs(observed):
            hits += 1
    perm_p = float((hits + 1) / (N_PERM + 1))

    prism_rows.sort(key=lambda r: r["delta_high_marker_minus_low_sensitivity_z"], reverse=True)
    out = {
        "question": "Does AMD1 mark a broader synthetic-flow dependency state, and do flow-collapse PRISM MOAs preferentially inhibit high AMD1+flow-index cancer models?",
        "data_sources": [
            "DepMap 24Q4 CRISPRGeneEffect and Model.csv.",
            "PRISM Repurposing 19Q4 primary collapsed log-fold-change and treatment metadata.",
        ],
        "dependency_design": "Within-lineage residualized CRISPR dependency; AMD1 dependency tested against pre-specified synthetic-flow modules.",
        "drug_design": "Marker = within-lineage residualized rank(AMD1 dependency) + rank(non-polyamine synthetic-flow dependency index). Drug sensitivity = -PRISM log2 fold-change residualized within lineage. Excluded near-universal lethal compounds.",
        "n_depmap_cancer_models": int(len(model_ids)),
        "n_prism_overlap_models": int(len(common_models)),
        "module_results": module_results,
        "prism_summary": {
            "n_drugs_after_filter": int(len(prism_rows)),
            "n_flow_collapse_moa_drugs": int(labels.sum()),
            "mean_delta_flow_collapse_moa": float(np.nanmean(flow_deltas)),
            "mean_delta_other_moa": float(np.nanmean(other_deltas)),
            "flow_minus_other_delta": observed,
            "welch_p": float(p),
            "drug_label_permutation_p": perm_p,
        },
        "top_marker_selective_prism_hits": prism_rows[:80],
        "top_flow_collapse_moa_hits": [r for r in prism_rows if r["is_flow_collapse_moa"]][:50],
    }
    (ROOT / "synthetic_flow_collapse_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
