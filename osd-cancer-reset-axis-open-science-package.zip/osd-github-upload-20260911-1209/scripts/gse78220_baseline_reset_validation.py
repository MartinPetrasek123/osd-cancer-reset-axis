#!/usr/bin/env python3
import gzip
import json
import math
import re
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = Path(__file__).resolve().parents[3] / "outputs"

MODULES = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1"],
    "inflammatory_alarm": ["IL6", "IL1B", "TNF", "NFKB1", "NFKB2", "RELA", "STAT3", "PTGS2", "CXCL8", "CCL2", "CXCL1", "CXCL2"],
    "interferon_alarm": ["IFNG", "IRF7", "STAT1", "ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "CXCL10", "GBP1"],
    "wound_ecm_fibrosis": ["TGFB1", "TGFBR1", "SMAD2", "SMAD3", "COL1A1", "COL1A2", "COL3A1", "FN1", "VIM", "ACTA2", "MMP2", "MMP9", "TIMP1"],
    "coagulation_complement": ["C3", "C5", "CFB", "CFH", "F2", "F3", "FGA", "FGB", "FGG", "SERPINE1", "PLAU", "PLAT"],
    "hypoxia_redox_stress": ["HIF1A", "VEGFA", "SLC2A1", "CA9", "LDHA", "NFE2L2", "HMOX1", "NQO1", "SOD2", "TXN", "PRDX1"],
    "proteostasis_er_stress": ["HSPA5", "XBP1", "ATF4", "DDIT3", "HSP90AA1", "PSMA1", "PSMB5", "PSMC1", "PSMD1"],
    "bioelectric_junction_order": ["GJA1", "GJB1", "GJB2", "PANX1", "ATP1A1", "ATP1B1", "KCNJ2", "KCNQ1", "CLCN3", "SLC9A1", "VDAC1"],
    "polarity_adhesion_order": ["PARD3", "PARD6A", "PRKCI", "SCRIB", "DLG1", "LLGL1", "CDH1", "ITGA5", "ITGB1", "VCL", "TLN1", "PXN"],
    "circadian_order": ["CLOCK", "ARNTL", "PER1", "PER2", "PER3", "CRY1", "CRY2", "NR1D1", "NR1D2", "RORA", "DBP"],
    "mitochondrial_homeostasis": ["PPARGC1A", "PPARGC1B", "NDUFS1", "NDUFV1", "SDHA", "UQCRC1", "COX4I1", "ATP5F1A", "TFAM", "SIRT3"],
    "differentiation_order": ["NOTCH1", "NOTCH2", "RBPJ", "CTNNB1", "APC", "YAP1", "WWTR1", "TEAD1", "TEAD4", "LATS1", "LATS2"],
}


def zscore(x):
    x = np.asarray(x, dtype=float)
    s = np.nanstd(x)
    if not np.isfinite(s) or s == 0:
        return np.zeros_like(x)
    return (x - np.nanmean(x)) / s


def residualize(y, x):
    y = np.asarray(y, dtype=float)
    x = zscore(x)
    mask = np.isfinite(y) & np.isfinite(x)
    out = np.full(y.shape, np.nan)
    if mask.sum() < 6:
        return out
    xm = x[mask] - np.mean(x[mask])
    ym = y[mask] - np.mean(y[mask])
    denom = float(np.dot(xm, xm))
    if denom == 0:
        return out
    out[mask] = ym - float(np.dot(xm, ym) / denom) * xm
    return out


def ranks(x):
    x = np.asarray(x, dtype=float)
    order = np.argsort(x)
    out = np.empty(len(x), dtype=float)
    i = 0
    while i < len(x):
        j = i + 1
        while j < len(x) and x[order[j]] == x[order[i]]:
            j += 1
        out[order[i:j]] = (i + j - 1) / 2.0 + 1.0
        i = j
    return out


def spearman(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 4:
        return math.nan
    rx = ranks(x[mask])
    ry = ranks(y[mask])
    sx = np.std(rx)
    sy = np.std(ry)
    if sx == 0 or sy == 0:
        return math.nan
    return float(np.corrcoef(rx, ry)[0, 1])


def auc_higher(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    a = a[np.isfinite(a)]
    b = b[np.isfinite(b)]
    if len(a) == 0 or len(b) == 0:
        return math.nan
    wins = 0.0
    for va in a:
        wins += float(np.sum(va > b)) + 0.5 * float(np.sum(va == b))
    return wins / (len(a) * len(b))


def parse_series_matrix():
    meta_rows = {}
    with gzip.open(ROOT / "GSE78220_series_matrix.txt.gz", "rt", errors="replace") as f:
        titles = None
        for line in f:
            if line.startswith("!Sample_title"):
                titles = [p.strip().strip('"') for p in line.rstrip("\n").split("\t")[1:]]
                meta_rows = {t: {"title": t} for t in titles}
            elif titles and line.startswith("!Sample_source_name_ch1"):
                vals = [p.strip().strip('"') for p in line.rstrip("\n").split("\t")[1:]]
                for title, val in zip(titles, vals):
                    if "_" in val:
                        meta_rows[title]["response"] = val.rsplit("_", 1)[1]
            elif titles and line.startswith("!Sample_characteristics_ch1"):
                vals = [p.strip().strip('"') for p in line.rstrip("\n").split("\t")[1:]]
                for title, val in zip(titles, vals):
                    if ": " not in val:
                        continue
                    key, raw = val.split(": ", 1)
                    key = key.lower().replace(" ", "_").replace("-", "_")
                    meta_rows[title][key] = raw
    return meta_rows


def column_to_patient(col):
    stem = col.split(".", 1)[0]
    return re.sub(r"[A-Z]$", "", stem)


def response_binary(response):
    if response in {"Complete Response", "Partial Response"}:
        return "responder"
    if response == "Progressive Disease":
        return "progressor"
    return "other"


def module_scores(expr):
    genes_found = {}
    gene_z = expr.apply(lambda row: zscore(np.log2(row.to_numpy(dtype=float) + 1.0)), axis=1, result_type="expand")
    gene_z.columns = expr.columns
    gene_z.index = expr.index

    scores = {}
    for module, genes in MODULES.items():
        present = [g for g in genes if g in gene_z.index]
        genes_found[module] = present
        scores[module] = gene_z.loc[present].mean(axis=0).to_numpy(dtype=float)

    instability = sum(zscore(scores[name]) for name in [
        "inflammatory_alarm",
        "interferon_alarm",
        "wound_ecm_fibrosis",
        "coagulation_complement",
        "hypoxia_redox_stress",
        "proteostasis_er_stress",
    ])
    order = sum(zscore(scores[name]) for name in [
        "bioelectric_junction_order",
        "polarity_adhesion_order",
        "circadian_order",
        "mitochondrial_homeostasis",
        "differentiation_order",
    ])
    scores["instability_load"] = instability
    scores["order_capacity"] = order
    scores["osd_raw"] = instability - order
    scores["osd_residual_vs_proliferation"] = residualize(scores["osd_raw"], scores["proliferation"])
    return scores, genes_found


def mannwhitney_summary(values, labels, a="progressor", b="responder"):
    va = np.array([v for v, lab in zip(values, labels) if lab == a and np.isfinite(v)], dtype=float)
    vb = np.array([v for v, lab in zip(values, labels) if lab == b and np.isfinite(v)], dtype=float)
    if len(va) < 3 or len(vb) < 3:
        return {"n_a": len(va), "n_b": len(vb), "delta_a_minus_b": math.nan, "permutation_p": math.nan, "auc_a_higher": math.nan}
    perm = permutation_delta(values, labels, n_perm=10000, seed=13)
    return {
        "group_a": a,
        "group_b": b,
        "n_a": int(len(va)),
        "n_b": int(len(vb)),
        "median_a": float(np.median(va)),
        "median_b": float(np.median(vb)),
        "delta_median_a_minus_b": float(np.median(va) - np.median(vb)),
        "permutation_p": perm["two_sided_empirical_p"],
        "auc_a_higher": float(auc_higher(va, vb)),
    }


def permutation_delta(values, labels, n_perm=10000, seed=7):
    values = np.asarray(values, dtype=float)
    labels = np.asarray(labels)
    mask = np.isfinite(values) & np.isin(labels, ["responder", "progressor"])
    values = values[mask]
    labels = labels[mask]
    obs = float(np.median(values[labels == "progressor"]) - np.median(values[labels == "responder"]))
    rng = np.random.default_rng(seed)
    count = 0
    for _ in range(n_perm):
        shuffled = rng.permutation(labels)
        perm = float(np.median(values[shuffled == "progressor"]) - np.median(values[shuffled == "responder"]))
        if abs(perm) >= abs(obs):
            count += 1
    return {"observed_delta_progressor_minus_responder": obs, "n_perm": n_perm, "two_sided_empirical_p": (count + 1) / (n_perm + 1)}


def survival_summary(values, os_days, vital_status, n_perm=10000, seed=11):
    values = np.asarray(values, dtype=float)
    os_days = np.asarray(os_days, dtype=float)
    events = np.array([1 if v == "Dead" else 0 for v in vital_status], dtype=int)
    mask = np.isfinite(values) & np.isfinite(os_days)
    values = values[mask]
    os_days = os_days[mask]
    events = events[mask]
    if len(values) < 8:
        return {}
    rho = spearman(values, os_days)
    high = values >= np.median(values)
    obs = float(np.median(os_days[high]) - np.median(os_days[~high]))
    rng = np.random.default_rng(seed)
    count = 0
    count_rho = 0
    for _ in range(n_perm):
        perm_high = rng.permutation(high)
        perm = float(np.median(os_days[perm_high]) - np.median(os_days[~perm_high]))
        if abs(perm) >= abs(obs):
            count += 1
        perm_values = rng.permutation(values)
        perm_rho = spearman(perm_values, os_days)
        if abs(perm_rho) >= abs(rho):
            count_rho += 1
    return {
        "n": int(len(values)),
        "events": int(events.sum()),
        "spearman_score_vs_os_days": float(rho),
        "spearman_permutation_p": (count_rho + 1) / (n_perm + 1),
        "median_os_high_score": float(np.median(os_days[high])),
        "median_os_low_score": float(np.median(os_days[~high])),
        "delta_median_os_high_minus_low": obs,
        "permutation_p_for_median_os_delta": (count + 1) / (n_perm + 1),
    }


def main():
    meta = parse_series_matrix()
    fpkm = pd.read_excel(ROOT / "GSE78220_PatientFPKM.xlsx", sheet_name="FPKM")
    fpkm = fpkm.groupby("Gene", as_index=True).mean(numeric_only=True)
    baseline_cols = [c for c in fpkm.columns if c.endswith(".baseline")]
    expr = fpkm[baseline_cols]
    scores, genes_found = module_scores(expr)

    rows = []
    sample_order = [col.split(".", 1)[0] for col in baseline_cols]
    for i, col in enumerate(baseline_cols):
        title = col.split(".", 1)[0]
        patient = column_to_patient(col)
        m = meta.get(title, {})
        response = m.get("anti_pd_1_response") or m.get("response")
        if response is None:
            continue
        os_raw = m.get("overall_survival_(days)", "nan")
        row = {
            "sample": title,
            "patient": patient,
            "response": response,
            "response_binary": response_binary(response),
            "overall_survival_days": float(os_raw) if os_raw != "NA" else math.nan,
            "vital_status": m.get("vital_status"),
            "previous_mapki": m.get("previous_mapki"),
        }
        for name, vec in scores.items():
            row[name] = float(vec[i])
        rows.append(row)

    # Pt27 has two baseline biopsies; use patient-level averaging to avoid double-counting.
    patient_rows = []
    for patient in sorted({r["patient"] for r in rows}):
        rs = [r for r in rows if r["patient"] == patient]
        base = rs[0].copy()
        base["samples_averaged"] = [r["sample"] for r in rs]
        for name in scores:
            base[name] = float(np.mean([r[name] for r in rs]))
        patient_rows.append(base)

    labels = [r["response_binary"] for r in patient_rows]
    os_days = [r["overall_survival_days"] for r in patient_rows]
    vital = [r["vital_status"] for r in patient_rows]

    score_names = [
        "osd_raw",
        "osd_residual_vs_proliferation",
        "instability_load",
        "order_capacity",
        "wound_ecm_fibrosis",
        "hypoxia_redox_stress",
        "proteostasis_er_stress",
        "interferon_alarm",
        "circadian_order",
        "mitochondrial_homeostasis",
        "proliferation",
    ]
    response_tests = {name: mannwhitney_summary([r[name] for r in patient_rows], labels) for name in score_names}
    response_permutations = {name: permutation_delta([r[name] for r in patient_rows], labels) for name in ["osd_raw", "osd_residual_vs_proliferation", "wound_ecm_fibrosis", "proteostasis_er_stress"]}
    survival_tests = {name: survival_summary([r[name] for r in patient_rows], os_days, vital) for name in ["osd_raw", "osd_residual_vs_proliferation", "wound_ecm_fibrosis", "proteostasis_er_stress", "proliferation"]}

    result = {
        "question": "Independent real-patient validation: does baseline organism stability disruption mark anti-PD-1 resistance or survival in melanoma?",
        "data_source": "GSE78220 / Hugo et al. pretreatment melanoma biopsies treated with pembrolizumab; FPKM expression and clinical response from GEO supplementary file.",
        "n_baseline_biopsies": len(rows),
        "n_patients_after_averaging_duplicate_baseline_biopsies": len(patient_rows),
        "response_counts": {k: labels.count(k) for k in sorted(set(labels))},
        "primary_prediction": "Progressive disease should show higher baseline OSD, especially wound/ECM/stress modules, than complete/partial responders.",
        "module_genes_found": genes_found,
        "response_tests_progressor_vs_responder": response_tests,
        "permutation_tests": response_permutations,
        "survival_tests": survival_tests,
        "patient_rows": patient_rows,
        "guardrail": "Small public cohort; this is hypothesis validation, not clinical proof or treatment advice.",
    }
    (ROOT / "gse78220_baseline_reset_validation_results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")

    report = [
        "# GSE78220 Independent Baseline Reset Validation",
        "",
        "## Question",
        "Does the same organism-stability / reset-axis signature, without retuning genes to this cohort, mark real anti-PD-1 resistance in pretreatment melanoma biopsies?",
        "",
        "## Dataset",
        "- Source: GSE78220 / Hugo et al., pretreatment melanoma biopsies treated with pembrolizumab.",
        f"- Baseline biopsies analyzed: {len(rows)}.",
        f"- Patients after averaging duplicate baseline biopsies: {len(patient_rows)}.",
        f"- Response groups: {result['response_counts']}.",
        "",
        "## Primary Result",
    ]
    for name in ["osd_raw", "osd_residual_vs_proliferation", "wound_ecm_fibrosis", "proteostasis_er_stress", "hypoxia_redox_stress", "proliferation"]:
        t = response_tests[name]
        report.append(
            f"- {name}: progressor median {t['median_a']:.3f}, responder median {t['median_b']:.3f}, "
            f"delta {t['delta_median_a_minus_b']:.3f}, AUC progressor-higher {t['auc_a_higher']:.3f}, "
            f"permutation p={t['permutation_p']:.4g}."
        )
    report += [
        "",
        "## Survival Anchor",
    ]
    for name in ["osd_raw", "osd_residual_vs_proliferation", "wound_ecm_fibrosis", "proteostasis_er_stress", "proliferation"]:
        s = survival_tests[name]
        report.append(
            f"- {name}: Spearman score vs OS days rho={s['spearman_score_vs_os_days']:.3f}, "
            f"permutation p={s['spearman_permutation_p']:.4g}; median OS high-score {s['median_os_high_score']:.0f} days vs "
            f"low-score {s['median_os_low_score']:.0f} days, delta {s['delta_median_os_high_minus_low']:.0f} days, "
            f"permutation p={s['permutation_p_for_median_os_delta']:.4g}."
        )
    report += [
        "",
        "## Interpretation",
        "The result is partially supportive, not decisive. The full OSD score is higher in progressive disease than in responders, including after residualizing against proliferation, but the small cohort does not make that omnibus score statistically secure.",
        "",
        "The strongest replicated component is wound/ECM/fibrosis: it is clearly higher in progressive disease. That matters because it is one of the proposed organism-level stability-failure modules and matches the published biology of this cohort, where innate anti-PD-1 resistance was linked to mesenchymal, adhesion, ECM, wound-healing, and angiogenesis programs.",
        "",
        "Survival trends are weak in this small cohort. Proliferation shows the clearest adverse survival trend, while OSD and wound/ECM point in the expected direction but are not independently strong.",
        "",
        "So this is not a proof of a treatment. It is a real-patient anchor showing that the reset hypothesis should probably focus on a measurable tissue-repair/pathological-healing axis, then ask whether perturbing proteostasis/mechanics/epigenetic fixation can move that state.",
        "",
        "A strong finding here would be especially useful for attracting labs because it connects the theory to baseline clinical response, not only cell lines.",
    ]
    report_path = OUT / "gse78220_baseline_reset_validation_report.md"
    report_path.write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
