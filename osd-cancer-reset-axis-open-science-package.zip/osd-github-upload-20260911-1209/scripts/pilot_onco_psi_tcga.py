#!/usr/bin/env python3
import json
import math
import time
import urllib.request
from pathlib import Path

import numpy as np
from scipy import stats


BASE = "https://www.cbioportal.org/api"
OUT = Path(__file__).resolve().parent


def get_json(url, cache_name):
    cache = OUT / cache_name
    if cache.exists():
        return json.loads(cache.read_text())
    with urllib.request.urlopen(url, timeout=60) as r:
        data = json.loads(r.read().decode("utf-8"))
    cache.write_text(json.dumps(data), encoding="utf-8")
    time.sleep(0.05)
    return data


def tcga_pan_can_studies():
    studies = get_json(f"{BASE}/studies?projection=SUMMARY&pageSize=10000000", "studies.json")
    return sorted(
        s["studyId"]
        for s in studies
        if s.get("studyId", "").endswith("_tcga_pan_can_atlas_2018")
    )


def pivot(records, key_field, keep):
    rows = {}
    for r in records:
        attr = r.get("clinicalAttributeId")
        if attr not in keep:
            continue
        key = (r.get("studyId"), r.get(key_field))
        rows.setdefault(key, {})[attr] = r.get("value")
    return rows


def as_float(x):
    try:
        if x is None or str(x).strip() in {"", "NA", "N/A", "NaN", "nan"}:
            return math.nan
        return float(str(x).replace(",", ""))
    except Exception:
        return math.nan


def os_event(x):
    if x is None:
        return None
    s = str(x).strip().upper()
    if s.startswith("1:") or "DECEASED" in s or "DEAD" in s:
        return 1
    if s.startswith("0:") or "LIVING" in s or "ALIVE" in s:
        return 0
    return None


def zscore(v):
    v = np.asarray(v, dtype=float)
    m = np.nanmean(v)
    s = np.nanstd(v)
    if not np.isfinite(s) or s == 0:
        return np.zeros_like(v)
    return (v - m) / s


def stratified_cox_1d(times, events, x, strata):
    times = np.asarray(times, dtype=float)
    events = np.asarray(events, dtype=int)
    x = np.asarray(x, dtype=float)
    strata = np.asarray(strata)

    groups = []
    for st in sorted(set(strata)):
        idx = np.where(strata == st)[0]
        if events[idx].sum() >= 5 and len(idx) >= 20:
            groups.append(idx)

    def ll_grad_hess(beta):
        ll = 0.0
        grad = 0.0
        hess = 0.0
        for idx in groups:
            t = times[idx]
            e = events[idx]
            xx = x[idx]
            order = np.argsort(-t)
            t, e, xx = t[order], e[order], xx[order]
            eta = beta * xx
            # Stabilize risk weights inside each stratum.
            eta = eta - np.max(eta)
            w = np.exp(eta)
            cum_w = np.cumsum(w)
            cum_wx = np.cumsum(w * xx)
            cum_wx2 = np.cumsum(w * xx * xx)
            event_times = np.unique(t[e == 1])
            for et in event_times:
                pos = np.where(t == et)[0]
                dmask = pos[e[pos] == 1]
                if len(dmask) == 0:
                    continue
                last = pos[-1]
                d = len(dmask)
                sw = cum_w[last]
                mean = cum_wx[last] / sw
                var = cum_wx2[last] / sw - mean * mean
                ll += beta * np.sum(xx[dmask]) - d * (math.log(sw) + np.max(beta * xx))
                grad += np.sum(xx[dmask]) - d * mean
                hess -= d * max(var, 1e-12)
        return ll, grad, hess

    beta = 0.0
    for _ in range(40):
        _, g, h = ll_grad_hess(beta)
        step = g / (-h)
        beta += step
        if abs(step) < 1e-8:
            break
    ll, g, h = ll_grad_hess(beta)
    se = math.sqrt(1 / (-h))
    z = beta / se
    p = 2 * stats.norm.sf(abs(z))
    return {
        "beta": beta,
        "hr": math.exp(beta),
        "se": se,
        "z": z,
        "p": p,
        "strata_used": len(groups),
        "events_used": int(sum(events[idx].sum() for idx in groups)),
        "n_used": int(sum(len(idx) for idx in groups)),
    }


def main():
    sample_attrs = {"MUTATION_COUNT", "FRACTION_GENOME_ALTERED", "ANEUPLOIDY_SCORE", "SAMPLE_TYPE"}
    patient_attrs = {"OS_MONTHS", "OS_STATUS", "AGE"}

    all_rows = []
    for study in tcga_pan_can_studies():
        sample = get_json(
            f"{BASE}/studies/{study}/clinical-data?clinicalDataType=SAMPLE&projection=SUMMARY&pageSize=100000",
            f"{study}.sample_clinical.json",
        )
        patient = get_json(
            f"{BASE}/studies/{study}/clinical-data?clinicalDataType=PATIENT&projection=SUMMARY&pageSize=100000",
            f"{study}.patient_clinical.json",
        )
        srows = pivot(sample, "sampleId", sample_attrs)
        prows = pivot(patient, "patientId", patient_attrs)
        for (st, sample_id), sr in srows.items():
            # Prefer primary tumors; keep unknown if SAMPLE_TYPE is absent.
            stype = sr.get("SAMPLE_TYPE", "")
            if stype and stype.lower() != "primary":
                continue
            patient_id = "-".join(sample_id.split("-")[:3])
            pr = prows.get((st, patient_id), {})
            t = as_float(pr.get("OS_MONTHS"))
            ev = os_event(pr.get("OS_STATUS"))
            mut = as_float(sr.get("MUTATION_COUNT"))
            fga = as_float(sr.get("FRACTION_GENOME_ALTERED"))
            ane = as_float(sr.get("ANEUPLOIDY_SCORE"))
            if np.isfinite(t) and t > 0 and ev is not None:
                all_rows.append((study, sample_id, patient_id, t, ev, mut, fga, ane))

    rows = np.array(all_rows, dtype=object)
    studies = rows[:, 0].astype(str)
    times = rows[:, 3].astype(float)
    events = rows[:, 4].astype(int)
    mut = rows[:, 5].astype(float)
    fga = rows[:, 6].astype(float)
    ane = rows[:, 7].astype(float)

    complete = np.isfinite(mut) & np.isfinite(fga) & np.isfinite(ane)
    mut_z = zscore(np.log1p(mut[complete]))
    fga_z = zscore(fga[complete])
    ane_z = zscore(ane[complete])
    cri = (mut_z + fga_z + ane_z) / 3.0

    x_cri = zscore(cri)
    result = stratified_cox_1d(times[complete], events[complete], x_cri, studies[complete])
    component_results = {
        "log1p_mutation_count": stratified_cox_1d(times[complete], events[complete], zscore(np.log1p(mut[complete])), studies[complete]),
        "fraction_genome_altered": stratified_cox_1d(times[complete], events[complete], zscore(fga[complete]), studies[complete]),
        "aneuploidy_score": stratified_cox_1d(times[complete], events[complete], zscore(ane[complete]), studies[complete]),
    }

    rng = np.random.default_rng(20260910)
    perm_z = []
    for _ in range(1000):
        xp = x_cri.copy()
        for st in sorted(set(studies[complete])):
            idx = np.where(studies[complete] == st)[0]
            xp[idx] = rng.permutation(xp[idx])
        perm_z.append(stratified_cox_1d(times[complete], events[complete], xp, studies[complete])["z"])
    perm_z = np.asarray(perm_z)
    perm_p = (np.sum(np.abs(perm_z) >= abs(result["z"])) + 1) / (len(perm_z) + 1)

    per = []
    for st in sorted(set(studies[complete])):
        idx = np.where((studies[complete] == st))[0]
        if len(idx) < 40 or events[complete][idx].sum() < 5:
            continue
        try:
            r = stratified_cox_1d(times[complete][idx], events[complete][idx], zscore(cri[idx]), np.array([st] * len(idx)))
            per.append((st, len(idx), int(events[complete][idx].sum()), r["hr"], r["p"]))
        except Exception:
            pass

    high = cri >= np.nanmedian(cri)
    # Crude unadjusted event enrichment at 60 months among patients followed or dead by 60 months.
    at5 = (times[complete] >= 60) | (events[complete] == 1)
    death5 = (events[complete] == 1) & (times[complete] <= 60)
    tab = np.array([
        [int((death5 & high & at5).sum()), int(((~death5) & high & at5).sum())],
        [int((death5 & (~high) & at5).sum()), int(((~death5) & (~high) & at5).sum())],
    ])
    oddsratio, fisher_p = stats.fisher_exact(tab)

    out = {
        "hypothesis": "Pre-specified CRI = mean z(log1p mutation count), z(fraction genome altered), z(aneuploidy score).",
        "data_source": "cBioPortal TCGA PanCancer Atlas clinical attributes via public API.",
        "n_total_os": int(len(rows)),
        "n_complete_cri": int(complete.sum()),
        "events_complete_cri": int(events[complete].sum()),
        "stratified_cox_by_cancer_type": result,
        "component_stratified_cox": component_results,
        "within_cancer_permutation": {
            "n": int(len(perm_z)),
            "seed": 20260910,
            "observed_z": float(result["z"]),
            "max_abs_perm_z": float(np.max(np.abs(perm_z))),
            "empirical_two_sided_p": float(perm_p),
        },
        "five_year_crude_table_high_vs_low_cri": tab.tolist(),
        "five_year_crude_oddsratio": float(oddsratio),
        "five_year_crude_fisher_p": float(fisher_p),
        "per_cancer_results": [
            {"study": st, "n": n, "events": ev, "hr_per_sd_cri": hr, "p": p}
            for st, n, ev, hr, p in per
        ],
    }
    (OUT / "pilot_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
