#!/usr/bin/env python3
import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import pdist

ROOT = Path(__file__).resolve().parent
MIN_LINEAGE_N = 12
N_BOOT = 250
RNG_SEED = 20260910

MODULES = {
    "polyamine": ["AMD1", "SMS", "SRM", "ODC1", "SAT1", "SMOX", "PAOX"],
    "proteasome": ["PSMA1", "PSMA2", "PSMA3", "PSMA6", "PSMB1", "PSMB2", "PSMB3", "PSMB5", "PSMC1", "PSMD1"],
    "mitosis": ["PLK1", "AURKA", "AURKB", "BUB1B", "CDC20", "CDK1", "KIF11", "TTK"],
    "dna_replication": ["PCNA", "MCM2", "MCM3", "MCM4", "MCM5", "MCM6", "MCM7", "RRM1", "RRM2", "TOP1", "TOP2A"],
    "rna_processing": ["SNRPD3", "SNRPF", "SNRPA1", "SF3B1", "SF3B5", "SMU1", "THRAP3", "LDB1"],
    "apoptosis_buffer": ["BCL2L1", "MCL1", "BIRC5", "XIAP", "PIM2"],
    "immune_visibility": ["B2M", "HLA-A", "HLA-B", "HLA-C", "TAP1", "TAP2", "NLRC5", "JAK1", "JAK2", "STING1"],
}


def gene_symbol(x):
    return x.split(" (", 1)[0]


def load_models():
    meta = {}
    with open(ROOT / "Model.csv", newline="") as f:
        for row in csv.DictReader(f):
            disease = row.get("OncotreePrimaryDisease") or ""
            lineage = row.get("OncotreeLineage") or "Unknown"
            is_noncancer = disease == "Non-Cancerous" or lineage == "Normal"
            meta[row["ModelID"]] = {"lineage": lineage, "is_cancer": not is_noncancer, "disease": disease}
    return meta


def residualize_matrix(mat, groups):
    groups = np.asarray(groups)
    out = np.full(mat.shape, np.nan)
    for g in sorted(set(groups)):
        idx = np.where(groups == g)[0]
        if len(idx) < MIN_LINEAGE_N:
            continue
        block = mat[idx]
        mu = np.nanmean(block, axis=0)
        sd = np.nanstd(block, axis=0)
        ok = np.isfinite(sd) & (sd > 0)
        out[np.ix_(idx, ok)] = (block[:, ok] - mu[ok]) / sd[ok]
    return out


def load_module_scores():
    meta_map = load_models()
    wanted = sorted({g for genes in MODULES.values() for g in genes})
    with open(ROOT / "CRISPRGeneEffect.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        all_genes = [gene_symbol(h) for h in header[1:]]
        gene_to_idx = {g: i for i, g in enumerate(all_genes)}
        idx_by_module = {
            name: [gene_to_idx[g] for g in genes if g in gene_to_idx]
            for name, genes in MODULES.items()
        }
        needed_idx = sorted(set(i for idxs in idx_by_module.values() for i in idxs))
        idx_map = {old: new for new, old in enumerate(needed_idx)}
        mids, lineages, rows = [], [], []
        for row in reader:
            mid = row[0]
            if mid not in meta_map or not meta_map[mid]["is_cancer"]:
                continue
            vals = np.array([float(row[i + 1]) if row[i + 1] else np.nan for i in needed_idx], dtype=float)
            mids.append(mid)
            lineages.append(meta_map[mid]["lineage"])
            rows.append(vals)
    dep = -np.vstack(rows)
    dep_z = residualize_matrix(dep, lineages)
    module_names = list(MODULES)
    scores = []
    genes_found = {}
    for name in module_names:
        idxs = [idx_map[i] for i in idx_by_module[name]]
        genes_found[name] = [wanted_gene for wanted_gene in MODULES[name] if wanted_gene in gene_to_idx]
        scores.append(np.nanmean(dep_z[:, idxs], axis=1))
    score_mat = np.vstack(scores).T
    mask = np.isfinite(score_mat).sum(axis=1) == len(module_names)
    return np.array(mids)[mask], np.array(lineages)[mask], module_names, score_mat[mask], genes_found


def summarize_clusters(mids, lineages, module_names, scores, k):
    z = linkage(pdist(scores, metric="euclidean"), method="ward")
    labels = fcluster(z, k, criterion="maxclust")
    clusters = []
    for c in sorted(set(labels)):
        idx = labels == c
        center = np.mean(scores[idx], axis=0)
        order = np.argsort(center)[::-1]
        lin_counts = {}
        for lin in lineages[idx]:
            lin_counts[lin] = lin_counts.get(lin, 0) + 1
        clusters.append({
            "cluster": int(c),
            "n": int(idx.sum()),
            "fraction": float(idx.mean()),
            "dominant_modules": [{"module": module_names[i], "mean_z": float(center[i])} for i in order[:4]],
            "weak_modules": [{"module": module_names[i], "mean_z": float(center[i])} for i in order[-3:]],
            "top_lineages": sorted(lin_counts.items(), key=lambda kv: kv[1], reverse=True)[:8],
        })
    return labels, clusters


def bootstrap_stability(scores, k):
    rng = np.random.default_rng(RNG_SEED)
    n = scores.shape[0]
    co_same = np.zeros((n, n), dtype=float)
    co_seen = np.zeros((n, n), dtype=float)
    for _ in range(N_BOOT):
        sample = rng.choice(n, size=n, replace=True)
        unique = np.unique(sample)
        if len(unique) < k + 5:
            continue
        z = linkage(pdist(scores[unique], metric="euclidean"), method="ward")
        lab = fcluster(z, k, criterion="maxclust")
        for a_pos, a in enumerate(unique):
            same = unique[lab == lab[a_pos]]
            co_seen[a, unique] += 1
            co_same[a, same] += 1
    with np.errstate(invalid="ignore", divide="ignore"):
        consensus = co_same / co_seen
    tri = consensus[np.triu_indices(n, 1)]
    tri = tri[np.isfinite(tri)]
    return float(np.mean(np.maximum(tri, 1 - tri))), float(np.mean((tri < 0.1) | (tri > 0.9)))


def prism_moa_enrichment(mids, lineages, labels, module_names, scores):
    treatment = {}
    with open(ROOT / "prism_primary_treatment_info.csv", newline="") as f:
        for row in csv.DictReader(f):
            treatment[row["column_name"]] = row
    rows_by_model = {}
    with open(ROOT / "prism_primary_collapsed_lfc.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            if row[0] in set(mids):
                rows_by_model[row[0]] = row
    common = [m for m in mids if m in rows_by_model]
    pos = np.array([np.where(mids == m)[0][0] for m in common], dtype=int)
    common_labels = labels[pos]
    results = []
    for c in sorted(set(labels)):
        in_c = common_labels == c
        if in_c.sum() < 20 or (~in_c).sum() < 100:
            continue
        hits = []
        for j, col in enumerate(header[1:], start=1):
            vals = []
            in_flags = []
            for m, flag in zip(common, in_c):
                try:
                    v = float(rows_by_model[m][j])
                except Exception:
                    continue
                if np.isfinite(v):
                    vals.append(-v)
                    in_flags.append(flag)
            vals = np.array(vals)
            in_flags = np.array(in_flags, dtype=bool)
            if len(vals) < 180 or in_flags.sum() < 20:
                continue
            t, p = stats.ttest_ind(vals[in_flags], vals[~in_flags], equal_var=False)
            diff = float(np.mean(vals[in_flags]) - np.mean(vals[~in_flags]))
            info = treatment.get(col, {})
            hits.append({
                "name": info.get("name"),
                "moa": info.get("moa"),
                "target": info.get("target"),
                "phase": info.get("phase"),
                "sensitivity_in_cluster_minus_other": diff,
                "welch_p": float(p),
                "mean_sensitivity_cluster": float(np.mean(vals[in_flags])),
                "mean_sensitivity_other": float(np.mean(vals[~in_flags])),
            })
        hits.sort(key=lambda x: x["welch_p"])
        results.append({"cluster": int(c), "top_prism_differential_hits": hits[:20]})
    return results


def main():
    mids, lineages, module_names, scores, genes_found = load_module_scores()
    k_results = []
    for k in [3, 4, 5, 6]:
        labels, clusters = summarize_clusters(mids, lineages, module_names, scores, k)
        consensus_strength, hard_fraction = bootstrap_stability(scores, k)
        k_results.append({
            "k": k,
            "bootstrap_consensus_strength_mean": consensus_strength,
            "bootstrap_hard_pair_fraction": hard_fraction,
            "clusters": clusters,
        })
    chosen_k = 4
    labels, clusters = summarize_clusters(mids, lineages, module_names, scores, chosen_k)
    prism = prism_moa_enrichment(mids, lineages, labels, module_names, scores)

    corr = []
    for i, a in enumerate(module_names):
        for j, b in enumerate(module_names):
            if j <= i:
                continue
            r, p = stats.spearmanr(scores[:, i], scores[:, j])
            corr.append({"a": a, "b": b, "spearman_r": float(r), "p": float(p)})
    corr.sort(key=lambda x: abs(x["spearman_r"]), reverse=True)

    out = {
        "question": "Do pan-cancer dependency modules form distinct malignant stability regimes rather than one universal key?",
        "data_sources": [
            "DepMap 24Q4 CRISPRGeneEffect and Model.csv.",
            "PRISM Repurposing 19Q4 primary screen for cluster-differential drug sensitivity.",
        ],
        "design": "Compute within-lineage residualized module dependencies, cluster cancer models by module profile, bootstrap cluster stability, and inspect PRISM differential sensitivities by regime.",
        "n_cancer_models_with_complete_module_scores": int(len(mids)),
        "module_genes_found": genes_found,
        "module_correlation_top": corr[:30],
        "cluster_solutions": k_results,
        "chosen_k": chosen_k,
        "chosen_clusters": clusters,
        "cluster_prism_differential_hits": prism,
    }
    (ROOT / "stability_regime_map_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
