#!/usr/bin/env python3
import csv
import gzip
import json
import math
import shutil
import urllib.request
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent / "xena_cir"
ROOT.mkdir(parents=True, exist_ok=True)

EXPR_URL = "https://toil.xenahubs.net/download/TcgaTargetGtex_rsem_gene_tpm.gz"

MODULES = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1"],
    "stress_flow": ["HIF1A", "ATF4", "HSPA5", "XBP1", "HSP90AA1", "PSMA1", "PSMA2", "PSMB5", "PSMC1", "PSMD1"],
    "polyamine_flow": ["AMD1", "SMS", "SRM", "ODC1", "SAT1", "SMOX", "PAOX"],
    "tissue_governance": ["YAP1", "WWTR1", "TEAD1", "TEAD4", "LATS1", "LATS2", "NF2", "TGFB1", "TGFBR1", "TGFBR2", "SMAD2", "SMAD3", "SMAD4", "CTNNB1", "APC", "NOTCH1", "NOTCH2", "RBPJ"],
    "polarity_adhesion": ["PARD3", "PARD6A", "PRKCI", "SCRIB", "DLG1", "LLGL1", "CDH1", "CDH2", "ITGA5", "ITGB1", "VCL", "TLN1", "PXN", "PTK2"],
    "junction_bioelectric": ["GJA1", "GJB1", "GJB2", "PANX1", "ATP1A1", "ATP1B1", "KCNJ2", "KCNQ1", "CLCN3", "SLC9A1", "VDAC1"],
    "immune_visibility": ["B2M", "HLA-A", "HLA-B", "HLA-C", "TAP1", "TAP2", "NLRC5", "JAK1", "JAK2"],
}

PRIMARY_SITE_MAP = {
    "Adrenal Gland": "Adrenal Gland",
    "Bladder": "Bladder",
    "Blood": "Blood",
    "Blood Vessel": "Blood Vessel",
    "Bone Marrow": "Blood",
    "Brain": "Brain",
    "Breast": "Breast",
    "Cervix": "Cervix",
    "Colon": "Colon",
    "Endometrium": "Uterus",
    "Esophagus": "Esophagus",
    "Eye": "Eye",
    "Head and Neck region": "Head and Neck",
    "Kidney": "Kidney",
    "Liver": "Liver",
    "Lung": "Lung",
    "Ovary": "Ovary",
    "Pancreas": "Pancreas",
    "Prostate": "Prostate",
    "Rectum": "Colon",
    "Skin": "Skin",
    "Stomach": "Stomach",
    "Testis": "Testis",
    "Thyroid": "Thyroid",
    "Uterus": "Uterus",
}

DETAILED_GTEX_MAP = {
    "Adrenal Gland": "Adrenal Gland",
    "Bladder": "Bladder",
    "Artery - Aorta": "Blood Vessel",
    "Artery - Coronary": "Blood Vessel",
    "Artery - Tibial": "Blood Vessel",
    "Brain - Amygdala": "Brain",
    "Brain - Anterior cingulate cortex (BA24)": "Brain",
    "Brain - Caudate (basal ganglia)": "Brain",
    "Brain - Cerebellar Hemisphere": "Brain",
    "Brain - Cerebellum": "Brain",
    "Brain - Cortex": "Brain",
    "Brain - Frontal Cortex (BA9)": "Brain",
    "Brain - Hippocampus": "Brain",
    "Brain - Hypothalamus": "Brain",
    "Brain - Nucleus accumbens (basal ganglia)": "Brain",
    "Brain - Putamen (basal ganglia)": "Brain",
    "Brain - Spinal cord (cervical c-1)": "Brain",
    "Brain - Substantia nigra": "Brain",
    "Breast - Mammary Tissue": "Breast",
    "Cells - EBV-transformed lymphocytes": "Blood",
    "Whole Blood": "Blood",
    "Colon - Sigmoid": "Colon",
    "Colon - Transverse": "Colon",
    "Esophagus - Gastroesophageal Junction": "Esophagus",
    "Esophagus - Mucosa": "Esophagus",
    "Esophagus - Muscularis": "Esophagus",
    "Liver": "Liver",
    "Lung": "Lung",
    "Ovary": "Ovary",
    "Pancreas": "Pancreas",
    "Prostate": "Prostate",
    "Skin - Not Sun Exposed (Suprapubic)": "Skin",
    "Skin - Sun Exposed (Lower leg)": "Skin",
    "Stomach": "Stomach",
    "Testis": "Testis",
    "Thyroid": "Thyroid",
    "Uterus": "Uterus",
}


def zscore(x):
    x = np.asarray(x, dtype=float)
    s = np.nanstd(x)
    if not np.isfinite(s) or s == 0:
        return np.full(x.shape, np.nan)
    return (x - np.nanmean(x)) / s


def residualize_one(y, x):
    y = np.asarray(y, dtype=float)
    x = zscore(x)
    mask = np.isfinite(y) & np.isfinite(x)
    out = np.full(y.shape, np.nan)
    if mask.sum() < 30:
        return out
    xm = x[mask] - np.mean(x[mask])
    ym = y[mask] - np.mean(y[mask])
    denom = float(np.dot(xm, xm))
    if denom == 0:
        return out
    beta = float(np.dot(xm, ym) / denom)
    out[mask] = ym - beta * xm
    return out


def load_gene_map():
    mapping = {}
    with open(ROOT / "gencode.v23.annotation.gene.probemap") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            mapping.setdefault(row["gene"], row["id"])
    return mapping


def load_phenotype():
    rows = {}
    with gzip.open(ROOT / "TcgaTargetGTEX_phenotype.txt.gz", "rt", encoding="utf-8", errors="replace") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            study = row["_study"]
            sample_type = row["_sample_type"]
            site = None
            label = None
            if study == "TCGA" and sample_type == "Primary Tumor":
                site = PRIMARY_SITE_MAP.get(row["_primary_site"])
                label = "tumor"
            elif study == "GTEX":
                site = DETAILED_GTEX_MAP.get(row["primary disease or tissue"])
                label = "normal"
            if site and label:
                rows[row["sample"]] = {
                    "sample": row["sample"],
                    "label": label,
                    "site": site,
                    "source_site": row["_primary_site"] or row["primary disease or tissue"],
                }
    return rows


def extract_expression(ensembl_ids):
    out_path = ROOT / "selected_module_gene_expression.tsv.gz"
    if out_path.exists():
        return out_path

    wanted = set(ensembl_ids)
    req = urllib.request.Request(EXPR_URL, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=300) as response:
        with gzip.GzipFile(fileobj=response) as gz:
            with gzip.open(out_path, "wt") as out:
                header = gz.readline().decode("utf-8")
                out.write(header)
                found = 0
                for raw in gz:
                    first = raw.split(b"\t", 1)[0].decode("utf-8")
                    if first in wanted:
                        out.write(raw.decode("utf-8"))
                        found += 1
                        if found == len(wanted):
                            break
    return out_path


def benjamini_hochberg(pairs):
    pairs = [(k, p) for k, p in pairs if np.isfinite(p)]
    pairs.sort(key=lambda x: x[1])
    m = len(pairs)
    q = {}
    prev = 1.0
    for i in range(m, 0, -1):
        key, p = pairs[i - 1]
        val = min(prev, p * m / i)
        q[key] = val
        prev = val
    return q


def main():
    gene_map = load_gene_map()
    wanted_genes = sorted({g for genes in MODULES.values() for g in genes})
    gene_to_id = {g: gene_map[g] for g in wanted_genes if g in gene_map}
    id_to_gene = {v: k for k, v in gene_to_id.items()}
    expr_path = extract_expression(gene_to_id.values())

    phen = load_phenotype()
    with gzip.open(expr_path, "rt") as f:
        header = f.readline().rstrip("\n").split("\t")
        samples_all = header[1:]
        keep_idx = [i for i, s in enumerate(samples_all) if s in phen]
        samples = [samples_all[i] for i in keep_idx]
        data = {}
        for line in f:
            parts = line.rstrip("\n").split("\t")
            gene = id_to_gene.get(parts[0])
            if gene:
                data[gene] = np.array([float(parts[i + 1]) for i in keep_idx], dtype=float)

    labels = np.array([phen[s]["label"] for s in samples])
    sites = np.array([phen[s]["site"] for s in samples])
    matched_sites = sorted({
        site for site in set(sites)
        if np.sum((sites == site) & (labels == "tumor")) >= 20
        and np.sum((sites == site) & (labels == "normal")) >= 20
    })
    keep = np.array([site in matched_sites for site in sites])
    labels = labels[keep]
    sites = sites[keep]
    samples = [s for s, k in zip(samples, keep) if k]
    for gene in list(data):
        # UCSC Xena Toil RSEM TPM values are already log2(TPM + small offset).
        data[gene] = data[gene][keep]

    gene_z = {g: zscore(v) for g, v in data.items()}
    scores = {}
    found = {}
    for module, genes in MODULES.items():
        gs = [g for g in genes if g in gene_z]
        found[module] = gs
        scores[module] = np.nanmean(np.vstack([gene_z[g] for g in gs]), axis=0)

    raw_autonomy = (
        zscore(scores["stress_flow"])
        + zscore(scores["polyamine_flow"])
        - zscore(scores["tissue_governance"])
        - zscore(scores["polarity_adhesion"])
        - zscore(scores["junction_bioelectric"])
        - zscore(scores["immune_visibility"])
    )
    cir = residualize_one(raw_autonomy, scores["proliferation"])

    site_results = []
    for site in matched_sites:
        idx = sites == site
        y = labels[idx] == "tumor"
        row = {
            "site": site,
            "n_tumor": int(y.sum()),
            "n_normal": int((~y).sum()),
        }
        for name, vec in [("proliferation", scores["proliferation"]), ("raw_autonomy", raw_autonomy), ("CIR", cir)]:
            x = vec[idx]
            finite = np.isfinite(x)
            tumor_vals = x[y & finite]
            normal_vals = x[(~y) & finite]
            if len(tumor_vals) < 10 or len(normal_vals) < 10:
                row[name] = {
                    "tumor_mean": math.nan,
                    "normal_mean": math.nan,
                    "tumor_minus_normal": math.nan,
                    "auc_tumor_higher": math.nan,
                    "p": math.nan,
                }
                continue
            stat = stats.mannwhitneyu(tumor_vals, normal_vals, alternative="two-sided")
            # ROC AUC equals U/(n_pos*n_neg), oriented as tumor higher than normal.
            auc = float(stat.statistic / (len(tumor_vals) * len(normal_vals)))
            row[name] = {
                "tumor_mean": float(np.nanmean(tumor_vals)),
                "normal_mean": float(np.nanmean(normal_vals)),
                "tumor_minus_normal": float(np.nanmean(tumor_vals) - np.nanmean(normal_vals)),
                "auc_tumor_higher": auc,
                "p": float(stat.pvalue),
            }
        site_results.append(row)

    for name in ["proliferation", "raw_autonomy", "CIR"]:
        q = benjamini_hochberg([((r["site"], name), r[name]["p"]) for r in site_results])
        for r in site_results:
            r[name]["q"] = q.get((r["site"], name), math.nan)

    summary = {}
    for name in ["proliferation", "raw_autonomy", "CIR"]:
        deltas = [r[name]["tumor_minus_normal"] for r in site_results]
        aucs = [r[name]["auc_tumor_higher"] for r in site_results]
        ps = [r[name]["p"] for r in site_results]
        summary[name] = {
            "n_sites": len(site_results),
            "median_tumor_minus_normal": float(np.nanmedian(deltas)),
            "positive_sites": int(sum(d > 0 for d in deltas)),
            "negative_sites": int(sum(d < 0 for d in deltas)),
            "median_auc_tumor_higher": float(np.nanmedian(aucs)),
            "fdr_lt_0_05_positive": int(sum(r[name]["q"] < 0.05 and r[name]["tumor_minus_normal"] > 0 for r in site_results)),
            "fdr_lt_0_05_negative": int(sum(r[name]["q"] < 0.05 and r[name]["tumor_minus_normal"] < 0 for r in site_results)),
            "fisher_p": float(stats.chi2.sf(-2 * sum(math.log(max(p, 1e-300)) for p in ps), 2 * len(ps))),
        }

    out = {
        "question": "Does Cancer Irreversibility Residual distinguish primary tumors from matched normal tissues after removing proliferation?",
        "data_source": "UCSC Xena Toil recompute TCGA TARGET GTEx RSEM TPM; TCGA primary tumors vs GTEx normal tissues.",
        "predefined_modules": MODULES,
        "matched_sites": matched_sites,
        "n_samples": int(len(samples)),
        "n_tumor": int(np.sum(labels == "tumor")),
        "n_normal": int(np.sum(labels == "normal")),
        "module_genes_found": found,
        "summary": summary,
        "site_results": site_results,
        "interpretation_guardrail": "This is bulk RNA-seq tumor-vs-normal validation, not clinical treatment evidence. GTEx normals are not patient-matched adjacent normals.",
    }
    out_path = ROOT / "xena_cir_validation_results.json"
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
