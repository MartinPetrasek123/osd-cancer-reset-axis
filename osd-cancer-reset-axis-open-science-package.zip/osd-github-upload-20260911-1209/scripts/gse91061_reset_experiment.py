#!/usr/bin/env python3
import csv
import gzip
import json
import math
import re
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent
ONCO = ROOT.parent

MODULES = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1"],
    "inflammatory_alarm": ["IL6", "IL1B", "TNF", "NFKB1", "NFKB2", "RELA", "STAT3", "PTGS2", "CXCL8", "CCL2", "CXCL1", "CXCL2"],
    "interferon_alarm": ["IFNG", "IRF7", "STAT1", "ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "CXCL10", "GBP1"],
    "wound_ecm_fibrosis": ["TGFB1", "TGFBR1", "SMAD2", "SMAD3", "COL1A1", "COL1A2", "COL3A1", "FN1", "VIM", "ACTA2", "MMP2", "MMP9", "TIMP1"],
    "coagulation_complement": ["C3", "C5", "CFB", "CFH", "F2", "F3", "FGA", "FGB", "FGG", "SERPINE1", "PLAU", "PLAT"],
    "hypoxia_redox_stress": ["HIF1A", "VEGFA", "SLC2A1", "CA9", "LDHA", "NFE2L2", "HMOX1", "NQO1", "SOD2", "TXN", "PRDX1"],
    "proteostasis_er_stress": ["HSPA5", "XBP1", "ATF4", "DDIT3", "HSP90AA1", "PSMA1", "PSMB5", "PSMC1", "PSMD1"],
    "bioelectric_junction_order": ["GJA1", "GJB1", "GJB2", "PANX1", "ATP1A1", "ATP1B1", "KCNJ2", "KCNQ1", "CLCN3", "SLC9A1", "VDAC1"],
    "polarity_adhesion_order": ["PARD3", "PARD6A", "PRKCI", "SCRIB", "DLG1", "LLGL1", "CDH1", "ITGA5", "ITGB1", "VCL", "TLN1", "PXN"],
    "circadian_order": ["CLOCK", "ARNTL", "PER1", "PER2", "PER3", "CRY1", "CRY2", "NR1D1", "NR1D2", "RORA", "DBP"],
    "mitochondrial_homeostasis": ["PPARGC1A", "PPARGC1B", "NDUFS1", "NDUFV1", "SDHA", "UQCRC1", "COX4I1", "ATP5F1A", "TFAM", "SIRT3"],
    "differentiation_order": ["NOTCH1", "NOTCH2", "RBPJ", "CTNNB1", "APC", "YAP1", "WWTR1", "TEAD1", "TEAD4", "LATS1", "LATS2"],
}


def zscore(x):
    x = np.asarray(x, dtype=float)
    s = np.nanstd(x)
    if not np.isfinite(s) or s == 0:
        return np.zeros_like(x)
    return (x - np.nanmean(x)) / s


def symbol_to_entrez():
    with open(ONCO / "OmicsExpressionProteinCodingGenesTPMLogp1.csv", newline="") as f:
        header = next(csv.reader(f))
    out = {}
    for col in header[1:]:
        m = re.match(r"^(.+?) \((\d+)\)$", col)
        if m:
            out.setdefault(m.group(1), m.group(2))
    return out


def parse_series_matrix():
    meta = {}
    with gzip.open(ROOT / "GSE91061_series_matrix.txt.gz", "rt", errors="replace") as f:
        for line in f:
            if line.startswith("!Sample_title"):
                parts = [p.strip().strip('"') for p in line.rstrip("\n").split("\t")[1:]]
                for sample in parts:
                    m = re.match(r"^(Pt\d+)_(Pre|On)_", sample)
                    if m:
                        meta[sample] = {"patient": m.group(1), "visit": m.group(2)}
            elif line.startswith("!Sample_characteristics_ch1"):
                parts = [p.strip().strip('"') for p in line.rstrip("\n").split("\t")[1:]]
                if not meta:
                    continue
                keys = list(meta)
                for sample, val in zip(keys, parts):
                    if val.startswith("response:"):
                        meta[sample]["response"] = val.split(":", 1)[1].strip()
                    elif val.startswith("visit (pre or on treatment):"):
                        meta[sample]["visit"] = val.split(":", 1)[1].strip()
    return meta


def load_expression(wanted_entrez):
    path = ROOT / "GSE91061_BMS038109Sample.hg19KnownGene.rld.csv.gz"
    with gzip.open(path, "rt") as f:
        reader = csv.reader(f)
        header = next(reader)
        samples = [h.strip().strip('"') for h in header[1:]]
        data = {}
        for row in reader:
            gene_id = row[0].strip().strip('"')
            if gene_id in wanted_entrez:
                data[gene_id] = np.array([float(x) if x else math.nan for x in row[1:]], dtype=float)
    return samples, data


def module_scores(samples, data, sym2id):
    scores = {}
    found = {}
    gene_z = {eid: zscore(vals) for eid, vals in data.items()}
    for module, genes in MODULES.items():
        ids = [sym2id[g] for g in genes if g in sym2id and sym2id[g] in gene_z]
        found[module] = [g for g in genes if g in sym2id and sym2id[g] in gene_z]
        scores[module] = np.nanmean(np.vstack([gene_z[eid] for eid in ids]), axis=0)
    instability = (
        zscore(scores["inflammatory_alarm"])
        + zscore(scores["interferon_alarm"])
        + zscore(scores["wound_ecm_fibrosis"])
        + zscore(scores["coagulation_complement"])
        + zscore(scores["hypoxia_redox_stress"])
        + zscore(scores["proteostasis_er_stress"])
    )
    order = (
        zscore(scores["bioelectric_junction_order"])
        + zscore(scores["polarity_adhesion_order"])
        + zscore(scores["circadian_order"])
        + zscore(scores["mitochondrial_homeostasis"])
        + zscore(scores["differentiation_order"])
    )
    scores["instability_load"] = instability
    scores["order_capacity"] = order
    scores["organism_stability_disruption"] = instability - order
    return scores, found


def pair_changes(samples, scores, meta):
    sample_to_idx = {s: i for i, s in enumerate(samples)}
    by_patient = defaultdict(dict)
    for sample, m in meta.items():
        if sample in sample_to_idx and "response" in m:
            by_patient[m["patient"]][m["visit"]] = sample
            by_patient[m["patient"]]["response"] = m["response"]

    rows = []
    for patient, vals in sorted(by_patient.items()):
        if "Pre" not in vals or "On" not in vals:
            continue
        pre = sample_to_idx[vals["Pre"]]
        on = sample_to_idx[vals["On"]]
        row = {
            "patient": patient,
            "response": vals["response"],
            "pre_sample": vals["Pre"],
            "on_sample": vals["On"],
        }
        for name, vec in scores.items():
            row[f"{name}_pre"] = float(vec[pre])
            row[f"{name}_on"] = float(vec[on])
            row[f"{name}_change_on_minus_pre"] = float(vec[on] - vec[pre])
        rows.append(row)
    return rows


def summarize_change(rows, field):
    groups = {}
    for group_name, allowed in {
        "responders_PRCR": {"PRCR"},
        "stable_SD": {"SD"},
        "progressors_PD": {"PD"},
        "clinical_control_PRCR_SD": {"PRCR", "SD"},
        "nonresponders_PD": {"PD"},
    }.items():
        vals = np.array([r[field] for r in rows if r["response"] in allowed and np.isfinite(r[field])], dtype=float)
        if len(vals) < 3:
            groups[group_name] = {"n": int(len(vals)), "median_change": math.nan, "mean_change": math.nan, "wilcoxon_p_vs_0": math.nan}
            continue
        try:
            p = float(stats.wilcoxon(vals, alternative="two-sided").pvalue)
        except ValueError:
            p = math.nan
        groups[group_name] = {
            "n": int(len(vals)),
            "median_change": float(np.median(vals)),
            "mean_change": float(np.mean(vals)),
            "wilcoxon_p_vs_0": p,
        }

    pos = np.array([r[field] for r in rows if r["response"] in {"PRCR", "SD"}], dtype=float)
    neg = np.array([r[field] for r in rows if r["response"] == "PD"], dtype=float)
    pos = pos[np.isfinite(pos)]
    neg = neg[np.isfinite(neg)]
    if len(pos) >= 3 and len(neg) >= 3:
        mw = stats.mannwhitneyu(pos, neg, alternative="two-sided")
        groups["PRCR_SD_vs_PD"] = {
            "n_PRCR_SD": int(len(pos)),
            "n_PD": int(len(neg)),
            "delta_median_PRCR_SD_minus_PD": float(np.median(pos) - np.median(neg)),
            "p": float(mw.pvalue),
        }
    return groups


def main():
    sym2id = symbol_to_entrez()
    wanted_entrez = {sym2id[g] for genes in MODULES.values() for g in genes if g in sym2id}
    samples, data = load_expression(wanted_entrez)
    meta = parse_series_matrix()
    scores, found = module_scores(samples, data, sym2id)
    rows = pair_changes(samples, scores, meta)

    fields = [
        "organism_stability_disruption_change_on_minus_pre",
        "instability_load_change_on_minus_pre",
        "order_capacity_change_on_minus_pre",
        "interferon_alarm_change_on_minus_pre",
        "hypoxia_redox_stress_change_on_minus_pre",
        "proteostasis_er_stress_change_on_minus_pre",
        "wound_ecm_fibrosis_change_on_minus_pre",
        "circadian_order_change_on_minus_pre",
        "proliferation_change_on_minus_pre",
    ]
    summary = {field: summarize_change(rows, field) for field in fields}

    out = {
        "question": "Does anti-PD-1 treatment move tumors toward an organismic reset state in paired pre/on-treatment melanoma biopsies?",
        "data_source": "GSE91061 / Riaz et al. melanoma anti-PD-1 RNA-seq, 109 samples: 51 pre-treatment, 58 on-treatment.",
        "prediction": "Responding/stable patients should show a larger decrease in organism_stability_disruption or a favorable shift in its modules compared with progressive disease.",
        "n_paired_patients": len(rows),
        "response_counts": dict((k, sum(1 for r in rows if r["response"] == k)) for k in sorted(set(r["response"] for r in rows))),
        "module_genes_found": found,
        "summary": summary,
        "paired_rows": rows,
        "guardrail": "This is a public transcriptomic reanalysis of an immunotherapy cohort, not clinical advice or proof of a treatment protocol.",
    }
    out_path = ROOT / "gse91061_reset_experiment_results.json"
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
