#!/usr/bin/env python3
import csv
import gzip
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats

BASE = Path(__file__).resolve().parent
XENA = BASE / "xena_cir"

MODULES = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1"],
    "inflammatory_alarm": ["IL6", "IL1B", "TNF", "NFKB1", "NFKB2", "RELA", "STAT3", "PTGS2", "CXCL8", "CCL2", "CXCL1", "CXCL2"],
    "interferon_alarm": ["IFNG", "IRF7", "STAT1", "ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "CXCL10", "GBP1"],
    "wound_ecm_fibrosis": ["TGFB1", "TGFBR1", "SMAD2", "SMAD3", "COL1A1", "COL1A2", "COL3A1", "FN1", "VIM", "ACTA2", "MMP2", "MMP9", "TIMP1"],
    "coagulation_complement": ["C3", "C5", "CFB", "CFH", "F2", "F3", "FGA", "FGB", "FGG", "SERPINE1", "PLAU", "PLAT"],
    "hypoxia_redox_stress": ["HIF1A", "VEGFA", "SLC2A1", "CA9", "LDHA", "NFE2L2", "HMOX1", "NQO1", "SOD2", "TXN", "PRDX1"],
    "proteostasis_er_stress": ["HSPA5", "XBP1", "ATF4", "DDIT3", "HSP90AA1", "PSMA1", "PSMB5", "PSMC1", "PSMD1"],
    "bioelectric_junction_order": ["GJA1", "GJB1", "GJB2", "PANX1", "ATP1A1", "ATP1B1", "KCNJ2", "KCNQ1", "CLCN3", "SLC9A1", "VDAC1"],
    "polarity_adhesion_order": ["PARD3", "PARD6A", "PRKCI", "SCRIB", "DLG1", "LLGL1", "CDH1", "ITGA5", "ITGB1", "VCL", "TLN1", "PXN"],
    "circadian_order": ["CLOCK", "ARNTL", "PER1", "PER2", "PER3", "CRY1", "CRY2", "NR1D1", "NR1D2", "RORA", "DBP"],
    "mitochondrial_homeostasis": ["PPARGC1A", "PPARGC1B", "NDUFS1", "NDUFV1", "SDHA", "UQCRC1", "COX4I1", "ATP5F1A", "TFAM", "SIRT3"],
    "differentiation_order": ["NOTCH1", "NOTCH2", "RBPJ", "CTNNB1", "APC", "YAP1", "WWTR1", "TEAD1", "TEAD4", "LATS1", "LATS2"],
}


def zscore(v):
    v = np.asarray(v, dtype=float)
    s = np.nanstd(v)
    if not np.isfinite(s) or s == 0:
        return np.zeros_like(v)
    return (v - np.nanmean(v)) / s


def residualize_one(y, x):
    y = np.asarray(y, dtype=float)
    x = zscore(x)
    mask = np.isfinite(y) & np.isfinite(x)
    out = np.full(y.shape, np.nan)
    if mask.sum() < 30:
        return out
    xm = x[mask] - np.mean(x[mask])
    ym = y[mask] - np.mean(y[mask])
    denom = float(np.dot(xm, xm))
    if denom == 0:
        return out
    out[mask] = ym - float(np.dot(xm, ym) / denom) * xm
    return out


def within_site_transform(values, sites, mode):
    out = np.full(len(values), np.nan)
    for site in sorted(set(sites)):
        idx = np.where(sites == site)[0]
        if len(idx) < 30:
            continue
        if mode == "z":
            out[idx] = zscore(values[idx])
        else:
            raise ValueError(mode)
    return out


def safe_float(x):
    try:
        if x is None or str(x).strip() in {"", "NA", "N/A", "NaN", "nan"}:
            return math.nan
        return float(str(x).replace(",", ""))
    except Exception:
        return math.nan


def os_event(x):
    if x is None:
        return None
    s = str(x).strip().upper()
    if s.startswith("1:") or "DECEASED" in s or "DEAD" in s:
        return 1
    if s.startswith("0:") or "LIVING" in s or "ALIVE" in s:
        return 0
    return None


def load_tcga_survival():
    out = {}
    for path in BASE.glob("*_tcga_pan_can_atlas_2018.patient_clinical.json"):
        records = json.loads(path.read_text())
        tmp = {}
        for r in records:
            attr = r.get("clinicalAttributeId")
            if attr in {"OS_MONTHS", "OS_STATUS", "AGE"}:
                key = r.get("patientId")
                tmp.setdefault(key, {})[attr] = r.get("value")
        for patient, vals in tmp.items():
            t = safe_float(vals.get("OS_MONTHS"))
            ev = os_event(vals.get("OS_STATUS"))
            if np.isfinite(t) and t > 0 and ev is not None:
                out[patient] = {"time": t, "event": ev, "study": path.name.replace(".patient_clinical.json", "")}
    return out


def load_expression():
    expr_path = XENA / "selected_organism_reset_gene_expression.tsv.gz"
    map_path = XENA / "gencode.v23.annotation.gene.probemap"
    gene_map = {}
    with open(map_path) as f:
        for row in csv.DictReader(f, delimiter="\t"):
            gene_map.setdefault(row["id"], row["gene"])

    wanted = {g for genes in MODULES.values() for g in genes}
    with gzip.open(expr_path, "rt") as f:
        header = f.readline().rstrip("\n").split("\t")
        samples = header[1:]
        data = {}
        for line in f:
            parts = line.rstrip("\n").split("\t")
            gene = gene_map.get(parts[0])
            if gene in wanted:
                data[gene] = np.array([float(x) for x in parts[1:]], dtype=float)
    return samples, data


def stratified_cox_1d(times, events, x, strata):
    times = np.asarray(times, dtype=float)
    events = np.asarray(events, dtype=int)
    x = np.asarray(x, dtype=float)
    strata = np.asarray(strata)
    finite = np.isfinite(times) & np.isfinite(x)
    times, events, x, strata = times[finite], events[finite], x[finite], strata[finite]

    groups = []
    for st in sorted(set(strata)):
        idx = np.where(strata == st)[0]
        if len(idx) >= 40 and events[idx].sum() >= 5:
            groups.append(idx)
    if not groups:
        return None

    def grad_hess(beta):
        grad = 0.0
        hess = 0.0
        for idx in groups:
            t = times[idx]
            e = events[idx]
            xx = x[idx]
            order = np.argsort(-t)
            t, e, xx = t[order], e[order], xx[order]
            eta = beta * xx
            eta -= np.max(eta)
            w = np.exp(eta)
            cw = np.cumsum(w)
            cwx = np.cumsum(w * xx)
            cwx2 = np.cumsum(w * xx * xx)
            for et in np.unique(t[e == 1]):
                pos = np.where(t == et)[0]
                dmask = pos[e[pos] == 1]
                if len(dmask) == 0:
                    continue
                last = pos[-1]
                mean = cwx[last] / cw[last]
                var = cwx2[last] / cw[last] - mean * mean
                grad += np.sum(xx[dmask]) - len(dmask) * mean
                hess -= len(dmask) * max(var, 1e-12)
        return grad, hess

    beta = 0.0
    for _ in range(60):
        g, h = grad_hess(beta)
        step = g / (-h)
        beta += step
        if abs(step) < 1e-8:
            break
    _, h = grad_hess(beta)
    se = math.sqrt(1 / (-h))
    z = beta / se
    return {
        "beta": float(beta),
        "hr_per_sd": float(math.exp(beta)),
        "se": float(se),
        "z": float(z),
        "p": float(2 * stats.norm.sf(abs(z))),
        "n_used": int(sum(len(g) for g in groups)),
        "events_used": int(sum(events[g].sum() for g in groups)),
        "strata_used": int(len(groups)),
    }


def main():
    survival = load_tcga_survival()
    samples, data = load_expression()
    kept = []
    for i, sample in enumerate(samples):
        if not sample.startswith("TCGA-") or sample[13:15] != "01":
            continue
        patient = "-".join(sample.split("-")[:3])
        if patient in survival:
            kept.append((i, sample, patient))

    labels = [sample for _, sample, _ in kept]
    times = np.array([survival[p]["time"] for _, _, p in kept], dtype=float)
    events = np.array([survival[p]["event"] for _, _, p in kept], dtype=int)
    strata = np.array([survival[p]["study"] for _, _, p in kept])
    idxs = [i for i, _, _ in kept]

    gene_z = {g: zscore(v[idxs]) for g, v in data.items()}
    scores = {}
    found = {}
    for module, genes in MODULES.items():
        gs = [g for g in genes if g in gene_z]
        found[module] = gs
        scores[module] = np.nanmean(np.vstack([gene_z[g] for g in gs]), axis=0)

    instability_load = (
        zscore(scores["inflammatory_alarm"])
        + zscore(scores["interferon_alarm"])
        + zscore(scores["wound_ecm_fibrosis"])
        + zscore(scores["coagulation_complement"])
        + zscore(scores["hypoxia_redox_stress"])
        + zscore(scores["proteostasis_er_stress"])
    )
    order_capacity = (
        zscore(scores["bioelectric_junction_order"])
        + zscore(scores["polarity_adhesion_order"])
        + zscore(scores["circadian_order"])
        + zscore(scores["mitochondrial_homeostasis"])
        + zscore(scores["differentiation_order"])
    )
    osd_raw = instability_load - order_capacity

    # Residualize inside each cancer type so the score means "beyond proliferation for this cancer".
    osd_resid = np.full(len(osd_raw), np.nan)
    for st in sorted(set(strata)):
        ix = np.where(strata == st)[0]
        osd_resid[ix] = residualize_one(osd_raw[ix], scores["proliferation"][ix])

    tested = {
        "organism_stability_disruption_raw": zscore(osd_raw),
        "organism_stability_disruption_residual_within_cancer": within_site_transform(osd_resid, strata, "z"),
        "instability_load": zscore(instability_load),
        "order_capacity": zscore(order_capacity),
        "proliferation": zscore(scores["proliferation"]),
        "interferon_alarm": zscore(scores["interferon_alarm"]),
        "proteostasis_er_stress": zscore(scores["proteostasis_er_stress"]),
        "hypoxia_redox_stress": zscore(scores["hypoxia_redox_stress"]),
        "circadian_order": zscore(scores["circadian_order"]),
    }

    results = {}
    for name, x in tested.items():
        results[name] = stratified_cox_1d(times, events, x, strata)

    rng = np.random.default_rng(20260910)
    target = tested["organism_stability_disruption_residual_within_cancer"]
    observed = results["organism_stability_disruption_residual_within_cancer"]
    perm_z = []
    for _ in range(500):
        xp = target.copy()
        for st in sorted(set(strata)):
            ix = np.where(strata == st)[0]
            xp[ix] = rng.permutation(xp[ix])
        r = stratified_cox_1d(times, events, xp, strata)
        if r:
            perm_z.append(r["z"])
    perm_z = np.asarray(perm_z, dtype=float)
    empirical_p = float((np.sum(np.abs(perm_z) >= abs(observed["z"])) + 1) / (len(perm_z) + 1))

    boot_hr = []
    valid_strata = []
    for st in sorted(set(strata)):
        ix = np.where(strata == st)[0]
        if len(ix) >= 40 and events[ix].sum() >= 5:
            valid_strata.append(ix)
    for _ in range(300):
        sample_ix = np.concatenate([rng.choice(ix, size=len(ix), replace=True) for ix in valid_strata])
        r = stratified_cox_1d(times[sample_ix], events[sample_ix], target[sample_ix], strata[sample_ix])
        if r and np.isfinite(r["hr_per_sd"]):
            boot_hr.append(r["hr_per_sd"])
    boot_hr = np.asarray(boot_hr, dtype=float)

    per_cancer = []
    x = tested["organism_stability_disruption_residual_within_cancer"]
    for st in sorted(set(strata)):
        ix = np.where(strata == st)[0]
        if len(ix) < 80 or events[ix].sum() < 10:
            continue
        r = stratified_cox_1d(times[ix], events[ix], zscore(x[ix]), np.array([st] * len(ix)))
        if r:
            per_cancer.append({"study": st, "n": int(len(ix)), "events": int(events[ix].sum()), **r})

    out = {
        "question": "Does organism-level stability disruption predict overall survival in TCGA after removing proliferation within cancer type?",
        "data_sources": [
            "UCSC Xena Toil TCGA expression selected organism-reset genes",
            "cBioPortal TCGA PanCancer Atlas clinical overall survival",
        ],
        "n_tcga_primary_tumor_samples_matched": int(len(kept)),
        "events": int(events.sum()),
        "module_genes_found": found,
        "stratified_cox_by_cancer_type": results,
        "robustness_for_residual_axis": {
            "within_cancer_permutations": {
                "n": int(len(perm_z)),
                "seed": 20260910,
                "observed_z": float(observed["z"]),
                "max_abs_permuted_z": float(np.max(np.abs(perm_z))),
                "empirical_two_sided_p": empirical_p,
            },
            "stratified_bootstrap_hr": {
                "n": int(len(boot_hr)),
                "seed": 20260910,
                "median_hr": float(np.median(boot_hr)),
                "ci_2_5": float(np.percentile(boot_hr, 2.5)),
                "ci_97_5": float(np.percentile(boot_hr, 97.5)),
            },
        },
        "per_cancer_osd_residual_results": per_cancer,
        "guardrail": "Association with survival is not treatment evidence. It only tests whether the stability-disruption axis has clinical signal.",
    }
    out_path = BASE / "organism_reset_axis_survival_results.json"
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
