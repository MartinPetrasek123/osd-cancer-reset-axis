#!/usr/bin/env python3
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent
RNG_SEED = 20260910
MIN_TISSUE_N = 10
MIN_DRUG_N = 180
N_PERM_TOP = 1000

EXPRESSION_SETS = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1", "AURKA", "AURKB"],
    "stemness_dedifferentiation": ["SOX2", "NANOG", "POU5F1", "KLF4", "MYC", "PROM1", "CD44", "ALDH1A1"],
    "emt_invasion": ["VIM", "FN1", "ZEB1", "ZEB2", "SNAI1", "SNAI2", "TWIST1", "MMP2", "MMP9"],
    "stress_adaptation": ["HIF1A", "ATF4", "DDIT3", "XBP1", "HSPA5", "HSP90AA1", "HSP90AB1", "SQSTM1"],
    "anti_apoptosis": ["BCL2", "BCL2L1", "MCL1", "XIAP", "BIRC5"],
    "immune_visibility_low": ["B2M", "HLA-A", "HLA-B", "HLA-C", "TAP1", "TAP2", "NLRC5"],
}


def gene_symbol(header_name):
    return header_name.split(" (", 1)[0]


def rank_norm(x):
    x = np.asarray(x, dtype=float)
    mask = np.isfinite(x)
    out = np.full(x.shape, np.nan)
    if mask.sum() < 3:
        return out
    ranks = stats.rankdata(x[mask], method="average")
    u = (ranks - 0.5) / mask.sum()
    out[mask] = stats.norm.ppf(u)
    return out


def bh_fdr(pvals):
    p = np.asarray(pvals, dtype=float)
    q = np.full(p.shape, np.nan)
    mask = np.isfinite(p)
    vals = p[mask]
    order = np.argsort(vals)
    ranked = vals[order]
    n = len(ranked)
    adj = np.empty(n)
    prev = 1.0
    for i in range(n - 1, -1, -1):
        val = min(prev, ranked[i] * n / (i + 1))
        adj[i] = val
        prev = val
    restored = np.empty(n)
    restored[order] = adj
    q[mask] = restored
    return q


def load_prism_tissue():
    tissue = {}
    with open(ROOT / "prism_primary_cell_line_info.csv", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("depmap_id") and row.get("primary_tissue"):
                tissue[row["depmap_id"]] = row["primary_tissue"]
    return tissue


def load_prism_treatments():
    info = {}
    with open(ROOT / "prism_primary_treatment_info.csv", newline="") as f:
        for row in csv.DictReader(f):
            info[row["column_name"]] = {
                "name": row.get("name"),
                "broad_id": row.get("broad_id"),
                "dose": row.get("dose"),
                "moa": row.get("moa"),
                "target": row.get("target"),
                "phase": row.get("phase"),
                "disease_area": row.get("disease.area"),
                "indication": row.get("indication"),
            }
    return info


def load_expression_scores(models):
    wanted = sorted({g for genes in EXPRESSION_SETS.values() for g in genes})
    wanted_set = set(wanted)
    model_set = set(models)
    expr_by_model = {}
    with open(ROOT / "OmicsExpressionProteinCodingGenesTPMLogp1.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        idx_to_gene = {i: gene_symbol(h) for i, h in enumerate(header[1:], start=1) if gene_symbol(h) in wanted_set}
        for row in reader:
            mid = row[0]
            if mid not in model_set:
                continue
            vals = {}
            for i, g in idx_to_gene.items():
                try:
                    vals[g] = float(row[i])
                except Exception:
                    vals[g] = math.nan
            expr_by_model[mid] = vals
    scores = {}
    found = {}
    for set_name, genes in EXPRESSION_SETS.items():
        found[set_name] = [g for g in genes if any(g in expr_by_model.get(m, {}) for m in models)]
    for mid in models:
        vals = expr_by_model.get(mid, {})
        s = {}
        for set_name, genes in EXPRESSION_SETS.items():
            arr = [vals.get(g, math.nan) for g in genes]
            s[set_name] = float(np.nanmean(arr)) if np.isfinite(arr).any() else math.nan
        scores[mid] = s
    return scores, found


def load_mutation_burden(models):
    out = {}
    model_set = set(models)
    with open(ROOT / "OmicsSomaticMutationsMatrixDamaging.csv", newline="") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            if row[0] not in model_set:
                continue
            vals = np.array([float(x) if x else 0.0 for x in row[1:]], dtype=float)
            out[row[0]] = float(np.nansum(vals))
    return out


def load_cn_instability(models):
    out = {}
    model_set = set(models)
    with open(ROOT / "OmicsAbsoluteCNGene.csv", newline="") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            if row[0] not in model_set:
                continue
            vals = np.array([float(x) if x else np.nan for x in row[1:]], dtype=float)
            v = vals[np.isfinite(vals)]
            if len(v) < 1000:
                continue
            frac_alt = np.mean(np.abs(v - 2.0) >= 0.5)
            mad = np.mean(np.abs(v - 2.0))
            high = np.mean((v <= 1.0) | (v >= 4.0))
            out[row[0]] = float(np.mean([frac_alt, mad, high]))
    return out


def tissue_residualize(values, tissues):
    values = np.asarray(values, dtype=float)
    tissues = np.asarray(tissues)
    out = np.full(values.shape, np.nan)
    for t in sorted(set(tissues)):
        idx = np.where(tissues == t)[0]
        if len(idx) < MIN_TISSUE_N:
            continue
        v = values[idx]
        mu = np.nanmean(v)
        sd = np.nanstd(v)
        if np.isfinite(sd) and sd > 0:
            out[idx] = (v - mu) / sd
    return out


def safe_spearman(x, y):
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < MIN_DRUG_N:
        return math.nan, math.nan, int(mask.sum())
    r, p = stats.spearmanr(x[mask], y[mask])
    return float(r), float(p), int(mask.sum())


def broadness(x, y, tissues):
    rows = []
    for t in sorted(set(tissues)):
        idx = np.where(np.asarray(tissues) == t)[0]
        mask = np.isfinite(x[idx]) & np.isfinite(y[idx])
        if mask.sum() < MIN_TISSUE_N:
            continue
        r, p = stats.spearmanr(x[idx][mask], y[idx][mask])
        rows.append({"tissue": t, "n": int(mask.sum()), "r": float(r), "p": float(p)})
    pos = sum(1 for row in rows if row["r"] > 0)
    neg = sum(1 for row in rows if row["r"] < 0)
    return pos, neg, rows


def permutation_p(x, y, tissues, observed_r, rng):
    mask = np.isfinite(x) & np.isfinite(y)
    x0 = x[mask]
    y0 = y[mask]
    t0 = np.asarray(tissues)[mask]
    hits = 0
    obs = abs(observed_r)
    for _ in range(N_PERM_TOP):
        yp = y0.copy()
        for t in sorted(set(t0)):
            idx = np.where(t0 == t)[0]
            yp[idx] = rng.permutation(yp[idx])
        rp, _ = stats.spearmanr(x0, yp)
        if abs(rp) >= obs:
            hits += 1
    return float((hits + 1) / (N_PERM_TOP + 1))


def main():
    rng = np.random.default_rng(RNG_SEED)
    tissue_map = load_prism_tissue()
    treatments = load_prism_treatments()

    with open(ROOT / "prism_primary_collapsed_lfc.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        prism_models = [row[0] for row in reader]

    models = sorted(set(prism_models) & set(tissue_map))
    expr_scores, expr_found = load_expression_scores(models)
    mut = load_mutation_burden(models)
    cn = load_cn_instability(models)
    models = [m for m in models if m in expr_scores and m in mut and m in cn]
    tissues = np.array([tissue_map[m] for m in models])

    component_raw = defaultdict(list)
    for m in models:
        component_raw["proliferation"].append(expr_scores[m]["proliferation"])
        component_raw["stemness_dedifferentiation"].append(expr_scores[m]["stemness_dedifferentiation"])
        component_raw["emt_invasion"].append(expr_scores[m]["emt_invasion"])
        component_raw["stress_adaptation"].append(expr_scores[m]["stress_adaptation"])
        component_raw["anti_apoptosis"].append(expr_scores[m]["anti_apoptosis"])
        component_raw["low_immune_visibility"].append(-expr_scores[m]["immune_visibility_low"])
        component_raw["copy_number_instability"].append(cn[m])
        component_raw["damaging_mutation_burden"].append(mut[m])

    components = {}
    for name, vals in component_raw.items():
        components[name] = tissue_residualize(rank_norm(vals), tissues)
    cai = np.nanmean(np.vstack([components[k] for k in sorted(components)]), axis=0)
    cai = tissue_residualize(cai, tissues)

    model_index = {m: i for i, m in enumerate(models)}
    drug_rows = []
    with open(ROOT / "prism_primary_collapsed_lfc.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        colnames = header[1:]
        data_rows = []
        for row in reader:
            if row[0] in model_index:
                data_rows.append(row)
        for j, col in enumerate(colnames, start=1):
            y = np.full(len(models), np.nan)
            for row in data_rows:
                i = model_index[row[0]]
                try:
                    y[i] = -float(row[j])
                except Exception:
                    pass
            y = tissue_residualize(y, tissues)
            r, p, n = safe_spearman(cai, y)
            if not np.isfinite(r):
                continue
            pos, neg, tissue_rows = broadness(cai, y, tissues)
            meta = treatments.get(col, {})
            drug_rows.append({
                "column_name": col,
                "n": n,
                "spearman_r_autonomy_vs_sensitivity": r,
                "spearman_p": p,
                "positive_tissues": pos,
                "negative_tissues": neg,
                "tissues_tested": pos + neg,
                **meta,
                "top_tissue_effects": sorted(tissue_rows, key=lambda z: abs(z["r"]), reverse=True)[:8],
            })

    qs = bh_fdr([row["spearman_p"] for row in drug_rows])
    for row, q in zip(drug_rows, qs):
        row["bh_fdr"] = float(q)
    drug_rows.sort(key=lambda row: row["spearman_p"])

    for row in drug_rows[:40]:
        y = np.full(len(models), np.nan)
        col_idx = header.index(row["column_name"])
        with open(ROOT / "prism_primary_collapsed_lfc.csv", newline="") as f:
            reader = csv.reader(f)
            next(reader)
            for record in reader:
                if record[0] in model_index:
                    try:
                        y[model_index[record[0]]] = -float(record[col_idx])
                    except Exception:
                        pass
        y = tissue_residualize(y, tissues)
        row["within_tissue_permutation_p"] = permutation_p(cai, y, tissues, row["spearman_r_autonomy_vs_sensitivity"], rng)

    comp_corr = []
    for name, vals in components.items():
        r, p, n = safe_spearman(cai, vals)
        comp_corr.append({"component": name, "r_with_cai": r, "p": p, "n": n})

    out = {
        "data_sources": [
            "DepMap 24Q4 Public: expression, damaging mutations, absolute copy number.",
            "PRISM Repurposing 19Q4 primary replicate-collapsed log-fold-change drug screen.",
        ],
        "primary_question": "Does a pre-specified Cancer Autonomy Index identify broad PRISM compounds whose sensitivity rises across tissue-residualized pan-cancer models?",
        "design": {
            "cancer_autonomy_index": "Mean of tissue-residualized rank-normalized components: proliferation, stemness/dedifferentiation, EMT/invasion, stress adaptation, anti-apoptosis, low immune visibility, copy-number instability, damaging mutation burden.",
            "drug_sensitivity": "Negative PRISM log2 fold-change; higher means stronger growth inhibition/killing.",
            "controls": "Both CAI and drug sensitivity are residualized within primary tissue; p-values are FDR-corrected across all PRISM primary treatments; top hits receive within-tissue permutation p-values.",
        },
        "n_models": len(models),
        "n_tissues": int(len(set(tissues))),
        "expression_genes_found": expr_found,
        "component_correlations_with_cai": comp_corr,
        "n_drugs_tested": len(drug_rows),
        "top_drug_hits": drug_rows[:60],
    }
    (ROOT / "prism_cancer_autonomy_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
