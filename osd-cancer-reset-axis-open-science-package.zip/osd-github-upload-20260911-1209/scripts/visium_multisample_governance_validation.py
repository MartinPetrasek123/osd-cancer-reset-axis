#!/usr/bin/env python3
import csv
import gzip
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats
from scipy.io import mmread
from scipy.spatial import cKDTree

BASE = Path(__file__).resolve().parent

SAMPLES = [
    {
        "id": "V1_Breast_Cancer_Block_A_Section_1",
        "path": BASE / "visium_breast",
        "class": "tumor",
        "source": "10x Genomics Visium, Space Ranger 1.1.0",
    },
    {
        "id": "V1_Breast_Cancer_Block_A_Section_2",
        "path": BASE / "visium_validation" / "V1_Breast_Cancer_Block_A_Section_2",
        "class": "tumor",
        "source": "10x Genomics Visium, Space Ranger 1.1.0",
    },
    {
        "id": "Visium_FFPE_Human_Breast_Cancer",
        "path": BASE / "visium_validation" / "Visium_FFPE_Human_Breast_Cancer",
        "class": "tumor",
        "source": "10x Genomics Visium FFPE, Space Ranger 1.3.0",
    },
    {
        "id": "Visium_FFPE_Human_Prostate_Cancer",
        "path": BASE / "visium_validation" / "Visium_FFPE_Human_Prostate_Cancer",
        "class": "tumor",
        "source": "10x Genomics Visium FFPE, Space Ranger 1.3.0",
    },
    {
        "id": "CytAssist_FFPE_Human_Breast_Cancer",
        "path": BASE / "visium_validation" / "CytAssist_FFPE_Human_Breast_Cancer",
        "class": "tumor",
        "source": "10x Genomics CytAssist FFPE, Space Ranger 2.0.0",
    },
    {
        "id": "V1_Human_Lymph_Node",
        "path": BASE / "visium_validation" / "V1_Human_Lymph_Node",
        "class": "non_tumor_control",
        "source": "10x Genomics Visium normal lymph node, Space Ranger 1.1.0",
    },
]

MODULES = {
    "malignant_pressure": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1", "VIM", "FN1", "ZEB1", "SNAI2", "HIF1A", "ATF4", "BCL2L1", "MCL1"],
    "tissue_governance": ["YAP1", "WWTR1", "TEAD1", "TEAD4", "LATS1", "LATS2", "NF2", "TGFB1", "TGFBR1", "TGFBR2", "SMAD2", "SMAD3", "SMAD4", "CTNNB1", "APC", "NOTCH1", "NOTCH2", "RBPJ"],
    "polarity_adhesion": ["PARD3", "PARD6A", "PRKCI", "SCRIB", "DLG1", "LLGL1", "CDH1", "CDH2", "ITGA5", "ITGB1", "VCL", "TLN1", "PXN", "PTK2"],
    "junction_bioelectric": ["GJA1", "GJB1", "GJB2", "PANX1", "ATP1A1", "ATP1B1", "KCNH2", "KCNJ2", "KCNQ1", "CLCN3", "SLC9A1", "VDAC1"],
    "immune_visibility": ["B2M", "HLA-A", "HLA-B", "HLA-C", "TAP1", "TAP2", "NLRC5", "JAK1", "JAK2", "STING1"],
    "polyamine_flow": ["AMD1", "SMS", "SRM", "ODC1", "SAT1", "SMOX", "PAOX"],
    "proteostasis_flow": ["PSMA1", "PSMA2", "PSMA3", "PSMA6", "PSMB1", "PSMB3", "PSMB5", "PSMC1", "PSMD1", "HSP90AA1", "HSPA5", "XBP1"],
}


def read_lines_gz(path):
    with gzip.open(path, "rt") as f:
        return [line.rstrip("\n") for line in f]


def zscore(x):
    x = np.asarray(x, dtype=float)
    m = np.nanmean(x)
    s = np.nanstd(x)
    if not np.isfinite(s) or s == 0:
        return np.full(x.shape, np.nan)
    return (x - m) / s


def safe_spearman(x, y):
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 30:
        return math.nan, math.nan, int(mask.sum())
    r, p = stats.spearmanr(x[mask], y[mask])
    return float(r), float(p), int(mask.sum())


def residualize(y, *xs):
    if len(xs) != 1:
        raise ValueError("This validation script only residualizes one predictor.")
    y = np.asarray(y, dtype=float)
    x = zscore(np.asarray(xs[0], dtype=float))
    mask = np.isfinite(y) & np.isfinite(x)
    out = np.full(y.shape, np.nan)
    if mask.sum() < 30:
        return out
    xm = x[mask] - np.mean(x[mask])
    ym = y[mask] - np.mean(y[mask])
    denom = float(np.dot(xm, xm))
    if denom == 0 or not np.isfinite(denom):
        return out
    beta = float(np.dot(xm, ym) / denom)
    out[mask] = ym - beta * xm
    return out


def fisher_method(p_values):
    vals = [p for p in p_values if np.isfinite(p) and p > 0]
    if not vals:
        return math.nan
    stat = -2 * sum(math.log(p) for p in vals)
    return float(stats.chi2.sf(stat, 2 * len(vals)))


def stouffer_signed(rs, ns):
    z_vals = []
    weights = []
    for r, n in zip(rs, ns):
        if not np.isfinite(r) or n <= 3:
            continue
        r = max(min(r, 0.999999), -0.999999)
        z_vals.append(math.atanh(r) * math.sqrt(n - 3))
        weights.append(math.sqrt(n))
    if not z_vals:
        return {"z": math.nan, "p_two_sided": math.nan}
    z = float(np.dot(z_vals, weights) / math.sqrt(np.dot(weights, weights)))
    return {"z": z, "p_two_sided": float(2 * stats.norm.sf(abs(z)))}


def find_cluster_file(root):
    candidates = [
        root / "analysis" / "clustering" / "graphclust" / "clusters.csv",
        root / "analysis" / "clustering" / "gene_expression_graphclust" / "clusters.csv",
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(f"No graphclust clusters.csv found under {root}")


def read_positions(root):
    path = root / "spatial" / "tissue_positions.csv"
    if path.exists():
        coords = {}
        with open(path, newline="") as f:
            for row in csv.DictReader(f):
                if row["in_tissue"] == "1":
                    coords[row["barcode"]] = (
                        float(row["pxl_col_in_fullres"]),
                        float(row["pxl_row_in_fullres"]),
                    )
        return coords

    path = root / "spatial" / "tissue_positions_list.csv"
    coords = {}
    with open(path, newline="") as f:
        for row in csv.reader(f):
            barcode, in_tissue, _array_row, _array_col, px_row, px_col = row
            if in_tissue == "1":
                coords[barcode] = (float(px_col), float(px_row))
    return coords


def analyze_sample(sample):
    root = sample["path"]
    features = []
    with gzip.open(root / "filtered_feature_bc_matrix" / "features.tsv.gz", "rt") as f:
        for row in csv.reader(f, delimiter="\t"):
            features.append(row[1])
    barcodes = read_lines_gz(root / "filtered_feature_bc_matrix" / "barcodes.tsv.gz")
    gene_to_idx = {}
    for i, gene in enumerate(features):
        gene_to_idx.setdefault(gene, i)

    wanted = sorted({g for genes in MODULES.values() for g in genes if g in gene_to_idx})
    wanted_idx = [gene_to_idx[g] for g in wanted]
    mat = mmread(str(root / "filtered_feature_bc_matrix" / "matrix.mtx.gz")).tocsr()
    sub = mat[wanted_idx, :].astype(float).toarray()
    totals = np.asarray(mat.sum(axis=0)).ravel()
    norm = np.log1p((sub / np.maximum(totals, 1)) * 10000.0)
    gene_expr = {g: norm[i] for i, g in enumerate(wanted)}

    coords = read_positions(root)
    clusters = {}
    with open(find_cluster_file(root), newline="") as f:
        for row in csv.DictReader(f):
            clusters[row["Barcode"]] = int(row["Cluster"])

    keep = [i for i, b in enumerate(barcodes) if b in coords and b in clusters]
    kept_barcodes = [barcodes[i] for i in keep]
    xy = np.array([coords[b] for b in kept_barcodes], dtype=float)
    cluster = np.array([clusters[b] for b in kept_barcodes], dtype=int)

    module_scores = {}
    module_found = {}
    for module, genes in MODULES.items():
        found = [g for g in genes if g in gene_expr]
        module_found[module] = found
        vals = np.vstack([zscore(gene_expr[g][keep]) for g in found])
        module_scores[module] = np.nanmean(vals, axis=0)

    malignant = module_scores["malignant_pressure"]
    cluster_malignancy = {
        int(c): float(np.nanmean(malignant[cluster == c]))
        for c in sorted(set(cluster))
    }
    cutoff = np.nanpercentile(list(cluster_malignancy.values()), 75)
    malignant_clusters = {c for c, v in cluster_malignancy.items() if v >= cutoff}
    malignant_mask = np.array([c in malignant_clusters for c in cluster], dtype=bool)
    if malignant_mask.sum() == 0 or (~malignant_mask).sum() == 0:
        raise ValueError(f"Could not define boundary for {sample['id']}")

    tree_mal = cKDTree(xy[malignant_mask])
    tree_other = cKDTree(xy[~malignant_mask])
    dist_to_mal = tree_mal.query(xy, k=1)[0]
    dist_to_other = tree_other.query(xy, k=1)[0]
    signed_distance = dist_to_mal.copy()
    signed_distance[malignant_mask] = -dist_to_other[malignant_mask]

    abs_dist = np.abs(signed_distance)
    boundary_mask = abs_dist <= np.nanpercentile(abs_dist, 35)
    tumor_core_mask = signed_distance < -np.nanpercentile(abs_dist, 65)
    outside_mask = signed_distance > np.nanpercentile(abs_dist, 65)

    gradients = {}
    for module, score in module_scores.items():
        r, p, n = safe_spearman(signed_distance, score)
        gradients[module] = {
            "r": r,
            "p": p,
            "n": n,
            "mean_core": float(np.nanmean(score[tumor_core_mask])),
            "mean_boundary": float(np.nanmean(score[boundary_mask])),
            "mean_outside": float(np.nanmean(score[outside_mask])),
            "outside_minus_core": float(np.nanmean(score[outside_mask]) - np.nanmean(score[tumor_core_mask])),
        }

    autonomy = (
        zscore(module_scores["malignant_pressure"])
        + zscore(module_scores["proteostasis_flow"])
        + zscore(module_scores["polyamine_flow"])
        - zscore(module_scores["tissue_governance"])
        - zscore(module_scores["polarity_adhesion"])
        - zscore(module_scores["junction_bioelectric"])
        - zscore(module_scores["immune_visibility"])
    )
    r, p, n = safe_spearman(signed_distance, autonomy)
    gradients["autonomy_composite"] = {
        "r": r,
        "p": p,
        "n": n,
        "mean_core": float(np.nanmean(autonomy[tumor_core_mask])),
        "mean_boundary": float(np.nanmean(autonomy[boundary_mask])),
        "mean_outside": float(np.nanmean(autonomy[outside_mask])),
        "outside_minus_core": float(np.nanmean(autonomy[outside_mask]) - np.nanmean(autonomy[tumor_core_mask])),
    }

    autonomy_residual = residualize(autonomy, module_scores["malignant_pressure"])
    r, p, n = safe_spearman(signed_distance, autonomy_residual)
    gradients["autonomy_residual_after_malignant_pressure"] = {
        "r": r,
        "p": p,
        "n": n,
        "mean_core": float(np.nanmean(autonomy_residual[tumor_core_mask])),
        "mean_boundary": float(np.nanmean(autonomy_residual[boundary_mask])),
        "mean_outside": float(np.nanmean(autonomy_residual[outside_mask])),
        "outside_minus_core": float(np.nanmean(autonomy_residual[outside_mask]) - np.nanmean(autonomy_residual[tumor_core_mask])),
    }

    return {
        "id": sample["id"],
        "class": sample["class"],
        "source": sample["source"],
        "n_spots": int(len(kept_barcodes)),
        "n_clusters": int(len(set(cluster))),
        "malignant_clusters_by_predefined_rule": sorted(int(c) for c in malignant_clusters),
        "module_genes_found": module_found,
        "gradients": gradients,
    }


def summarize(results):
    modules = list(MODULES) + ["autonomy_composite", "autonomy_residual_after_malignant_pressure"]
    summary = {}
    tumor = [r for r in results if r["class"] == "tumor"]
    controls = [r for r in results if r["class"] != "tumor"]
    for group_name, group in [("tumor", tumor), ("non_tumor_control", controls), ("all", results)]:
        summary[group_name] = {}
        for module in modules:
            rs = [r["gradients"][module]["r"] for r in group]
            ps = [r["gradients"][module]["p"] for r in group]
            ns = [r["gradients"][module]["n"] for r in group]
            deltas = [r["gradients"][module]["outside_minus_core"] for r in group]
            summary[group_name][module] = {
                "n_samples": len(group),
                "median_r": float(np.nanmedian(rs)) if rs else math.nan,
                "mean_r": float(np.nanmean(rs)) if rs else math.nan,
                "sign_consistency_negative": int(sum(1 for r in rs if np.isfinite(r) and r < 0)),
                "sign_consistency_positive": int(sum(1 for r in rs if np.isfinite(r) and r > 0)),
                "median_outside_minus_core": float(np.nanmedian(deltas)) if deltas else math.nan,
                "fisher_p": fisher_method(ps),
                "stouffer": stouffer_signed(rs, ns),
            }
    return summary


def main():
    results = [analyze_sample(sample) for sample in SAMPLES]
    out = {
        "question": "Multisample validation of a spatial cancer-autonomy / tissue-governance boundary signature.",
        "pre_registered_rule": "Within each section, define tumor-like clusters as the top quartile of graph clusters by the same malignant-pressure expression module; compute signed distance outward and test fixed modules against that distance.",
        "major_limitations": [
            "10x public examples are convenience data, not a balanced clinical cohort.",
            "Tumor-like clusters are inferred from expression, not pathologist-drawn tumor masks.",
            "Samples are mostly breast/prostate; this is not yet all-cancer validation.",
            "A normal lymph node is a negative technical control, not matched normal tissue.",
        ],
        "samples": results,
        "summary": summarize(results),
    }
    out_path = BASE / "visium_multisample_governance_validation_results.json"
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
