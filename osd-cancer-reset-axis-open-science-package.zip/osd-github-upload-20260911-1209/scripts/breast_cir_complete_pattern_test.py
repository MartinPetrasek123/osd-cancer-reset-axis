#!/usr/bin/env python3
import csv
import json
import math
import re
from collections import Counter
from pathlib import Path

import numpy as np
from scipy import stats
from scipy.cluster.vq import kmeans2

ROOT = Path(__file__).resolve().parent

MODULES = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1"],
    "stress_flow": ["HIF1A", "ATF4", "HSPA5", "XBP1", "HSP90AA1", "PSMA1", "PSMA2", "PSMB5", "PSMC1", "PSMD1"],
    "polyamine_flow": ["AMD1", "SMS", "SRM", "ODC1", "SAT1", "SMOX", "PAOX"],
    "tissue_governance": ["YAP1", "WWTR1", "TEAD1", "TEAD4", "LATS1", "LATS2", "NF2", "TGFB1", "TGFBR1", "TGFBR2", "SMAD2", "SMAD3", "SMAD4", "CTNNB1", "APC", "NOTCH1", "NOTCH2", "RBPJ"],
    "polarity_adhesion": ["PARD3", "PARD6A", "PRKCI", "SCRIB", "DLG1", "LLGL1", "CDH1", "CDH2", "ITGA5", "ITGB1", "VCL", "TLN1", "PXN", "PTK2"],
    "junction_bioelectric": ["GJA1", "GJB1", "GJB2", "PANX1", "ATP1A1", "ATP1B1", "KCNJ2", "KCNQ1", "CLCN3", "SLC9A1", "VDAC1"],
    "immune_visibility": ["B2M", "HLA-A", "HLA-B", "HLA-C", "TAP1", "TAP2", "NLRC5", "JAK1", "JAK2"],
}


def gene_name(col):
    m = re.match(r"^(.+?) \(\d+\)$", col)
    return m.group(1) if m else col


def zscore(x):
    x = np.asarray(x, dtype=float)
    s = np.nanstd(x)
    if not np.isfinite(s) or s == 0:
        return np.full(x.shape, np.nan)
    return (x - np.nanmean(x)) / s


def residualize_one(y, x):
    y = np.asarray(y, dtype=float)
    x = zscore(x)
    mask = np.isfinite(y) & np.isfinite(x)
    out = np.full(y.shape, np.nan)
    if mask.sum() < 15:
        return out
    xm = x[mask] - np.mean(x[mask])
    ym = y[mask] - np.mean(y[mask])
    denom = float(np.dot(xm, xm))
    if denom == 0:
        return out
    out[mask] = ym - float(np.dot(xm, ym) / denom) * xm
    return out


def safe_spearman(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 10:
        return math.nan, math.nan, int(mask.sum())
    r, p = stats.spearmanr(x[mask], y[mask])
    return float(r), float(p), int(mask.sum())


def bh_q(pairs):
    vals = [(k, p) for k, p in pairs if np.isfinite(p)]
    vals.sort(key=lambda x: x[1])
    m = len(vals)
    out = {}
    prev = 1.0
    for i in range(m, 0, -1):
        k, p = vals[i - 1]
        q = min(prev, p * m / i)
        out[k] = q
        prev = q
    return out


def classify_subtype(features):
    f = (features or "").lower()
    if "tnbc" in f or "basal" in f:
        return "TNBC_basal"
    if "her2" in f:
        return "HER2"
    if "er+" in f or "luminal" in f or "pr+" in f:
        return "ER_luminal"
    return "other_unknown"


def load_models():
    models = {}
    with open(ROOT / "Model.csv", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("OncotreeLineage") != "Breast":
                continue
            if row.get("OncotreePrimaryDisease") == "Non-Cancerous":
                continue
            subtype = classify_subtype(row.get("ModelSubtypeFeatures", ""))
            models[row["ModelID"]] = {
                "model_id": row["ModelID"],
                "name": row.get("StrippedCellLineName", ""),
                "subtype": subtype,
                "features": row.get("ModelSubtypeFeatures", ""),
                "disease": row.get("OncotreePrimaryDisease", ""),
            }
    return models


def load_expression(model_ids):
    wanted = sorted({g for genes in MODULES.values() for g in genes})
    rows = {}
    with open(ROOT / "OmicsExpressionProteinCodingGenesTPMLogp1.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        gene_to_col = {gene_name(c): i for i, c in enumerate(header) if gene_name(c) in wanted}
        for row in reader:
            if row[0] in model_ids:
                rows[row[0]] = {g: float(row[i]) if row[i] else math.nan for g, i in gene_to_col.items()}
    model_order = sorted(rows)
    expr = {g: np.array([rows[m].get(g, math.nan) for m in model_order], dtype=float) for g in gene_to_col}
    return model_order, expr


def compute_scores(expr):
    gene_z = {g: zscore(v) for g, v in expr.items()}
    scores = {}
    found = {}
    for module, genes in MODULES.items():
        gs = [g for g in genes if g in gene_z]
        found[module] = gs
        scores[module] = np.nanmean(np.vstack([gene_z[g] for g in gs]), axis=0)
    raw = (
        zscore(scores["stress_flow"])
        + zscore(scores["polyamine_flow"])
        - zscore(scores["tissue_governance"])
        - zscore(scores["polarity_adhesion"])
        - zscore(scores["junction_bioelectric"])
        - zscore(scores["immune_visibility"])
    )
    cir = residualize_one(raw, scores["proliferation"])
    scores["raw_autonomy"] = raw
    scores["CIR"] = cir
    return scores, found


def load_feature_matrix(path, model_order, metadata=None):
    model_to_idx = {m: i for i, m in enumerate(model_order)}
    rows = []
    with open(path, newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        values = []
        kept_models = []
        for row in reader:
            idx = model_to_idx.get(row[0])
            if idx is None:
                continue
            vals = []
            for x in row[1:]:
                try:
                    vals.append(float(x) if x and x.lower() != "nan" else math.nan)
                except ValueError:
                    vals.append(math.nan)
            values.append(vals)
            kept_models.append(row[0])
    arr = np.array(values, dtype=float)
    order_idx = [kept_models.index(m) for m in model_order if m in kept_models]
    aligned_models = [kept_models[i] for i in order_idx]
    arr = arr[order_idx, :]
    features = header[1:]
    meta = metadata or {}
    for j, feature in enumerate(features):
        rows.append({"feature": feature, **meta.get(feature, {}), "values": arr[:, j]})
    return aligned_models, rows


def align_vector(source_models, source_values, target_models):
    lookup = {m: source_values[i] for i, m in enumerate(source_models)}
    return np.array([lookup.get(m, math.nan) for m in target_models], dtype=float)


def align_labels(source_models, source_labels, target_models, default="missing"):
    lookup = {m: source_labels[i] for i, m in enumerate(source_models)}
    return np.array([lookup.get(m, default) for m in target_models])


def treatment_info():
    info = {}
    with open(ROOT / "prism_primary_treatment_info.csv", newline="") as f:
        for row in csv.DictReader(f):
            info[row["column_name"]] = {
                "name": row["name"],
                "moa": row["moa"],
                "target": row["target"],
                "phase": row["phase"],
            }
    return info


def association_scan(features, score, mask, min_n, fdr_cutoff):
    results = []
    all_p = []
    tested = 0
    score = np.asarray(score, dtype=float)
    for item in features:
        y = np.asarray(item["values"], dtype=float)
        finite = mask & np.isfinite(score) & np.isfinite(y)
        if finite.sum() < min_n:
            continue
        tested += 1
        r, p, n = safe_spearman(score[finite], y[finite])
        all_p.append((item["feature"], p))
        x = score[finite]
        vals = y[finite]
        hi = x >= np.nanpercentile(x, 75)
        lo = x <= np.nanpercentile(x, 25)
        high_minus_low = float(np.nanmean(vals[hi]) - np.nanmean(vals[lo]))
        if r < 0 and high_minus_low < 0:
            result = {k: v for k, v in item.items() if k != "values"}
            result.update({
                "r": r,
                "p": p,
                "n": n,
                "high_minus_low": high_minus_low,
            })
            results.append(result)
    q = bh_q(all_p)
    for r in results:
        r["q"] = float(q.get(r["feature"], math.nan))
    confirmed = [r for r in results if r["q"] < fdr_cutoff]
    return {
        "tested": tested,
        "confirmed": sorted(confirmed, key=lambda x: (x["q"], x["r"]))[:40],
        "top_nominal": sorted(results, key=lambda x: x["p"])[:25],
    }


def differential_scan(features, positive_mask, min_n_each, fdr_cutoff):
    results = []
    all_p = []
    tested = 0
    for item in features:
        y = np.asarray(item["values"], dtype=float)
        pos = positive_mask & np.isfinite(y)
        neg = (~positive_mask) & np.isfinite(y)
        if pos.sum() < min_n_each or neg.sum() < min_n_each:
            continue
        tested += 1
        stat = stats.mannwhitneyu(y[pos], y[neg], alternative="two-sided")
        all_p.append((item["feature"], float(stat.pvalue)))
        diff = float(np.nanmean(y[pos]) - np.nanmean(y[neg]))
        if diff < 0:
            result = {k: v for k, v in item.items() if k != "values"}
            result.update({
                "p": float(stat.pvalue),
                "n_positive": int(pos.sum()),
                "n_rest": int(neg.sum()),
                "positive_minus_rest": diff,
            })
            results.append(result)
    q = bh_q(all_p)
    for r in results:
        r["q"] = float(q.get(r["feature"], math.nan))
    return {
        "tested": tested,
        "confirmed": sorted([r for r in results if r["q"] < fdr_cutoff], key=lambda x: (x["q"], x["positive_minus_rest"]))[:40],
        "top_nominal": sorted(results, key=lambda x: x["p"])[:25],
    }


def describe_groups(model_order, models, scores):
    subtypes = np.array([models[m]["subtype"] for m in model_order])
    module_names = ["proliferation", "stress_flow", "polyamine_flow", "tissue_governance", "polarity_adhesion", "junction_bioelectric", "immune_visibility", "CIR"]
    out = {}
    for group in sorted(set(subtypes)):
        mask = subtypes == group
        out[group] = {
            "n": int(mask.sum()),
            "models": [models[m]["name"] for m, ok in zip(model_order, mask) if ok],
            "module_means": {name: float(np.nanmean(scores[name][mask])) for name in module_names},
        }
    return out


def stability_clusters(model_order, scores, k=3):
    names = ["proliferation", "stress_flow", "polyamine_flow", "tissue_governance", "polarity_adhesion", "junction_bioelectric", "immune_visibility", "CIR"]
    mat = np.vstack([zscore(scores[n]) for n in names]).T
    finite = np.all(np.isfinite(mat), axis=1)
    centroids, labels = kmeans2(mat[finite], k, minit="++", seed=7)
    full = np.full(len(model_order), -1, dtype=int)
    full[finite] = labels
    cluster_info = {}
    for c in sorted(set(labels)):
        mask = full == c
        means = {n: float(np.nanmean(scores[n][mask])) for n in names}
        dominant = sorted(means.items(), key=lambda x: x[1], reverse=True)[:3]
        cluster_info[f"regime_{c}"] = {
            "n": int(mask.sum()),
            "dominant_high_modules": dominant,
            "module_means": means,
        }
    return full, cluster_info


def main():
    models = load_models()
    model_order, expr = load_expression(models)
    models = {m: models[m] for m in model_order}
    scores, found = compute_scores(expr)
    subtypes = np.array([models[m]["subtype"] for m in model_order])
    subtype_counts = Counter(subtypes)

    crispr_models, crispr_features = load_feature_matrix(ROOT / "CRISPRGeneEffect.csv", model_order)
    prism_models, prism_features = load_feature_matrix(ROOT / "prism_primary_collapsed_lfc.csv", model_order, treatment_info())
    cir_crispr = align_vector(model_order, scores["CIR"], crispr_models)
    cir_prism = align_vector(model_order, scores["CIR"], prism_models)
    subtypes_crispr = align_labels(model_order, subtypes, crispr_models)
    subtypes_prism = align_labels(model_order, subtypes, prism_models)

    contexts = {
        "all_breast_cancer": np.ones(len(model_order), dtype=bool),
    }
    for st, n in subtype_counts.items():
        if n >= 10:
            contexts[f"subtype_{st}"] = subtypes == st

    context_results = {}
    for name, mask in contexts.items():
        mask_crispr = align_vector(model_order, mask.astype(float), crispr_models) == 1.0
        mask_prism = align_vector(model_order, mask.astype(float), prism_models) == 1.0
        context_results[name] = {
            "n": int(mask.sum()),
            "n_crispr": int(mask_crispr.sum()),
            "n_prism": int(mask_prism.sum()),
            "CIR_mean": float(np.nanmean(scores["CIR"][mask])),
            "CIR_sd": float(np.nanstd(scores["CIR"][mask])),
            "CRISPR_CIR_association": association_scan(crispr_features, cir_crispr, mask_crispr, min(20, max(10, int(mask_crispr.sum() * 0.7))), 0.10),
            "PRISM_CIR_association": association_scan(prism_features, cir_prism, mask_prism, min(15, max(8, int(mask_prism.sum() * 0.6))), 0.25),
        }

    regime_labels, regime_info = stability_clusters(model_order, scores, k=3)
    regime_results = {}
    for c in sorted(set(regime_labels)):
        if c < 0:
            continue
        mask = regime_labels == c
        mask_crispr = align_vector(model_order, mask.astype(float), crispr_models) == 1.0
        mask_prism = align_vector(model_order, mask.astype(float), prism_models) == 1.0
        regime_results[f"regime_{c}"] = {
            "n": int(mask.sum()),
            "subtype_counts": dict(Counter(subtypes[mask])),
            "n_crispr": int(mask_crispr.sum()),
            "n_prism": int(mask_prism.sum()),
            "CRISPR_regime_vs_rest": differential_scan(crispr_features, mask_crispr, min_n_each=8, fdr_cutoff=0.10),
            "PRISM_regime_vs_rest": differential_scan(prism_features, mask_prism, min_n_each=8, fdr_cutoff=0.25),
        }

    out = {
        "question": "Find a coherent breast-cancer stability-regime pattern from CIR, subtype, CRISPR vulnerabilities, and PRISM drug sensitivity.",
        "design": "Use predefined CIR modules in DepMap breast cancer cell lines, classify ER/luminal HER2 TNBC/basal subtypes from ModelSubtypeFeatures, derive 3 stability regimes by module scores, then test CIR-associated and regime-associated vulnerabilities.",
        "n_models": len(model_order),
        "subtype_counts": dict(subtype_counts),
        "module_genes_found": found,
        "subtype_profiles": describe_groups(model_order, models, scores),
        "regime_profiles": regime_info,
        "context_results": context_results,
        "regime_results": regime_results,
        "guardrail": "This is an in-vitro hypothesis-generation screen, not evidence of clinical efficacy or a treatment recommendation.",
    }
    out_path = ROOT / "breast_cir_complete_pattern_results.json"
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
