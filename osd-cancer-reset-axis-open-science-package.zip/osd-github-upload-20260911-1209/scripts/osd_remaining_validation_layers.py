#!/usr/bin/env python3
"""Remaining OSD validation layers: single-cell compartmentation, spatial summary,
and module-label permutation controls.

The script is intentionally conservative. It uses only locally available public
datasets and fixed gene modules. It does not claim causality; it asks whether the
bulk OSD signal can be decomposed into cellular compartments and whether the
spatial/multimodule architecture survives simple negative controls.
"""

from __future__ import annotations

import csv
import gzip
import importlib.util
import json
import math
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

warnings.filterwarnings("ignore", category=RuntimeWarning, message="Degrees of freedom <= 0 for slice.*")

ROOT = Path(__file__).resolve().parents[3]
WORK = ROOT / "work" / "onco_psi"
PKG = ROOT / "outputs" / "osd-github-upload-20260911-1209"
RESULTS = PKG / "results"
REPORTS = PKG / "reports"
BENCHMARK = PKG / "scripts" / "osd_locked_benchmark_controls.py"

MODULES = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1"],
    "inflammatory_alarm": ["IL6", "IL1B", "TNF", "NFKB1", "NFKB2", "RELA", "STAT3", "PTGS2", "CXCL8", "CCL2", "CXCL1", "CXCL2"],
    "interferon_alarm": ["IFNG", "IRF7", "STAT1", "ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "CXCL10", "GBP1"],
    "wound_ecm_fibrosis": ["TGFB1", "TGFBR1", "SMAD2", "SMAD3", "COL1A1", "COL1A2", "COL3A1", "FN1", "VIM", "ACTA2", "MMP2", "MMP9", "TIMP1"],
    "coagulation_complement": ["C3", "C5", "CFB", "CFD", "SERPINE1", "F3", "FGA", "FGB", "FGG", "PLAU", "PLAUR"],
    "hypoxia_redox": ["HIF1A", "VEGFA", "SLC2A1", "CA9", "LDHA", "NFE2L2", "HMOX1", "NQO1", "SOD2", "TXN", "PRDX1"],
    "proteostasis_er": ["HSPA5", "XBP1", "ATF4", "DDIT3", "HSP90AA1", "PSMA1", "PSMB5", "PSMC1", "PSMD1"],
    "bioelectric_junction": ["GJA1", "GJB2", "OCLN", "TJP1", "CLDN1", "KCNJ2", "KCNN4", "ATP1A1", "ATP1B1"],
    "polarity_adhesion": ["CDH1", "EPCAM", "PARD3", "PARD6B", "LLGL2", "SCRIB", "ITGA6", "ITGB4"],
    "circadian": ["ARNTL", "CLOCK", "PER1", "PER2", "CRY1", "CRY2", "NR1D1", "RORA"],
    "mitochondrial": ["PPARGC1A", "TFAM", "NDUFA9", "SDHA", "COX5A", "ATP5F1A", "SIRT3", "OPA1"],
    "differentiation": ["KRT8", "KRT18", "CDH1", "EPCAM", "FOXA1", "GATA3", "PPARG", "ALDH1A1"],
}

INSTABILITY = [
    "inflammatory_alarm", "interferon_alarm", "wound_ecm_fibrosis",
    "coagulation_complement", "hypoxia_redox", "proteostasis_er",
]
ORDER = ["bioelectric_junction", "polarity_adhesion", "circadian", "mitochondrial", "differentiation"]


def zscore(x):
    x = np.asarray(x, dtype=float)
    mu = np.nanmean(x)
    sd = np.nanstd(x)
    if not np.isfinite(sd) or sd == 0:
        return np.zeros_like(x, dtype=float)
    return (x - mu) / sd


def mean_present(frame, genes):
    present = [g for g in genes if g in frame.columns]
    if not present:
        return np.full(len(frame), np.nan), []
    return frame[present].mean(axis=1).to_numpy(dtype=float), present


def sc_compartmentation():
    base = WORK / "reset_experiment" / "gse165897"
    meta_path = base / "GSE165897_cellInfo_HGSOC.tsv.gz"
    count_path = base / "GSE165897_UMIcounts_HGSOC.tsv.gz"
    meta = pd.read_csv(meta_path, sep="\t")
    meta = meta.set_index("cell", drop=False)
    wanted = sorted({g for genes in MODULES.values() for g in genes})

    rows = {}
    with gzip.open(count_path, "rt") as handle:
        header = handle.readline().rstrip("\n").split("\t")
        cells = header[1:]
        for line in handle:
            parts = line.rstrip("\n").split("\t")
            gene = parts[0]
            if gene in wanted:
                rows[gene] = np.asarray(parts[1:], dtype=np.float32)
    used_cells = [c for c in cells if c in meta.index]
    idx = np.array([cells.index(c) for c in used_cells], dtype=int)
    norm = meta.loc[used_cells, "nCount_RNA"].to_numpy(dtype=float)
    expr = {}
    for gene, counts in rows.items():
        expr[gene] = np.log1p((counts[idx] / np.maximum(norm, 1.0)) * 10000.0)
    expr = pd.DataFrame(expr, index=used_cells)
    zexpr = expr.apply(zscore, axis=0)

    scores = pd.DataFrame(index=used_cells)
    found = {}
    for mod, genes in MODULES.items():
        scores[mod], found[mod] = mean_present(zexpr, genes)
    scores["instability_load"] = np.nanmean(scores[INSTABILITY].to_numpy(dtype=float), axis=1)
    scores["order_capacity"] = np.nanmean(scores[ORDER].to_numpy(dtype=float), axis=1)
    scores["osd_sc"] = scores["instability_load"] - scores["order_capacity"]
    scores["cell_type"] = meta.loc[used_cells, "cell_type"].to_numpy()
    scores["cell_subtype"] = meta.loc[used_cells, "cell_subtype"].to_numpy()
    scores["patient_id"] = meta.loc[used_cells, "patient_id"].to_numpy()
    scores["treatment_phase"] = meta.loc[used_cells, "treatment_phase"].to_numpy()

    modules_to_report = ["osd_sc", "wound_ecm_fibrosis", "hypoxia_redox", "proteostasis_er", "polarity_adhesion", "bioelectric_junction"]
    compartment = []
    for cell_type, sub in scores.groupby("cell_type"):
        row = {"cell_type": cell_type, "n_cells": int(len(sub)), "n_patients": int(sub["patient_id"].nunique())}
        for col in modules_to_report:
            row[f"{col}_mean"] = float(np.nanmean(sub[col]))
            row[f"{col}_median"] = float(np.nanmedian(sub[col]))
        compartment.append(row)
    compartment = sorted(compartment, key=lambda r: r["osd_sc_mean"], reverse=True)

    kruskal = {}
    for col in modules_to_report:
        groups = [g[col].dropna().to_numpy(dtype=float) for _, g in scores.groupby("cell_type") if len(g[col].dropna()) > 20]
        if len(groups) >= 2:
            h, p = stats.kruskal(*groups)
            kruskal[col] = {"H": float(h), "p": float(p), "n_groups": len(groups)}

    malignant = scores[scores["cell_type"].astype(str).str.upper().isin(["EOC", "MALIGNANT", "TUMOR"])]
    nonmal = scores[~scores.index.isin(malignant.index)]
    malignant_vs_other = {}
    for col in modules_to_report:
        if len(malignant) and len(nonmal):
            u = stats.mannwhitneyu(malignant[col], nonmal[col], alternative="two-sided", nan_policy="omit")
            malignant_vs_other[col] = {
                "malignant_mean": float(np.nanmean(malignant[col])),
                "other_mean": float(np.nanmean(nonmal[col])),
                "delta_malignant_minus_other": float(np.nanmean(malignant[col]) - np.nanmean(nonmal[col])),
                "p": float(u.pvalue),
            }

    return {
        "dataset": "GSE165897 HGSOC single-cell RNA-seq",
        "n_cells": int(len(scores)),
        "n_patients": int(scores["patient_id"].nunique()),
        "n_cell_types": int(scores["cell_type"].nunique()),
        "genes_found": found,
        "cell_type_summary": compartment,
        "kruskal_by_cell_type": kruskal,
        "malignant_vs_other": malignant_vs_other,
        "interpretation": "OSD-like signal is decomposable by compartment; bulk OSD should not be interpreted as tumor-cell-autonomous without single-cell assignment.",
    }


def load_benchmark_module():
    spec = importlib.util.spec_from_file_location("bench", BENCHMARK)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def module_label_permutation_tcga(n=200, seed=20260911):
    bench = load_benchmark_module()
    df, genes, _ = bench.tcga_data()
    inst_cols = [
        "inflammatory_alarm", "interferon_alarm", "wound_ecm_fibrosis",
        "coagulation_complement", "hypoxia_redox_stress", "proteostasis_er_stress",
    ]
    order_cols = [
        "bioelectric_junction_order", "polarity_adhesion_order", "circadian_order",
        "mitochondrial_homeostasis", "differentiation_order",
    ]
    pool = inst_cols + order_cols
    rng = np.random.default_rng(seed)

    def residual_for(inst, order):
        osd = bench.zscore(df[inst].mean(axis=1).to_numpy(dtype=float)) - bench.zscore(df[order].mean(axis=1).to_numpy(dtype=float))
        tmp = df.copy()
        tmp["perm_osd"] = bench.residualize(osd, [df["proliferation"].to_numpy(dtype=float)])
        fit = bench.cox_fit(tmp, ["perm_osd"], strata="study")
        return fit

    target = bench.cox_fit(df, ["osd_residual"], strata="study")
    vals = []
    for _ in range(n):
        shuffled = list(rng.permutation(pool))
        inst = shuffled[:len(inst_cols)]
        order = shuffled[len(inst_cols):]
        fit = residual_for(inst, order)
        if fit:
            vals.append({
                "p": fit["covariates"]["perm_osd"]["p"],
                "hr": fit["covariates"]["perm_osd"]["hr_per_sd"],
                "c_index": fit["concordance_index"],
            })
    pvals = np.array([v["p"] for v in vals], dtype=float)
    cidx = np.array([v["c_index"] for v in vals], dtype=float)
    return {
        "dataset": "TCGA survival",
        "n_permutations": int(len(vals)),
        "fixed_instability_modules": int(len(inst_cols)),
        "fixed_order_modules": int(len(order_cols)),
        "target_p": float(target["covariates"]["osd_residual"]["p"]),
        "target_hr": float(target["covariates"]["osd_residual"]["hr_per_sd"]),
        "target_c_index": float(target["concordance_index"]),
        "median_permuted_p": float(np.median(pvals)),
        "permuted_c_index_ci95_low": float(np.percentile(cidx, 2.5)),
        "permuted_c_index_ci95_high": float(np.percentile(cidx, 97.5)),
        "fraction_permuted_p_le_target": float(np.mean(pvals <= target["covariates"]["osd_residual"]["p"])),
        "fraction_permuted_c_index_ge_target": float(np.mean(cidx >= target["concordance_index"])),
    }


def summarize_spatial():
    path = WORK / "visium_multisample_governance_validation_results.json"
    r = json.loads(path.read_text())
    tumor = [s for s in r["samples"] if s["class"] == "tumor"]
    control = [s for s in r["samples"] if s["class"] != "tumor"]
    modules = ["malignant_pressure", "tissue_governance", "polarity_adhesion", "junction_bioelectric", "proteostasis_flow", "autonomy_composite", "autonomy_residual_after_malignant_pressure"]
    summary = {}
    for m in modules:
        rs = [s["gradients"][m]["r"] for s in tumor if m in s["gradients"]]
        ps = [s["gradients"][m]["p"] for s in tumor if m in s["gradients"]]
        summary[m] = {
            "n_tumor_sections": len(rs),
            "negative_gradient_sections": int(sum(x < 0 for x in rs)),
            "median_r_tumor": float(np.median(rs)) if rs else math.nan,
            "min_p_tumor": float(np.min(ps)) if ps else math.nan,
            "control_r": float(control[0]["gradients"][m]["r"]) if control and m in control[0]["gradients"] else None,
            "control_p": float(control[0]["gradients"][m]["p"]) if control and m in control[0]["gradients"] else None,
        }
    return {
        "source": "Existing multisample 10x Visium analysis",
        "n_tumor_sections": len(tumor),
        "n_control_sections": len(control),
        "summary": summary,
        "limitations": r.get("major_limitations", []),
    }


def write_report(res):
    sc = res["single_cell_compartmentation"]
    ml = res["module_label_permutation_tcga"]
    sp = res["spatial_multisample_summary"]
    top = sc["cell_type_summary"][:5]
    lines = [
        "# Remaining OSD Validation Layers",
        "",
        "## Single-cell compartmentation",
        f"Dataset: {sc['dataset']}; cells: {sc['n_cells']}; patients: {sc['n_patients']}; cell types: {sc['n_cell_types']}.",
        "Top cell types by mean single-cell OSD:",
    ]
    for row in top:
        lines.append(f"- {row['cell_type']}: n={row['n_cells']}, mean OSD={row['osd_sc_mean']:.3f}, wound/ECM={row['wound_ecm_fibrosis_mean']:.3f}, hypoxia/redox={row['hypoxia_redox_mean']:.3f}")
    lines += [
        "",
        "## TCGA module-label permutation",
        f"Target residual OSD: p={ml['target_p']:.3g}, HR={ml['target_hr']:.3f}, C-index={ml['target_c_index']:.3f}.",
        f"Permutations: n={ml['n_permutations']}; fraction with p <= target={ml['fraction_permuted_p_le_target']:.3f}; fraction with C-index >= target={ml['fraction_permuted_c_index_ge_target']:.3f}.",
        "",
        "## Multisample spatial summary",
        f"Tumor sections: {sp['n_tumor_sections']}; controls: {sp['n_control_sections']}.",
    ]
    for mod, row in sp["summary"].items():
        lines.append(f"- {mod}: {row['negative_gradient_sections']}/{row['n_tumor_sections']} tumor sections with negative gradient; median r={row['median_r_tumor']:.3f}; control r={row['control_r']:.3f}.")
    (REPORTS / "osd_remaining_validation_layers_report.md").write_text("\n".join(lines) + "\n")


def main():
    RESULTS.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    res = {
        "analysis_name": "Remaining OSD validation layers",
        "guardrail": "These are in-silico validation layers. They strengthen construct validity but do not prove clinical causality.",
        "single_cell_compartmentation": sc_compartmentation(),
        "spatial_multisample_summary": summarize_spatial(),
        "module_label_permutation_tcga": module_label_permutation_tcga(n=200),
    }
    out = RESULTS / "osd_remaining_validation_layers_results.json"
    out.write_text(json.dumps(res, indent=2))
    write_report(res)
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
