#!/usr/bin/env python3
import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent
MIN_TISSUE_N = 10
MIN_N = 180
TOP_SINGLETS = 250
MAX_PAIRS = 3000
RNG_SEED = 20260910


def rank_norm(x):
    x = np.asarray(x, dtype=float)
    mask = np.isfinite(x)
    out = np.full(x.shape, np.nan)
    if mask.sum() < 3:
        return out
    ranks = stats.rankdata(x[mask], method="average")
    u = (ranks - 0.5) / mask.sum()
    out[mask] = stats.norm.ppf(u)
    return out


def tissue_residualize(values, tissues):
    values = np.asarray(values, dtype=float)
    tissues = np.asarray(tissues)
    out = np.full(values.shape, np.nan)
    for t in sorted(set(tissues)):
        idx = np.where(tissues == t)[0]
        if len(idx) < MIN_TISSUE_N:
            continue
        v = values[idx]
        mu = np.nanmean(v)
        sd = np.nanstd(v)
        if np.isfinite(sd) and sd > 0:
            out[idx] = (v - mu) / sd
    return out


def gene_symbol(header_name):
    return header_name.split(" (", 1)[0]


def load_tissues():
    out = {}
    with open(ROOT / "prism_primary_cell_line_info.csv", newline="") as f:
        for row in csv.DictReader(f):
            out[row["row_name"]] = row.get("primary_tissue") or "unknown"
    return out


def load_treatments():
    out = {}
    with open(ROOT / "prism_primary_treatment_info.csv", newline="") as f:
        for row in csv.DictReader(f):
            out[row["column_name"]] = {
                "name": row.get("name"),
                "moa": row.get("moa"),
                "target": row.get("target"),
                "phase": row.get("phase"),
                "dose": row.get("dose"),
            }
    return out


def load_vector_csv(path, models, mode):
    model_set = set(models)
    out = {}
    with open(path, newline="") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            if row[0] not in model_set:
                continue
            vals = np.array([float(x) if x else np.nan for x in row[1:]], dtype=float)
            if mode == "sum":
                out[row[0]] = float(np.nansum(vals))
            elif mode == "cn":
                v = vals[np.isfinite(vals)]
                if len(v) >= 1000:
                    out[row[0]] = float(np.mean([
                        np.mean(np.abs(v - 2.0) >= 0.5),
                        np.mean(np.abs(v - 2.0)),
                        np.mean((v <= 1.0) | (v >= 4.0)),
                    ]))
    return out


EXPRESSION_SETS = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1", "AURKA", "AURKB"],
    "stemness_dedifferentiation": ["SOX2", "NANOG", "POU5F1", "KLF4", "MYC", "PROM1", "CD44", "ALDH1A1"],
    "emt_invasion": ["VIM", "FN1", "ZEB1", "ZEB2", "SNAI1", "SNAI2", "TWIST1", "MMP2", "MMP9"],
    "stress_adaptation": ["HIF1A", "ATF4", "DDIT3", "XBP1", "HSPA5", "HSP90AA1", "HSP90AB1", "SQSTM1"],
    "anti_apoptosis": ["BCL2", "BCL2L1", "MCL1", "XIAP", "BIRC5"],
    "immune_visibility_low": ["B2M", "HLA-A", "HLA-B", "HLA-C", "TAP1", "TAP2", "NLRC5"],
}


def load_expression_components(models):
    wanted = {g for genes in EXPRESSION_SETS.values() for g in genes}
    vals = {}
    with open(ROOT / "OmicsExpressionProteinCodingGenesTPMLogp1.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        idx_to_gene = {i: gene_symbol(h) for i, h in enumerate(header[1:], 1) if gene_symbol(h) in wanted}
        for row in reader:
            if row[0] not in models:
                continue
            vals[row[0]] = {}
            for i, g in idx_to_gene.items():
                try:
                    vals[row[0]][g] = float(row[i])
                except Exception:
                    vals[row[0]][g] = math.nan
    comps = {}
    for m in models:
        comps[m] = {}
        for name, genes in EXPRESSION_SETS.items():
            arr = np.array([vals.get(m, {}).get(g, math.nan) for g in genes], dtype=float)
            comps[m][name] = float(np.nanmean(arr)) if np.isfinite(arr).any() else math.nan
    return comps


def load_cai(models, tissues):
    expr = load_expression_components(set(models))
    mut = load_vector_csv(ROOT / "OmicsSomaticMutationsMatrixDamaging.csv", models, "sum")
    cn = load_vector_csv(ROOT / "OmicsAbsoluteCNGene.csv", models, "cn")
    keep = [m in expr and m in mut and m in cn for m in models]
    models = [m for m, k in zip(models, keep) if k]
    tissues = np.array([t for t, k in zip(tissues, keep) if k])
    raw = {
        "proliferation": [expr[m]["proliferation"] for m in models],
        "stemness_dedifferentiation": [expr[m]["stemness_dedifferentiation"] for m in models],
        "emt_invasion": [expr[m]["emt_invasion"] for m in models],
        "stress_adaptation": [expr[m]["stress_adaptation"] for m in models],
        "anti_apoptosis": [expr[m]["anti_apoptosis"] for m in models],
        "low_immune_visibility": [-expr[m]["immune_visibility_low"] for m in models],
        "copy_number_instability": [cn[m] for m in models],
        "damaging_mutation_burden": [mut[m] for m in models],
    }
    comps = [tissue_residualize(rank_norm(v), tissues) for v in raw.values()]
    cai = tissue_residualize(np.nanmean(np.vstack(comps), axis=0), tissues)
    return models, tissues, cai


def high_low_delta(cai, sens, tissues, tissue_subset=None):
    mask0 = np.isfinite(cai) & np.isfinite(sens)
    if tissue_subset is not None:
        mask0 &= np.isin(tissues, list(tissue_subset))
    deltas = []
    ns = 0
    for t in sorted(set(tissues[mask0])):
        idx = np.where(mask0 & (tissues == t))[0]
        if len(idx) < MIN_TISSUE_N:
            continue
        c = cai[idx]
        y = sens[idx]
        hi = c >= np.nanmedian(c)
        lo = c < np.nanmedian(c)
        if hi.sum() >= 4 and lo.sum() >= 4:
            deltas.append(float(np.nanmean(y[hi]) - np.nanmean(y[lo])))
            ns += len(idx)
    if not deltas:
        return math.nan, 0, 0
    return float(np.mean(deltas)), ns, len(deltas)


def main():
    rng = np.random.default_rng(RNG_SEED)
    tissue_map = load_tissues()
    treatments = load_treatments()
    with open(ROOT / "prism_primary_collapsed_lfc.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        rows0 = [row for row in reader if row[0] in tissue_map]
    tissues0 = np.array([tissue_map[row[0]] for row in rows0])
    eligible = {t for t in set(tissues0) if np.sum(tissues0 == t) >= MIN_TISSUE_N}
    rows0 = [row for row, t in zip(rows0, tissues0) if t in eligible]
    models0 = [row[0] for row in rows0]
    tissues0 = np.array([tissue_map[m] for m in models0])
    models, tissues, cai = load_cai(models0, tissues0)
    row_by_model = {row[0]: row for row in rows0}
    rows = [row_by_model[m] for m in models]

    singles = []
    sens_matrix = []
    cols = header[1:]
    for j, col in enumerate(cols, 1):
        lfc = np.full(len(models), np.nan)
        for i, row in enumerate(rows):
            try:
                lfc[i] = float(row[j])
            except Exception:
                pass
        sens = tissue_residualize(-lfc, tissues)
        mean_lfc = float(np.nanmean(lfc))
        frac_broad = float(np.nanmean(lfc <= -0.5))
        delta, n, nt = high_low_delta(cai, sens, tissues)
        if n < MIN_N or not np.isfinite(delta):
            continue
        r, p = stats.spearmanr(cai[np.isfinite(cai) & np.isfinite(sens)], sens[np.isfinite(cai) & np.isfinite(sens)])
        singles.append({
            "idx": len(sens_matrix),
            "column_name": col,
            "delta_high_minus_low_sensitivity_z": delta,
            "spearman_r": float(r),
            "spearman_p": float(p),
            "mean_lfc": mean_lfc,
            "frac_lfc_le_-0.5": frac_broad,
            "n": n,
            "tissues": nt,
            **treatments.get(col, {}),
        })
        sens_matrix.append(sens)
    sens_matrix = np.vstack(sens_matrix)

    # Keep compounds with some positive selectivity, while excluding the most broadly cytotoxic tail.
    selectable = [
        s for s in singles
        if s["delta_high_minus_low_sensitivity_z"] > 0
        and s["spearman_r"] > 0
        and s["frac_lfc_le_-0.5"] < 0.75
        and s["mean_lfc"] > -1.2
    ]
    selectable.sort(key=lambda s: (-s["delta_high_minus_low_sensitivity_z"], s["frac_lfc_le_-0.5"]))
    top = selectable[:TOP_SINGLETS]

    all_tissues = sorted(set(tissues))
    heldout_results = []
    for rep in range(80):
        held = set(rng.choice(all_tissues, size=max(4, len(all_tissues) // 4), replace=False))
        train = set(all_tissues) - held
        train_scored = []
        for s in selectable[:600]:
            delta, n, nt = high_low_delta(cai, sens_matrix[s["idx"]], tissues, train)
            if np.isfinite(delta):
                train_scored.append((delta, s))
        train_scored.sort(key=lambda x: -x[0])
        candidates = [s for _, s in train_scored[:80]]
        pair_scores = []
        for a_i in range(len(candidates)):
            for b_i in range(a_i + 1, len(candidates)):
                a = candidates[a_i]
                b = candidates[b_i]
                combo = sens_matrix[a["idx"]] + sens_matrix[b["idx"]]
                dtrain, _, _ = high_low_delta(cai, combo, tissues, train)
                if np.isfinite(dtrain):
                    pair_scores.append((dtrain, a, b))
        pair_scores.sort(key=lambda x: -x[0])
        for dtrain, a, b in pair_scores[:3]:
            combo = sens_matrix[a["idx"]] + sens_matrix[b["idx"]]
            dtest, ntest, nttest = high_low_delta(cai, combo, tissues, held)
            heldout_results.append({
                "rep": rep,
                "heldout_tissues": sorted(held),
                "train_delta": dtrain,
                "heldout_delta": dtest,
                "heldout_n": ntest,
                "heldout_tissues_tested": nttest,
                "a": {k: a.get(k) for k in ["name", "moa", "target", "phase", "delta_high_minus_low_sensitivity_z", "frac_lfc_le_-0.5"]},
                "b": {k: b.get(k) for k in ["name", "moa", "target", "phase", "delta_high_minus_low_sensitivity_z", "frac_lfc_le_-0.5"]},
            })

    valid_hold = [r["heldout_delta"] for r in heldout_results if np.isfinite(r["heldout_delta"])]
    t, p = stats.ttest_1samp(valid_hold, 0.0) if valid_hold else (math.nan, math.nan)

    direct_pairs = []
    for a_i in range(min(len(top), 80)):
        for b_i in range(a_i + 1, min(len(top), 80)):
            a = top[a_i]
            b = top[b_i]
            combo = sens_matrix[a["idx"]] + sens_matrix[b["idx"]]
            d, n, nt = high_low_delta(cai, combo, tissues)
            direct_pairs.append((d, n, nt, a, b))
    direct_pairs.sort(key=lambda x: -x[0])

    out = {
        "question": "Can a selective therapeutic window be detected: weak/moderate single agents that preferentially inhibit high Cancer Autonomy Index models, and additive in-silico pairs that preserve this signal in held-out tissues?",
        "design": {
            "single_agent_filter": "Positive CAI-sensitivity association; exclude broadly cytotoxic compounds with fraction LFC<=-0.5 >=0.75 or mean LFC <= -1.2.",
            "combo_model": "Exploratory additive model on tissue-residualized sensitivity z-scores, not a biochemical synergy model.",
            "cross_validation": "Repeated tissue holdout: choose candidates/pairs on training tissues, evaluate high-vs-low CAI sensitivity delta on held-out tissues.",
        },
        "n_models": len(models),
        "n_tissues": int(len(set(tissues))),
        "n_single_agents_tested": len(singles),
        "n_selective_single_agents": len(selectable),
        "top_selective_single_agents": top[:40],
        "top_exploratory_pairs_full_data": [
            {
                "delta_high_minus_low_sensitivity_z": d,
                "n": n,
                "tissues": nt,
                "a": {k: a.get(k) for k in ["name", "moa", "target", "phase", "delta_high_minus_low_sensitivity_z", "frac_lfc_le_-0.5", "mean_lfc"]},
                "b": {k: b.get(k) for k in ["name", "moa", "target", "phase", "delta_high_minus_low_sensitivity_z", "frac_lfc_le_-0.5", "mean_lfc"]},
            }
            for d, n, nt, a, b in direct_pairs[:40]
        ],
        "heldout_combo_validation": {
            "n_evaluated_pairs": len(valid_hold),
            "mean_heldout_delta": float(np.nanmean(valid_hold)) if valid_hold else math.nan,
            "median_heldout_delta": float(np.nanmedian(valid_hold)) if valid_hold else math.nan,
            "fraction_positive_heldout_delta": float(np.mean(np.array(valid_hold) > 0)) if valid_hold else math.nan,
            "one_sample_t_p": float(p) if np.isfinite(p) else math.nan,
            "examples": heldout_results[:20],
        },
    }
    (ROOT / "prism_selective_window_combo_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
