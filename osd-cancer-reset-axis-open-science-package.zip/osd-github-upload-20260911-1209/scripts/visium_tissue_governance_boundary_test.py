#!/usr/bin/env python3
import csv
import gzip
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats
from scipy.io import mmread
from scipy.spatial import cKDTree

ROOT = Path(__file__).resolve().parent / "visium_breast"

MODULES = {
    "malignant_pressure": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1", "VIM", "FN1", "ZEB1", "SNAI2", "HIF1A", "ATF4", "BCL2L1", "MCL1"],
    "tissue_governance": ["YAP1", "WWTR1", "TEAD1", "TEAD4", "LATS1", "LATS2", "NF2", "TGFB1", "TGFBR1", "TGFBR2", "SMAD2", "SMAD3", "SMAD4", "CTNNB1", "APC", "NOTCH1", "NOTCH2", "RBPJ"],
    "polarity_adhesion": ["PARD3", "PARD6A", "PRKCI", "SCRIB", "DLG1", "LLGL1", "CDH1", "CDH2", "ITGA5", "ITGB1", "VCL", "TLN1", "PXN", "PTK2"],
    "junction_bioelectric": ["GJA1", "GJB1", "GJB2", "PANX1", "ATP1A1", "ATP1B1", "KCNH2", "KCNJ2", "KCNQ1", "CLCN3", "SLC9A1", "VDAC1"],
    "immune_visibility": ["B2M", "HLA-A", "HLA-B", "HLA-C", "TAP1", "TAP2", "NLRC5", "JAK1", "JAK2", "STING1"],
    "polyamine_flow": ["AMD1", "SMS", "SRM", "ODC1", "SAT1", "SMOX", "PAOX"],
    "proteostasis_flow": ["PSMA1", "PSMA2", "PSMA3", "PSMA6", "PSMB1", "PSMB3", "PSMB5", "PSMC1", "PSMD1", "HSP90AA1", "HSPA5", "XBP1"],
}


def read_lines_gz(path):
    with gzip.open(path, "rt") as f:
        return [line.rstrip("\n") for line in f]


def zscore(x):
    x = np.asarray(x, dtype=float)
    m = np.nanmean(x)
    s = np.nanstd(x)
    if not np.isfinite(s) or s == 0:
        return np.full(x.shape, np.nan)
    return (x - m) / s


def safe_spearman(x, y):
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 30:
        return math.nan, math.nan, int(mask.sum())
    r, p = stats.spearmanr(x[mask], y[mask])
    return float(r), float(p), int(mask.sum())


def main():
    features = []
    with gzip.open(ROOT / "filtered_feature_bc_matrix/features.tsv.gz", "rt") as f:
        for row in csv.reader(f, delimiter="\t"):
            features.append(row[1])
    barcodes = read_lines_gz(ROOT / "filtered_feature_bc_matrix/barcodes.tsv.gz")
    gene_to_idx = {}
    for i, gene in enumerate(features):
        gene_to_idx.setdefault(gene, i)

    wanted = sorted({g for genes in MODULES.values() for g in genes if g in gene_to_idx})
    wanted_idx = [gene_to_idx[g] for g in wanted]
    mat = mmread(str(ROOT / "filtered_feature_bc_matrix/matrix.mtx.gz")).tocsr()
    sub = mat[wanted_idx, :].astype(float).toarray()
    totals = np.asarray(mat.sum(axis=0)).ravel()
    norm = np.log1p((sub / np.maximum(totals, 1)) * 10000.0)
    gene_expr = {g: norm[i] for i, g in enumerate(wanted)}

    coords = {}
    with open(ROOT / "spatial/tissue_positions_list.csv", newline="") as f:
        for row in csv.reader(f):
            barcode, in_tissue, array_row, array_col, px_row, px_col = row
            if in_tissue == "1":
                coords[barcode] = (float(px_col), float(px_row), int(array_row), int(array_col))
    clusters = {}
    with open(ROOT / "analysis/clustering/graphclust/clusters.csv", newline="") as f:
        for row in csv.DictReader(f):
            clusters[row["Barcode"]] = int(row["Cluster"])

    keep = [i for i, b in enumerate(barcodes) if b in coords and b in clusters]
    kept_barcodes = [barcodes[i] for i in keep]
    xy = np.array([[coords[b][0], coords[b][1]] for b in kept_barcodes], dtype=float)
    cluster = np.array([clusters[b] for b in kept_barcodes], dtype=int)

    module_scores = {}
    module_found = {}
    for module, genes in MODULES.items():
        found = [g for g in genes if g in gene_expr]
        module_found[module] = found
        vals = np.vstack([zscore(gene_expr[g][keep]) for g in found])
        module_scores[module] = np.nanmean(vals, axis=0)

    malignant = module_scores["malignant_pressure"]
    cluster_malignancy = {}
    for c in sorted(set(cluster)):
        idx = cluster == c
        cluster_malignancy[int(c)] = float(np.nanmean(malignant[idx]))
    malignant_clusters = {c for c, v in cluster_malignancy.items() if v >= np.nanpercentile(list(cluster_malignancy.values()), 75)}
    malignant_mask = np.array([c in malignant_clusters for c in cluster], dtype=bool)

    tree_mal = cKDTree(xy[malignant_mask])
    tree_other = cKDTree(xy[~malignant_mask])
    dist_to_mal = tree_mal.query(xy, k=1)[0]
    dist_to_other = tree_other.query(xy, k=1)[0]
    signed_distance = dist_to_mal.copy()
    signed_distance[malignant_mask] = -dist_to_other[malignant_mask]

    boundary_mask = np.abs(signed_distance) <= np.nanpercentile(np.abs(signed_distance), 35)
    tumor_core_mask = signed_distance < -np.nanpercentile(np.abs(signed_distance), 65)
    outside_mask = signed_distance > np.nanpercentile(np.abs(signed_distance), 65)

    module_gradient = []
    for module, score in module_scores.items():
        r, p, n = safe_spearman(signed_distance, score)
        module_gradient.append({
            "module": module,
            "spearman_r_with_distance_outward": r,
            "p": p,
            "n": n,
            "mean_tumor_core": float(np.nanmean(score[tumor_core_mask])),
            "mean_boundary": float(np.nanmean(score[boundary_mask])),
            "mean_outside": float(np.nanmean(score[outside_mask])),
            "boundary_minus_core": float(np.nanmean(score[boundary_mask]) - np.nanmean(score[tumor_core_mask])),
            "outside_minus_core": float(np.nanmean(score[outside_mask]) - np.nanmean(score[tumor_core_mask])),
        })
    module_gradient.sort(key=lambda x: abs(x["spearman_r_with_distance_outward"]), reverse=True)

    governance_loss = -zscore(module_scores["tissue_governance"]) - zscore(module_scores["polarity_adhesion"]) - zscore(module_scores["junction_bioelectric"]) - zscore(module_scores["immune_visibility"])
    autonomy = zscore(module_scores["malignant_pressure"]) + zscore(module_scores["proteostasis_flow"]) + zscore(module_scores["polyamine_flow"]) + governance_loss
    r, p, n = safe_spearman(signed_distance, autonomy)
    aut_by_cluster = []
    for c in sorted(set(cluster)):
        idx = cluster == c
        aut_by_cluster.append({
            "cluster": int(c),
            "n": int(idx.sum()),
            "malignant_pressure": float(np.nanmean(malignant[idx])),
            "autonomy_score": float(np.nanmean(autonomy[idx])),
            "mean_signed_distance": float(np.nanmean(signed_distance[idx])),
        })
    aut_by_cluster.sort(key=lambda x: x["autonomy_score"], reverse=True)

    out = {
        "question": "Is there a spatial tissue-governance boundary signal: loss of organism-level coordination near/inside tumor-like regions?",
        "data_source": "10x Genomics Visium Human Breast Cancer Block A Section 1, Space Ranger 1.1.0 public dataset.",
        "design": "Use graph-based clusters and expression modules. Tumor-like clusters are top-quartile clusters by malignant-pressure signature. Signed distance is negative inside tumor-like regions and positive outward. Test module gradients across this boundary.",
        "limitations": [
            "This is one breast cancer section, not pan-cancer validation.",
            "Tumor-like regions are inferred from expression clusters, not pathologist annotation.",
            "Visium spots contain mixtures of cells, so this tests tissue-field behavior, not single-cell causality.",
        ],
        "n_spots": int(len(kept_barcodes)),
        "n_clusters": int(len(set(cluster))),
        "malignant_clusters": sorted(int(c) for c in malignant_clusters),
        "cluster_malignancy": cluster_malignancy,
        "module_genes_found": module_found,
        "module_gradient_results": module_gradient,
        "autonomy_boundary_result": {
            "spearman_r_with_distance_outward": r,
            "p": p,
            "n": n,
            "mean_tumor_core": float(np.nanmean(autonomy[tumor_core_mask])),
            "mean_boundary": float(np.nanmean(autonomy[boundary_mask])),
            "mean_outside": float(np.nanmean(autonomy[outside_mask])),
        },
        "top_clusters_by_autonomy": aut_by_cluster,
    }
    out_path = Path(__file__).resolve().parent / "visium_tissue_governance_boundary_results.json"
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
