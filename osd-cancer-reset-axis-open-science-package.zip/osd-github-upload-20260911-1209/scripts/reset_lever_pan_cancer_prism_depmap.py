#!/usr/bin/env python3
import csv
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent

MODULES = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1"],
    "inflammatory_alarm": ["IL6", "IL1B", "TNF", "NFKB1", "NFKB2", "RELA", "STAT3", "PTGS2", "CXCL8", "CCL2", "CXCL1", "CXCL2"],
    "interferon_alarm": ["IFNG", "IRF7", "STAT1", "ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "CXCL10", "GBP1"],
    "wound_ecm_fibrosis": ["TGFB1", "TGFBR1", "SMAD2", "SMAD3", "COL1A1", "COL1A2", "COL3A1", "FN1", "VIM", "ACTA2", "MMP2", "MMP9", "TIMP1"],
    "coagulation_complement": ["C3", "C5", "CFB", "CFH", "F2", "F3", "FGA", "FGB", "FGG", "SERPINE1", "PLAU", "PLAT"],
    "hypoxia_redox_stress": ["HIF1A", "VEGFA", "SLC2A1", "CA9", "LDHA", "NFE2L2", "HMOX1", "NQO1", "SOD2", "TXN", "PRDX1"],
    "proteostasis_er_stress": ["HSPA5", "XBP1", "ATF4", "DDIT3", "HSP90AA1", "PSMA1", "PSMB5", "PSMC1", "PSMD1"],
    "bioelectric_junction_order": ["GJA1", "GJB1", "GJB2", "PANX1", "ATP1A1", "ATP1B1", "KCNJ2", "KCNQ1", "CLCN3", "SLC9A1", "VDAC1"],
    "polarity_adhesion_order": ["PARD3", "PARD6A", "PRKCI", "SCRIB", "DLG1", "LLGL1", "CDH1", "ITGA5", "ITGB1", "VCL", "TLN1", "PXN"],
    "circadian_order": ["CLOCK", "ARNTL", "PER1", "PER2", "PER3", "CRY1", "CRY2", "NR1D1", "NR1D2", "RORA", "DBP"],
    "mitochondrial_homeostasis": ["PPARGC1A", "PPARGC1B", "NDUFS1", "NDUFV1", "SDHA", "UQCRC1", "COX4I1", "ATP5F1A", "TFAM", "SIRT3"],
    "differentiation_order": ["NOTCH1", "NOTCH2", "RBPJ", "CTNNB1", "APC", "YAP1", "WWTR1", "TEAD1", "TEAD4", "LATS1", "LATS2"],
}


def gene_name(col):
    m = re.match(r"^(.+?) \(\d+\)$", col)
    return m.group(1) if m else col


def zscore(x):
    x = np.asarray(x, dtype=float)
    s = np.nanstd(x)
    if not np.isfinite(s) or s == 0:
        return np.full(x.shape, np.nan)
    return (x - np.nanmean(x)) / s


def residualize_one(y, x):
    y = np.asarray(y, dtype=float)
    x = zscore(x)
    out = np.full(y.shape, np.nan)
    mask = np.isfinite(y) & np.isfinite(x)
    if mask.sum() < 10:
        return out
    xm = x[mask] - np.mean(x[mask])
    ym = y[mask] - np.mean(y[mask])
    denom = float(np.dot(xm, xm))
    if denom == 0 or not np.isfinite(denom):
        return out
    out[mask] = ym - float(np.dot(xm, ym) / denom) * xm
    return out


def within_lineage_residual(values, lineages, covariate=None):
    values = np.asarray(values, dtype=float)
    out = np.full(values.shape, np.nan)
    for lin in sorted(set(lineages)):
        idx = np.where(lineages == lin)[0]
        if len(idx) < 10:
            continue
        if covariate is None:
            out[idx] = zscore(values[idx])
        else:
            out[idx] = zscore(residualize_one(values[idx], covariate[idx]))
    return out


def safe_spearman(x, y):
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 80:
        return math.nan, math.nan, int(mask.sum())
    r, p = stats.spearmanr(x[mask], y[mask])
    return float(r), float(p), int(mask.sum())


def bh_q(pairs):
    vals = [(k, p) for k, p in pairs if np.isfinite(p)]
    vals.sort(key=lambda x: x[1])
    m = len(vals)
    out = {}
    prev = 1.0
    for i in range(m, 0, -1):
        k, p = vals[i - 1]
        q = min(prev, p * m / i)
        out[k] = q
        prev = q
    return out


def load_models():
    rows = {}
    with open(ROOT / "Model.csv", newline="") as f:
        for row in csv.DictReader(f):
            lineage = row.get("OncotreeLineage", "")
            disease = row.get("OncotreePrimaryDisease", "")
            if not lineage or disease == "Non-Cancerous":
                continue
            rows[row["ModelID"]] = {
                "lineage": lineage,
                "name": row.get("StrippedCellLineName", ""),
                "disease": disease,
            }
    counts = Counter(r["lineage"] for r in rows.values())
    allowed = {lin for lin, n in counts.items() if n >= 20 and lin not in {"Fibroblast"}}
    return {mid: r for mid, r in rows.items() if r["lineage"] in allowed}


def load_module_expression(model_ids):
    wanted = sorted({g for genes in MODULES.values() for g in genes})
    rows = {}
    with open(ROOT / "OmicsExpressionProteinCodingGenesTPMLogp1.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        gene_to_col = {gene_name(c): i for i, c in enumerate(header) if gene_name(c) in wanted}
        for row in reader:
            if row[0] in model_ids:
                rows[row[0]] = {g: float(row[i]) if row[i] else math.nan for g, i in gene_to_col.items()}
    model_order = sorted(rows)
    expr = {g: np.array([rows[m].get(g, math.nan) for m in model_order], dtype=float) for g in gene_to_col}
    found = {module: [g for g in genes if g in expr] for module, genes in MODULES.items()}
    return model_order, expr, found


def compute_osd(expr):
    gene_z = {g: zscore(v) for g, v in expr.items()}
    scores = {}
    for module, genes in MODULES.items():
        gs = [g for g in genes if g in gene_z]
        scores[module] = np.nanmean(np.vstack([gene_z[g] for g in gs]), axis=0)
    instability = (
        zscore(scores["inflammatory_alarm"])
        + zscore(scores["interferon_alarm"])
        + zscore(scores["wound_ecm_fibrosis"])
        + zscore(scores["coagulation_complement"])
        + zscore(scores["hypoxia_redox_stress"])
        + zscore(scores["proteostasis_er_stress"])
    )
    order = (
        zscore(scores["bioelectric_junction_order"])
        + zscore(scores["polarity_adhesion_order"])
        + zscore(scores["circadian_order"])
        + zscore(scores["mitochondrial_homeostasis"])
        + zscore(scores["differentiation_order"])
    )
    scores["instability_load"] = instability
    scores["order_capacity"] = order
    scores["organism_stability_disruption"] = instability - order
    return scores


def scan_matrix(path, model_order, x, lineages, more_negative_sensitive=True, min_n=250):
    model_to_idx = {m: i for i, m in enumerate(model_order)}
    results = []
    all_p = []
    with open(path, newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        values_by_feature = [[] for _ in header[1:]]
        x_by_feature = [[] for _ in header[1:]]
        lineage_by_feature = [[] for _ in header[1:]]
        for row in reader:
            idx = model_to_idx.get(row[0])
            if idx is None or not np.isfinite(x[idx]):
                continue
            for j, val in enumerate(row[1:]):
                if not val or val.lower() == "nan":
                    continue
                try:
                    y = float(val)
                except ValueError:
                    continue
                if np.isfinite(y):
                    values_by_feature[j].append(y)
                    x_by_feature[j].append(x[idx])
                    lineage_by_feature[j].append(lineages[idx])

    for j, feature in enumerate(header[1:]):
        if len(values_by_feature[j]) < min_n:
            continue
        y = np.asarray(values_by_feature[j], dtype=float)
        xx = np.asarray(x_by_feature[j], dtype=float)
        lin = np.asarray(lineage_by_feature[j])
        y_resid = within_lineage_residual(y, lin, None)
        r, p, n = safe_spearman(xx, y_resid)
        if not np.isfinite(p):
            continue
        all_p.append((feature, p))
        mask = np.isfinite(xx) & np.isfinite(y_resid)
        hi = xx[mask] >= np.nanpercentile(xx[mask], 75)
        lo = xx[mask] <= np.nanpercentile(xx[mask], 25)
        high_minus_low = float(np.nanmean(y[mask][hi]) - np.nanmean(y[mask][lo]))
        sensitive = high_minus_low < 0 if more_negative_sensitive else high_minus_low > 0
        results.append({
            "feature": feature,
            "r": r,
            "p": p,
            "n": n,
            "high_osd_minus_low_osd_raw": high_minus_low,
            "high_osd_more_sensitive": bool(sensitive),
        })
    q = bh_q(all_p)
    for r in results:
        r["q"] = float(q.get(r["feature"], math.nan))
    return results


def treatment_info():
    info = {}
    with open(ROOT / "prism_primary_treatment_info.csv", newline="") as f:
        for row in csv.DictReader(f):
            info[row["column_name"]] = {
                "name": row["name"],
                "moa": row["moa"],
                "target": row["target"],
                "phase": row["phase"],
            }
    return info


def main():
    models = load_models()
    model_order, expr, found = load_module_expression(models)
    lineages = np.array([models[m]["lineage"] for m in model_order])
    scores = compute_osd(expr)
    osd = within_lineage_residual(scores["organism_stability_disruption"], lineages, scores["proliferation"])

    crispr = scan_matrix(ROOT / "CRISPRGeneEffect.csv", model_order, osd, lineages, True, min_n=500)
    prism = scan_matrix(ROOT / "prism_primary_collapsed_lfc.csv", model_order, osd, lineages, True, min_n=200)
    info = treatment_info()
    for row in prism:
        row.update(info.get(row["feature"], {}))

    crispr_hits = [r for r in crispr if r["q"] < 0.10 and r["r"] < 0 and r["high_osd_more_sensitive"]]
    prism_hits = [r for r in prism if r["q"] < 0.25 and r["r"] < 0 and r["high_osd_more_sensitive"]]
    crispr_hits.sort(key=lambda r: (r["q"], r["r"]))
    prism_hits.sort(key=lambda r: (r["q"], r["r"]))

    top_nominal_crispr = sorted(
        [r for r in crispr if r["r"] < 0 and r["high_osd_more_sensitive"]],
        key=lambda r: r["p"],
    )[:50]
    top_nominal_prism = sorted(
        [r for r in prism if r["r"] < 0 and r["high_osd_more_sensitive"]],
        key=lambda r: r["p"],
    )[:50]

    moa_counts = Counter()
    for r in top_nominal_prism[:100]:
        for moa in (r.get("moa") or "").split(","):
            moa = moa.strip()
            if moa and moa != "NA":
                moa_counts[moa] += 1

    out = {
        "question": "Which existing CRISPR/drug perturbation vulnerabilities are associated with high organism-stability disruption after removing proliferation and lineage effects?",
        "data_sources": [
            "DepMap 24Q4 expression and CRISPR gene effect",
            "PRISM Repurposing primary screen collapsed log-fold-change",
        ],
        "design": "Compute organism_stability_disruption from predefined modules in cancer cell lines, residualize within lineage against proliferation, then test lineage-residualized CRISPR/drug sensitivity associations. More negative CRISPR gene effect or PRISM LFC means greater vulnerability.",
        "n_models_with_expression": int(len(model_order)),
        "lineage_counts": dict(Counter(lineages)),
        "module_genes_found": found,
        "osd_summary": {
            "finite": int(np.isfinite(osd).sum()),
            "mean": float(np.nanmean(osd)),
            "sd": float(np.nanstd(osd)),
        },
        "crispr_tested": int(len(crispr)),
        "crispr_confirmed_fdr_0_10": crispr_hits[:50],
        "prism_tested": int(len(prism)),
        "prism_confirmed_fdr_0_25": prism_hits[:50],
        "top_nominal_crispr_high_osd_sensitive": top_nominal_crispr,
        "top_nominal_prism_high_osd_sensitive": top_nominal_prism,
        "top_nominal_prism_moa_counts": moa_counts.most_common(30),
        "guardrail": "This is a cell-line perturbation association screen. It does not establish a safe or effective clinical reset intervention.",
    }
    out_path = ROOT / "reset_lever_pan_cancer_prism_depmap_results.json"
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
