#!/usr/bin/env python3
import csv
import gzip
import json
import math
import urllib.request
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from scipy import stats

BASE = Path(__file__).resolve().parent
XENA = BASE / "xena_cir"
OUT = BASE / "lincs_osd_reversal_results.json"

MODULES = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1"],
    "inflammatory_alarm": ["IL6", "IL1B", "TNF", "NFKB1", "NFKB2", "RELA", "STAT3", "PTGS2", "CXCL8", "CCL2", "CXCL1", "CXCL2"],
    "interferon_alarm": ["IFNG", "IRF7", "STAT1", "ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "CXCL10", "GBP1"],
    "wound_ecm_fibrosis": ["TGFB1", "TGFBR1", "SMAD2", "SMAD3", "COL1A1", "COL1A2", "COL3A1", "FN1", "VIM", "ACTA2", "MMP2", "MMP9", "TIMP1"],
    "coagulation_complement": ["C3", "C5", "CFB", "CFH", "F2", "F3", "FGA", "FGB", "FGG", "SERPINE1", "PLAU", "PLAT"],
    "hypoxia_redox_stress": ["HIF1A", "VEGFA", "SLC2A1", "CA9", "LDHA", "NFE2L2", "HMOX1", "NQO1", "SOD2", "TXN", "PRDX1"],
    "proteostasis_er_stress": ["HSPA5", "XBP1", "ATF4", "DDIT3", "HSP90AA1", "PSMA1", "PSMB5", "PSMC1", "PSMD1"],
    "bioelectric_junction_order": ["GJA1", "GJB1", "GJB2", "PANX1", "ATP1A1", "ATP1B1", "KCNJ2", "KCNQ1", "CLCN3", "SLC9A1", "VDAC1"],
    "polarity_adhesion_order": ["PARD3", "PARD6A", "PRKCI", "SCRIB", "DLG1", "LLGL1", "CDH1", "ITGA5", "ITGB1", "VCL", "TLN1", "PXN"],
    "circadian_order": ["CLOCK", "ARNTL", "PER1", "PER2", "PER3", "CRY1", "CRY2", "NR1D1", "NR1D2", "RORA", "DBP"],
    "mitochondrial_homeostasis": ["PPARGC1A", "PPARGC1B", "NDUFS1", "NDUFV1", "SDHA", "UQCRC1", "COX4I1", "ATP5F1A", "TFAM", "SIRT3"],
    "differentiation_order": ["NOTCH1", "NOTCH2", "RBPJ", "CTNNB1", "APC", "YAP1", "WWTR1", "TEAD1", "TEAD4", "LATS1", "LATS2"],
}

PRIMARY_SITE_MAP = {
    "Brain": "Brain", "Breast": "Breast", "Colon": "Colon", "Endometrium": "Uterus",
    "Esophagus": "Esophagus", "Liver": "Liver", "Lung": "Lung", "Ovary": "Ovary",
    "Pancreas": "Pancreas", "Prostate": "Prostate", "Rectum": "Colon", "Skin": "Skin",
    "Stomach": "Stomach", "Testis": "Testis", "Uterus": "Uterus",
}

GTEX_MAP = {
    "Brain - Amygdala": "Brain", "Brain - Anterior cingulate cortex (BA24)": "Brain",
    "Brain - Caudate (basal ganglia)": "Brain", "Brain - Cerebellar Hemisphere": "Brain",
    "Brain - Cerebellum": "Brain", "Brain - Cortex": "Brain", "Brain - Frontal Cortex (BA9)": "Brain",
    "Brain - Hippocampus": "Brain", "Brain - Hypothalamus": "Brain",
    "Brain - Nucleus accumbens (basal ganglia)": "Brain", "Brain - Putamen (basal ganglia)": "Brain",
    "Brain - Spinal cord (cervical c-1)": "Brain", "Brain - Substantia nigra": "Brain",
    "Breast - Mammary Tissue": "Breast", "Colon - Sigmoid": "Colon", "Colon - Transverse": "Colon",
    "Esophagus - Gastroesophageal Junction": "Esophagus", "Esophagus - Mucosa": "Esophagus",
    "Esophagus - Muscularis": "Esophagus", "Liver": "Liver", "Lung": "Lung", "Ovary": "Ovary",
    "Pancreas": "Pancreas", "Prostate": "Prostate", "Skin - Not Sun Exposed (Suprapubic)": "Skin",
    "Skin - Sun Exposed (Lower leg)": "Skin", "Stomach": "Stomach", "Testis": "Testis", "Uterus": "Uterus",
}


def load_pheno():
    rows = {}
    with gzip.open(XENA / "TcgaTargetGTEX_phenotype.txt.gz", "rt", encoding="utf-8", errors="replace") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            label = None
            site = None
            if row["_study"] == "TCGA" and row["_sample_type"] == "Primary Tumor":
                site = PRIMARY_SITE_MAP.get(row["_primary_site"])
                label = "tumor"
            elif row["_study"] == "GTEX":
                site = GTEX_MAP.get(row["primary disease or tissue"])
                label = "normal"
            if site and label:
                rows[row["sample"]] = {"site": site, "label": label}
    return rows


def gene_map():
    out = {}
    with open(XENA / "gencode.v23.annotation.gene.probemap") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            out[row["id"]] = row["gene"]
    return out


def load_expression():
    genes = set(g for mod in MODULES.values() for g in mod)
    gid_to_gene = gene_map()
    path = XENA / "selected_organism_reset_gene_expression.tsv.gz"
    with gzip.open(path, "rt") as f:
        header = f.readline().rstrip("\n").split("\t")
        samples = header[1:]
        data = {}
        for line in f:
            parts = line.rstrip("\n").split("\t")
            gene = gid_to_gene.get(parts[0])
            if gene in genes:
                data[gene] = np.array([float(x) for x in parts[1:]], dtype=float)
    return samples, data


def build_signature():
    pheno = load_pheno()
    samples, data = load_expression()
    keep = [i for i, s in enumerate(samples) if s in pheno]
    labels = np.array([pheno[samples[i]]["label"] for i in keep])
    sites = np.array([pheno[samples[i]]["site"] for i in keep])
    matched = sorted({st for st in set(sites) if np.sum((sites == st) & (labels == "tumor")) >= 20 and np.sum((sites == st) & (labels == "normal")) >= 20})
    keep2 = np.array([st in matched for st in sites])
    labels = labels[keep2]
    sites = sites[keep2]
    idxs = [k for k, ok in zip(keep, keep2) if ok]

    gene_stats = []
    for gene, vals0 in data.items():
        vals = vals0[idxs]
        deltas = []
        aucs = []
        ps = []
        for st in matched:
            idx = sites == st
            tumor = vals[idx & (labels == "tumor")]
            normal = vals[idx & (labels == "normal")]
            if len(tumor) < 20 or len(normal) < 20:
                continue
            mw = stats.mannwhitneyu(tumor, normal, alternative="two-sided")
            deltas.append(float(np.mean(tumor) - np.mean(normal)))
            aucs.append(float(mw.statistic / (len(tumor) * len(normal))))
            ps.append(float(mw.pvalue))
        gene_stats.append({
            "gene": gene,
            "median_delta": float(np.median(deltas)),
            "positive_sites": int(sum(d > 0 for d in deltas)),
            "negative_sites": int(sum(d < 0 for d in deltas)),
            "median_auc": float(np.median(aucs)),
            "min_p": float(min(ps)) if ps else math.nan,
            "modules": [m for m, gs in MODULES.items() if gene in gs],
        })

    up = [
        g["gene"] for g in gene_stats
        if g["positive_sites"] >= 9 and g["median_delta"] > 0.15
        and "proliferation" not in g["modules"]
    ]
    dn = [
        g["gene"] for g in gene_stats
        if g["negative_sites"] >= 9 and g["median_delta"] < -0.15
        and "proliferation" not in g["modules"]
    ]
    weighted = [
        (g["gene"], g["median_delta"]) for g in gene_stats
        if (g["positive_sites"] >= 8 or g["negative_sites"] >= 8)
        and "proliferation" not in g["modules"]
        and abs(g["median_delta"]) > 0.05
    ]
    weighted.sort(key=lambda x: abs(x[1]), reverse=True)
    return {
        "matched_sites": matched,
        "gene_stats": sorted(gene_stats, key=lambda x: abs(x["median_delta"]), reverse=True),
        "up_genes": sorted(up),
        "down_genes": sorted(dn),
        "weighted_genes": weighted,
    }


def l1000_query(payload):
    url = "https://maayanlab.cloud/L1000CDS2/query"
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode(),
        headers={"content-type": "application/json", "User-Agent": "Mozilla/5.0"},
    )
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read().decode())


def summarize_top(top):
    by_pert = defaultdict(list)
    for row in top:
        by_pert[row["pert_desc"]].append(row)
    consensus = []
    for pert, rows in by_pert.items():
        consensus.append({
            "perturbation": pert,
            "n_signatures_top50": len(rows),
            "best_score": max(r.get("score", float("-inf")) for r in rows),
            "mean_score": float(np.mean([r.get("score", math.nan) for r in rows])),
            "cells": sorted(set(r.get("cell_id", "") for r in rows)),
            "pert_ids": sorted(set(r.get("pert_id", "") for r in rows)),
            "pubchem_ids": sorted(set(str(r.get("pubchem_id", "")) for r in rows if r.get("pubchem_id"))),
            "examples": rows[:3],
        })
    consensus.sort(key=lambda x: (x["n_signatures_top50"], x["best_score"]), reverse=True)
    return consensus


def compare_with_prism(reset_levers_path, perturbations):
    try:
        dep = json.loads(Path(reset_levers_path).read_text())
    except FileNotFoundError:
        return []
    prism_names = {r.get("name", "").lower(): r for r in dep.get("prism_confirmed_fdr_0_25", [])}
    hits = []
    for p in perturbations:
        row = prism_names.get(p["perturbation"].lower())
        if row:
            hits.append({"perturbation": p["perturbation"], "lincs": p, "prism": row})
    return hits


def main():
    sig = build_signature()
    up = [g.upper() for g in sig["up_genes"]]
    dn = [g.upper() for g in sig["down_genes"]]
    weighted = [(g.upper(), float(v)) for g, v in sig["weighted_genes"][:80]]

    gene_set_payload = {
        "data": {"upGenes": up, "dnGenes": dn},
        "config": {"aggravate": False, "searchMethod": "geneSet", "share": False, "combination": True, "db-version": "latest"},
        "meta": [{"key": "Tag", "value": "organism stability disruption reverse gene-set"}],
    }
    cd_payload = {
        "data": {"genes": [g for g, _ in weighted], "vals": [v for _, v in weighted]},
        "config": {"aggravate": False, "searchMethod": "CD", "share": False, "combination": True, "db-version": "latest"},
        "meta": [{"key": "Tag", "value": "organism stability disruption reverse weighted"}],
    }

    gene_set_res = l1000_query(gene_set_payload)
    cd_res = l1000_query(cd_payload)
    gene_set_consensus = summarize_top(gene_set_res.get("topMeta", []))
    cd_consensus = summarize_top(cd_res.get("topMeta", []))

    all_names = [p["perturbation"] for p in gene_set_consensus[:50]] + [p["perturbation"] for p in cd_consensus[:50]]
    recurrence = Counter(all_names)
    recurrent = [{"perturbation": k, "count_across_queries": v} for k, v in recurrence.most_common() if v > 1]

    out = {
        "question": "Which LINCS L1000 perturbations reverse the pan-cancer organism-stability disruption signature?",
        "data_sources": [
            "UCSC Xena Toil TCGA/GTEx selected organism-reset genes",
            "L1000CDS2 / LINCS L1000 characteristic direction signatures",
        ],
        "signature_rule": "Use TCGA-vs-GTEx per-gene median deltas across matched tissue contexts. Exclude proliferation genes. Up genes require positive tumor-normal delta in at least 9/13 sites and median delta > 0.15; down genes require negative delta in at least 9/13 sites and median delta < -0.15. Query L1000CDS2 reverse mode.",
        "matched_sites": sig["matched_sites"],
        "up_genes": sig["up_genes"],
        "down_genes": sig["down_genes"],
        "weighted_genes_top80": sig["weighted_genes"][:80],
        "gene_stats": sig["gene_stats"],
        "l1000_gene_set_top50": gene_set_res.get("topMeta", []),
        "l1000_cd_top50": cd_res.get("topMeta", []),
        "gene_set_consensus_by_perturbation": gene_set_consensus,
        "cd_consensus_by_perturbation": cd_consensus,
        "recurrent_across_gene_set_and_cd": recurrent,
        "overlap_with_prism_high_osd_sensitive_hits": compare_with_prism(BASE / "reset_lever_pan_cancer_prism_depmap_results.json", gene_set_consensus + cd_consensus),
        "guardrail": "LINCS reversal predicts transcriptomic opposition to the signature. It is not evidence of clinical efficacy or safety.",
    }
    OUT.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
