#!/usr/bin/env python3
import csv
import gzip
import json
import math
import urllib.request
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent / "xena_cir"
ROOT.mkdir(parents=True, exist_ok=True)

EXPR_URL = "https://toil.xenahubs.net/download/TcgaTargetGtex_rsem_gene_tpm.gz"

MODULES = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1"],
    "inflammatory_alarm": ["IL6", "IL1B", "TNF", "NFKB1", "NFKB2", "RELA", "STAT3", "PTGS2", "CXCL8", "CCL2", "CXCL1", "CXCL2"],
    "interferon_alarm": ["IFNG", "IRF7", "STAT1", "ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "CXCL10", "GBP1"],
    "wound_ecm_fibrosis": ["TGFB1", "TGFBR1", "SMAD2", "SMAD3", "COL1A1", "COL1A2", "COL3A1", "FN1", "VIM", "ACTA2", "MMP2", "MMP9", "TIMP1"],
    "coagulation_complement": ["C3", "C5", "CFB", "CFH", "F2", "F3", "FGA", "FGB", "FGG", "SERPINE1", "PLAU", "PLAT"],
    "hypoxia_redox_stress": ["HIF1A", "VEGFA", "SLC2A1", "CA9", "LDHA", "NFE2L2", "HMOX1", "NQO1", "SOD2", "TXN", "PRDX1"],
    "proteostasis_er_stress": ["HSPA5", "XBP1", "ATF4", "DDIT3", "HSP90AA1", "PSMA1", "PSMB5", "PSMC1", "PSMD1"],
    "bioelectric_junction_order": ["GJA1", "GJB1", "GJB2", "PANX1", "ATP1A1", "ATP1B1", "KCNJ2", "KCNQ1", "CLCN3", "SLC9A1", "VDAC1"],
    "polarity_adhesion_order": ["PARD3", "PARD6A", "PRKCI", "SCRIB", "DLG1", "LLGL1", "CDH1", "ITGA5", "ITGB1", "VCL", "TLN1", "PXN"],
    "circadian_order": ["CLOCK", "ARNTL", "PER1", "PER2", "PER3", "CRY1", "CRY2", "NR1D1", "NR1D2", "RORA", "DBP"],
    "mitochondrial_homeostasis": ["PPARGC1A", "PPARGC1B", "NDUFS1", "NDUFV1", "SDHA", "UQCRC1", "COX4I1", "ATP5F1A", "TFAM", "SIRT3"],
    "differentiation_order": ["NOTCH1", "NOTCH2", "RBPJ", "CTNNB1", "APC", "YAP1", "WWTR1", "TEAD1", "TEAD4", "LATS1", "LATS2"],
}

PRIMARY_SITE_MAP = {
    "Adrenal Gland": "Adrenal Gland",
    "Bladder": "Bladder",
    "Blood": "Blood",
    "Bone Marrow": "Blood",
    "Brain": "Brain",
    "Breast": "Breast",
    "Cervix": "Cervix",
    "Colon": "Colon",
    "Endometrium": "Uterus",
    "Esophagus": "Esophagus",
    "Eye": "Eye",
    "Kidney": "Kidney",
    "Liver": "Liver",
    "Lung": "Lung",
    "Ovary": "Ovary",
    "Pancreas": "Pancreas",
    "Prostate": "Prostate",
    "Rectum": "Colon",
    "Skin": "Skin",
    "Stomach": "Stomach",
    "Testis": "Testis",
    "Thyroid": "Thyroid",
    "Uterus": "Uterus",
}

DETAILED_GTEX_MAP = {
    "Adrenal Gland": "Adrenal Gland",
    "Brain - Amygdala": "Brain",
    "Brain - Anterior cingulate cortex (BA24)": "Brain",
    "Brain - Caudate (basal ganglia)": "Brain",
    "Brain - Cerebellar Hemisphere": "Brain",
    "Brain - Cerebellum": "Brain",
    "Brain - Cortex": "Brain",
    "Brain - Frontal Cortex (BA9)": "Brain",
    "Brain - Hippocampus": "Brain",
    "Brain - Hypothalamus": "Brain",
    "Brain - Nucleus accumbens (basal ganglia)": "Brain",
    "Brain - Putamen (basal ganglia)": "Brain",
    "Brain - Spinal cord (cervical c-1)": "Brain",
    "Brain - Substantia nigra": "Brain",
    "Breast - Mammary Tissue": "Breast",
    "Colon - Sigmoid": "Colon",
    "Colon - Transverse": "Colon",
    "Esophagus - Gastroesophageal Junction": "Esophagus",
    "Esophagus - Mucosa": "Esophagus",
    "Esophagus - Muscularis": "Esophagus",
    "Liver": "Liver",
    "Lung": "Lung",
    "Ovary": "Ovary",
    "Pancreas": "Pancreas",
    "Prostate": "Prostate",
    "Skin - Not Sun Exposed (Suprapubic)": "Skin",
    "Skin - Sun Exposed (Lower leg)": "Skin",
    "Stomach": "Stomach",
    "Testis": "Testis",
    "Thyroid": "Thyroid",
    "Uterus": "Uterus",
    "Whole Blood": "Blood",
}


def zscore(x):
    x = np.asarray(x, dtype=float)
    s = np.nanstd(x)
    if not np.isfinite(s) or s == 0:
        return np.full(x.shape, np.nan)
    return (x - np.nanmean(x)) / s


def residualize(y, covariates):
    if len(covariates) != 1:
        raise ValueError("This script currently uses one residualization covariate.")
    y = np.asarray(y, dtype=float)
    x = zscore(covariates[0])
    mask = np.isfinite(y) & np.isfinite(x)
    out = np.full(y.shape, np.nan)
    if mask.sum() < 30:
        return out
    xm = x[mask] - np.mean(x[mask])
    ym = y[mask] - np.mean(y[mask])
    denom = float(np.dot(xm, xm))
    if denom == 0 or not np.isfinite(denom):
        return out
    out[mask] = ym - float(np.dot(xm, ym) / denom) * xm
    return out


def load_gene_map():
    mapping = {}
    with open(ROOT / "gencode.v23.annotation.gene.probemap") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            mapping.setdefault(row["gene"], row["id"])
    return mapping


def load_phenotype():
    rows = {}
    with gzip.open(ROOT / "TcgaTargetGTEX_phenotype.txt.gz", "rt", encoding="utf-8", errors="replace") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            study = row["_study"]
            sample_type = row["_sample_type"]
            site = None
            label = None
            if study == "TCGA" and sample_type == "Primary Tumor":
                site = PRIMARY_SITE_MAP.get(row["_primary_site"])
                label = "tumor"
            elif study == "GTEX":
                site = DETAILED_GTEX_MAP.get(row["primary disease or tissue"])
                label = "normal"
            if site and label:
                rows[row["sample"]] = {"label": label, "site": site}
    return rows


def extract_expression(ensembl_ids):
    out_path = ROOT / "selected_organism_reset_gene_expression.tsv.gz"
    if out_path.exists():
        return out_path
    wanted = set(ensembl_ids)
    req = urllib.request.Request(EXPR_URL, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=300) as response:
        with gzip.GzipFile(fileobj=response) as gz:
            with gzip.open(out_path, "wt") as out:
                header = gz.readline().decode("utf-8")
                out.write(header)
                found = 0
                for raw in gz:
                    first = raw.split(b"\t", 1)[0].decode("utf-8")
                    if first in wanted:
                        out.write(raw.decode("utf-8"))
                        found += 1
                        if found == len(wanted):
                            break
    return out_path


def bh_q(named_p):
    vals = [(k, p) for k, p in named_p if np.isfinite(p)]
    vals.sort(key=lambda x: x[1])
    m = len(vals)
    out = {}
    prev = 1.0
    for i in range(m, 0, -1):
        k, p = vals[i - 1]
        q = min(prev, p * m / i)
        out[k] = q
        prev = q
    return out


def mannwhitney(tumor, normal):
    tumor = np.asarray(tumor, dtype=float)
    normal = np.asarray(normal, dtype=float)
    tumor = tumor[np.isfinite(tumor)]
    normal = normal[np.isfinite(normal)]
    if len(tumor) < 10 or len(normal) < 10:
        return {"delta": math.nan, "auc": math.nan, "p": math.nan}
    stat = stats.mannwhitneyu(tumor, normal, alternative="two-sided")
    return {
        "tumor_mean": float(np.mean(tumor)),
        "normal_mean": float(np.mean(normal)),
        "delta": float(np.mean(tumor) - np.mean(normal)),
        "auc_tumor_higher": float(stat.statistic / (len(tumor) * len(normal))),
        "p": float(stat.pvalue),
    }


def main():
    gene_map = load_gene_map()
    wanted = sorted({g for genes in MODULES.values() for g in genes})
    gene_to_id = {g: gene_map[g] for g in wanted if g in gene_map}
    id_to_gene = {v: k for k, v in gene_to_id.items()}
    expr_path = extract_expression(gene_to_id.values())
    phen = load_phenotype()

    with gzip.open(expr_path, "rt") as f:
        header = f.readline().rstrip("\n").split("\t")
        all_samples = header[1:]
        keep_idx = [i for i, s in enumerate(all_samples) if s in phen]
        samples = [all_samples[i] for i in keep_idx]
        data = {}
        for line in f:
            parts = line.rstrip("\n").split("\t")
            gene = id_to_gene.get(parts[0])
            if gene:
                data[gene] = np.array([float(parts[i + 1]) for i in keep_idx], dtype=float)

    labels = np.array([phen[s]["label"] for s in samples])
    sites = np.array([phen[s]["site"] for s in samples])
    matched_sites = sorted({
        site for site in set(sites)
        if np.sum((sites == site) & (labels == "tumor")) >= 20
        and np.sum((sites == site) & (labels == "normal")) >= 20
    })
    keep = np.array([site in matched_sites for site in sites])
    labels = labels[keep]
    sites = sites[keep]
    samples = [s for s, ok in zip(samples, keep) if ok]
    for gene in data:
        data[gene] = data[gene][keep]

    gene_z = {g: zscore(v) for g, v in data.items()}
    module_scores = {}
    found = {}
    for module, genes in MODULES.items():
        gs = [g for g in genes if g in gene_z]
        found[module] = gs
        module_scores[module] = np.nanmean(np.vstack([gene_z[g] for g in gs]), axis=0)

    instability_load = (
        zscore(module_scores["inflammatory_alarm"])
        + zscore(module_scores["interferon_alarm"])
        + zscore(module_scores["wound_ecm_fibrosis"])
        + zscore(module_scores["coagulation_complement"])
        + zscore(module_scores["hypoxia_redox_stress"])
        + zscore(module_scores["proteostasis_er_stress"])
    )
    order_capacity = (
        zscore(module_scores["bioelectric_junction_order"])
        + zscore(module_scores["polarity_adhesion_order"])
        + zscore(module_scores["circadian_order"])
        + zscore(module_scores["mitochondrial_homeostasis"])
        + zscore(module_scores["differentiation_order"])
    )
    osi_raw = instability_load - order_capacity
    osi_residual = residualize(osi_raw, [module_scores["proliferation"]])

    tested_vectors = {
        **module_scores,
        "instability_load": instability_load,
        "order_capacity": order_capacity,
        "organism_stability_disruption_raw": osi_raw,
        "organism_stability_disruption_residual": osi_residual,
    }

    site_results = []
    for site in matched_sites:
        idx = sites == site
        tumor = labels[idx] == "tumor"
        row = {"site": site, "n_tumor": int(tumor.sum()), "n_normal": int((~tumor).sum())}
        for name, vec in tested_vectors.items():
            row[name] = mannwhitney(vec[idx][tumor], vec[idx][~tumor])
        site_results.append(row)

    for name in tested_vectors:
        q = bh_q([((r["site"], name), r[name]["p"]) for r in site_results])
        for r in site_results:
            r[name]["q"] = q.get((r["site"], name), math.nan)

    summary = {}
    for name in tested_vectors:
        deltas = [r[name]["delta"] for r in site_results if np.isfinite(r[name]["delta"])]
        aucs = [r[name]["auc_tumor_higher"] for r in site_results if np.isfinite(r[name]["auc_tumor_higher"])]
        summary[name] = {
            "n_sites": len(deltas),
            "median_delta": float(np.median(deltas)) if deltas else math.nan,
            "positive_sites": int(sum(d > 0 for d in deltas)),
            "negative_sites": int(sum(d < 0 for d in deltas)),
            "median_auc": float(np.median(aucs)) if aucs else math.nan,
            "fdr_0_05_positive": int(sum(r[name]["q"] < 0.05 and r[name]["delta"] > 0 for r in site_results)),
            "fdr_0_05_negative": int(sum(r[name]["q"] < 0.05 and r[name]["delta"] < 0 for r in site_results)),
        }

    out = {
        "question": "Is there a common organism-level stability disruption axis across cancers, beyond proliferation?",
        "data_source": "UCSC Xena Toil TCGA/TARGET/GTEx gene expression; TCGA primary tumors vs GTEx normal tissues.",
        "concept": {
            "instability_load": "inflammatory/interferon alarm + wound/ECM/fibrosis + coagulation/complement + hypoxia/redox + ER/proteostasis stress",
            "order_capacity": "bioelectric/junction order + polarity/adhesion + circadian order + mitochondrial homeostasis + differentiation order",
            "organism_stability_disruption_raw": "instability_load - order_capacity",
            "organism_stability_disruption_residual": "raw score after removing proliferation",
        },
        "n_samples": int(len(samples)),
        "n_tumor": int(np.sum(labels == "tumor")),
        "n_normal": int(np.sum(labels == "normal")),
        "matched_sites": matched_sites,
        "module_genes_found": found,
        "summary": summary,
        "site_results": site_results,
        "guardrail": "This tests transcriptomic organism-stability signatures, not a treatment or clinical reset protocol. GTEx normals are not patient-matched controls.",
    }
    out_path = ROOT / "organism_reset_axis_tcga_gtex_results.json"
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
