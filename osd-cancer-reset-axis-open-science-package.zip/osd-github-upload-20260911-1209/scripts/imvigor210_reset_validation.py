#!/usr/bin/env python3
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import rdata
from lifelines import CoxPHFitter
from rdata.parser import RObjectType
from scipy import stats
from sklearn.metrics import roc_auc_score
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parent
PKG = ROOT / "IMvigor210CoreBiologies"
OUT = Path(__file__).resolve().parents[2] / "outputs"

MODULES = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1"],
    "inflammatory_alarm": ["IL6", "IL1B", "TNF", "NFKB1", "NFKB2", "RELA", "STAT3", "PTGS2", "CXCL8", "CCL2", "CXCL1", "CXCL2"],
    "interferon_alarm": ["IFNG", "IRF7", "STAT1", "ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "CXCL10", "GBP1"],
    "wound_ecm_fibrosis": ["TGFB1", "TGFBR1", "SMAD2", "SMAD3", "COL1A1", "COL1A2", "COL3A1", "FN1", "VIM", "ACTA2", "MMP2", "MMP9", "TIMP1"],
    "coagulation_complement": ["C3", "C5", "CFB", "CFH", "F2", "F3", "FGA", "FGB", "FGG", "SERPINE1", "PLAU", "PLAT"],
    "hypoxia_redox_stress": ["HIF1A", "VEGFA", "SLC2A1", "CA9", "LDHA", "NFE2L2", "HMOX1", "NQO1", "SOD2", "TXN", "PRDX1"],
    "proteostasis_er_stress": ["HSPA5", "XBP1", "ATF4", "DDIT3", "HSP90AA1", "PSMA1", "PSMB5", "PSMC1", "PSMD1"],
    "bioelectric_junction_order": ["GJA1", "GJB1", "GJB2", "PANX1", "ATP1A1", "ATP1B1", "KCNJ2", "KCNQ1", "CLCN3", "SLC9A1", "VDAC1"],
    "polarity_adhesion_order": ["PARD3", "PARD6A", "PRKCI", "SCRIB", "DLG1", "LLGL1", "CDH1", "ITGA5", "ITGB1", "VCL", "TLN1", "PXN"],
    "circadian_order": ["CLOCK", "ARNTL", "PER1", "PER2", "PER3", "CRY1", "CRY2", "NR1D1", "NR1D2", "RORA", "DBP"],
    "mitochondrial_homeostasis": ["PPARGC1A", "PPARGC1B", "NDUFS1", "NDUFV1", "SDHA", "UQCRC1", "COX4I1", "ATP5F1A", "TFAM", "SIRT3"],
    "differentiation_order": ["NOTCH1", "NOTCH2", "RBPJ", "CTNNB1", "APC", "YAP1", "WWTR1", "TEAD1", "TEAD4", "LATS1", "LATS2"],
}


def deref(o):
    while o is not None and o.info.type == RObjectType.REF and o.referenced_object is not None:
        o = o.referenced_object
    return o


def r_char(o):
    o = deref(o)
    if o is None:
        return None
    if o.info.type == RObjectType.SYM:
        return r_char(o.value)
    if o.info.type == RObjectType.CHAR:
        if o.value is None:
            return None
        return o.value.decode() if isinstance(o.value, bytes) else o.value
    if o.info.type == RObjectType.STR:
        return [r_char(x) for x in o.value]
    return None


def list_items(o, limit=100000):
    items = []
    cur = deref(o)
    n = 0
    while cur is not None and cur.info.type != RObjectType.NILVALUE and n < limit:
        cur = deref(cur)
        if cur.info.type not in (RObjectType.LIST, RObjectType.LANG):
            break
        items.append((r_char(cur.tag), deref(cur.value[0])))
        cur = cur.value[1]
        n += 1
    return items


def attrs(o):
    o = deref(o)
    return dict(list_items(o.attributes)) if o.attributes is not None else {}


def convert_column(o):
    o = deref(o)
    a = attrs(o)
    levels = r_char(a.get("levels")) if a.get("levels") is not None else None
    if o.info.type in (RObjectType.INT, RObjectType.REAL, RObjectType.LGL):
        vals = np.asarray(o.value)
        if levels:
            out = []
            for v in vals:
                if np.ma.is_masked(v) or pd.isna(v) or int(v) <= 0:
                    out.append(np.nan)
                else:
                    out.append(levels[int(v) - 1])
            return out
        return [np.nan if np.ma.is_masked(v) else float(v) for v in vals]
    if o.info.type == RObjectType.STR:
        return r_char(o)
    return list(o.value)


def load_cds():
    parsed = rdata.parser.parse_file(PKG / "data" / "cds.RData")
    cds = parsed.object.value[0]
    slots = dict(list_items(cds.attributes))

    pheno_obj = attrs(slots["phenoData"])["data"]
    pheno_attrs = attrs(pheno_obj)
    pheno_cols = r_char(pheno_attrs["names"])
    sample_names = r_char(pheno_attrs["row.names"])
    pheno = pd.DataFrame({name: convert_column(col) for name, col in zip(pheno_cols, pheno_obj.value)}, index=sample_names)

    feature_obj = attrs(slots["featureData"])["data"]
    feature_attrs = attrs(feature_obj)
    feature_cols = r_char(feature_attrs["names"])
    gene_row_names = r_char(feature_attrs["row.names"])
    features = pd.DataFrame({name: convert_column(col) for name, col in zip(feature_cols, feature_obj.value)}, index=gene_row_names)

    counts = None
    for bucket in slots["assayData"].value.hash_table.value:
        for key, value in list_items(bucket):
            if key == "counts":
                ca = attrs(value)
                dim = ca["dim"].value
                dimnames = ca["dimnames"].value
                row_ids = r_char(dimnames[0])
                col_ids = r_char(dimnames[1])
                arr = np.asarray(value.value, dtype=float).reshape(tuple(dim), order="F")
                counts = pd.DataFrame(arr, index=row_ids, columns=col_ids)
                break
    if counts is None:
        raise RuntimeError("counts not found")
    return counts, features, pheno


def zscore(x):
    x = np.asarray(x, dtype=float)
    s = np.nanstd(x)
    if not np.isfinite(s) or s == 0:
        return np.zeros_like(x)
    return (x - np.nanmean(x)) / s


def residualize(y, covariates):
    y = np.asarray(y, dtype=float)
    x = np.column_stack([zscore(c) for c in covariates])
    mask = np.isfinite(y) & np.all(np.isfinite(x), axis=1)
    out = np.full(y.shape, np.nan)
    if mask.sum() < x.shape[1] + 10:
        return out
    X = np.column_stack([np.ones(mask.sum()), x[mask]])
    beta = np.linalg.lstsq(X, y[mask], rcond=None)[0]
    out[mask] = y[mask] - X @ beta
    return out


def module_scores(counts, features, pheno):
    sample_ids = list(pheno.index)
    size_factor = pheno["sizeFactor"].astype(float).reindex(sample_ids).to_numpy()
    counts = counts.reindex(columns=sample_ids)

    symbol_by_entrez = features["Symbol"].fillna(features["symbol"]).astype(str).to_dict()
    wanted = sorted({g for genes in MODULES.values() for g in genes})
    gene_to_rows = {g: [] for g in wanted}
    for entrez, symbol in symbol_by_entrez.items():
        if symbol in gene_to_rows and entrez in counts.index:
            gene_to_rows[symbol].append(entrez)

    norm = np.log2(counts.to_numpy(dtype=float) / size_factor.reshape(1, -1) + 1.0)
    row_index = {gene_id: i for i, gene_id in enumerate(counts.index)}

    gene_vectors = {}
    for gene, row_ids in gene_to_rows.items():
        rows = [row_index[r] for r in row_ids if r in row_index]
        if rows:
            gene_vectors[gene] = np.nanmean(norm[rows, :], axis=0)

    scores = {}
    found = {}
    for module, genes in MODULES.items():
        present = [g for g in genes if g in gene_vectors]
        found[module] = present
        scores[module] = np.nanmean(np.vstack([zscore(gene_vectors[g]) for g in present]), axis=0)

    instability = sum(zscore(scores[name]) for name in [
        "inflammatory_alarm",
        "interferon_alarm",
        "wound_ecm_fibrosis",
        "coagulation_complement",
        "hypoxia_redox_stress",
        "proteostasis_er_stress",
    ])
    order = sum(zscore(scores[name]) for name in [
        "bioelectric_junction_order",
        "polarity_adhesion_order",
        "circadian_order",
        "mitochondrial_homeostasis",
        "differentiation_order",
    ])
    scores["instability_load"] = instability
    scores["order_capacity"] = order
    scores["osd_raw"] = instability - order
    scores["osd_residual_vs_proliferation"] = residualize(scores["osd_raw"], [scores["proliferation"]])
    return pd.DataFrame(scores, index=sample_ids), found


def bh_q(pairs):
    vals = [(k, p) for k, p in pairs if np.isfinite(p)]
    vals.sort(key=lambda x: x[1])
    m = len(vals)
    out = {}
    prev = 1.0
    for i in range(m, 0, -1):
        k, p = vals[i - 1]
        q = min(prev, p * m / i)
        out[k] = q
        prev = q
    return out


def response_test(df, score):
    sub = df[df["binaryResponse"].isin(["CR/PR", "SD/PD"])].copy()
    responders = sub.loc[sub["binaryResponse"] == "CR/PR", score].astype(float).dropna()
    nonresp = sub.loc[sub["binaryResponse"] == "SD/PD", score].astype(float).dropna()
    if len(responders) < 5 or len(nonresp) < 5:
        return {}
    u = stats.mannwhitneyu(nonresp, responders, alternative="two-sided")
    y = (sub["binaryResponse"] == "SD/PD").astype(int).to_numpy()
    x = sub[score].astype(float).to_numpy()
    mask = np.isfinite(x)
    auc = roc_auc_score(y[mask], x[mask])
    rng = np.random.default_rng(100)
    obs = float(np.median(nonresp) - np.median(responders))
    labels = sub.loc[mask, "binaryResponse"].to_numpy()
    xv = x[mask]
    count = 0
    for _ in range(10000):
        lab = rng.permutation(labels)
        perm = np.median(xv[lab == "SD/PD"]) - np.median(xv[lab == "CR/PR"])
        if abs(perm) >= abs(obs):
            count += 1
    return {
        "n_responders": int(len(responders)),
        "n_nonresponders": int(len(nonresp)),
        "median_nonresponder": float(np.median(nonresp)),
        "median_responder": float(np.median(responders)),
        "delta_nonresponder_minus_responder": obs,
        "auc_nonresponder_higher": float(auc),
        "mannwhitney_p": float(u.pvalue),
        "permutation_p": float((count + 1) / 10001),
    }


def logistic_models(df, score):
    sub = df[df["binaryResponse"].isin(["CR/PR", "SD/PD"])].copy()
    sub["nonresponse"] = (sub["binaryResponse"] == "SD/PD").astype(int)
    keep = ["nonresponse", score, "FMOne mutation burden per MB", "Enrollment IC", "Baseline ECOG Score"]
    m = sub[keep].dropna().copy()
    if len(m) < 50:
        return {}
    ic_map = {"IC0": 0, "IC1": 1, "IC2": 2}
    if m["Enrollment IC"].dtype == object:
        m["Enrollment_IC_num"] = m["Enrollment IC"].map(ic_map)
    else:
        m["Enrollment_IC_num"] = m["Enrollment IC"].astype(float)
    m = m.dropna()
    predictors = {
        "score_only": [score],
        "clinical_tmb_ic_ecog": ["FMOne mutation burden per MB", "Enrollment_IC_num", "Baseline ECOG Score"],
        "score_plus_tmb_ic_ecog": [score, "FMOne mutation burden per MB", "Enrollment_IC_num", "Baseline ECOG Score"],
    }
    out = {}
    for name, cols in predictors.items():
        X = m[cols].astype(float).apply(zscore)
        X = sm.add_constant(X, has_constant="add")
        try:
            fit = sm.Logit(m["nonresponse"], X).fit(disp=False, maxiter=200)
            out[name] = {
                "n": int(len(m)),
                "aic": float(fit.aic),
                "params": {k: float(v) for k, v in fit.params.items()},
                "pvalues": {k: float(v) for k, v in fit.pvalues.items()},
            }
        except Exception as e:
            out[name] = {"error": str(e)}
    return out


def cox_test(df, score):
    cols = ["os", "censOS", score, "FMOne mutation burden per MB", "Enrollment IC", "Baseline ECOG Score"]
    sub = df[cols].copy()
    ic_map = {"IC0": 0, "IC1": 1, "IC2": 2}
    if sub["Enrollment IC"].dtype == object:
        sub["Enrollment_IC_num"] = sub["Enrollment IC"].map(ic_map)
    else:
        sub["Enrollment_IC_num"] = sub["Enrollment IC"].astype(float)
    sub = sub.drop(columns=["Enrollment IC"]).dropna()
    if len(sub) < 50:
        return {}
    sub[score] = zscore(sub[score])
    for c in ["FMOne mutation burden per MB", "Enrollment_IC_num", "Baseline ECOG Score"]:
        sub[c] = zscore(sub[c])
    out = {}
    for name, cols2 in {
        "score_only": [score],
        "score_plus_tmb_ic_ecog": [score, "FMOne mutation burden per MB", "Enrollment_IC_num", "Baseline ECOG Score"],
    }.items():
        data = sub[["os", "censOS"] + cols2].copy()
        cph = CoxPHFitter()
        try:
            cph.fit(data, duration_col="os", event_col="censOS", show_progress=False)
            row = cph.summary.loc[score]
            out[name] = {
                "n": int(len(data)),
                "events": int(data["censOS"].sum()),
                "hr_per_sd": float(row["exp(coef)"]),
                "p": float(row["p"]),
                "ci95_low": float(row["exp(coef) lower 95%"]),
                "ci95_high": float(row["exp(coef) upper 95%"]),
            }
        except Exception as e:
            out[name] = {"error": str(e)}
    return out


def main():
    counts, features, pheno = load_cds()
    scores, found = module_scores(counts, features, pheno)
    df = pheno.join(scores)

    score_names = [
        "osd_raw",
        "osd_residual_vs_proliferation",
        "instability_load",
        "order_capacity",
        "wound_ecm_fibrosis",
        "proteostasis_er_stress",
        "hypoxia_redox_stress",
        "interferon_alarm",
        "circadian_order",
        "mitochondrial_homeostasis",
        "proliferation",
    ]
    response = {s: response_test(df, s) for s in score_names}
    q = bh_q([(s, response[s].get("mannwhitney_p", math.nan)) for s in score_names])
    for s in score_names:
        response[s]["fdr_q_across_modules"] = q.get(s, math.nan)

    selected = ["osd_raw", "osd_residual_vs_proliferation", "wound_ecm_fibrosis", "proteostasis_er_stress", "hypoxia_redox_stress", "proliferation"]
    cox = {s: cox_test(df, s) for s in selected}
    logistic = {s: logistic_models(df, s) for s in selected}

    export_cols = [
        "Best Confirmed Overall Response",
        "binaryResponse",
        "Immune phenotype",
        "FMOne mutation burden per MB",
        "Enrollment IC",
        "Baseline ECOG Score",
        "os",
        "censOS",
    ] + score_names
    df[export_cols].to_csv(ROOT / "imvigor210_reset_scores.csv")

    result = {
        "question": "Large real-patient validation: does the pre-specified organism reset/stability axis mark immunotherapy non-response and survival in IMvigor210?",
        "data_source": "IMvigor210CoreBiologies cds.RData, atezolizumab-treated metastatic urothelial cancer.",
        "n_samples": int(len(df)),
        "n_genes": int(len(counts)),
        "response_counts": df["Best Confirmed Overall Response"].value_counts(dropna=False).to_dict(),
        "binary_response_counts": df["binaryResponse"].value_counts(dropna=False).to_dict(),
        "module_genes_found": found,
        "response_tests_sd_pd_vs_cr_pr": response,
        "cox_os_tests": cox,
        "logistic_nonresponse_models": logistic,
        "guardrail": "Observational retrospective public-data validation; not a clinical treatment recommendation.",
    }
    (ROOT / "imvigor210_reset_validation_results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")

    report = [
        "# IMvigor210 Large Reset-Axis Validation",
        "",
        "## Question",
        "Does the pre-specified organism stability / reset axis predict real immunotherapy outcome in a substantially larger clinical cohort?",
        "",
        "## Dataset",
        "- IMvigor210CoreBiologies `cds.RData`, metastatic urothelial carcinoma treated with atezolizumab.",
        f"- Samples: {len(df)}.",
        f"- Genes: {len(counts)}.",
        f"- Best overall response counts: {result['response_counts']}.",
        f"- Binary response counts: {result['binary_response_counts']}.",
        "",
        "## Primary Response Test",
        "Positive delta means the score is higher in SD/PD non-responders than CR/PR responders.",
    ]
    for s in score_names:
        r = response[s]
        report.append(
            f"- {s}: delta {r['delta_nonresponder_minus_responder']:.3f}, "
            f"AUC nonresponder-higher {r['auc_nonresponder_higher']:.3f}, "
            f"p={r['mannwhitney_p']:.4g}, q={r['fdr_q_across_modules']:.4g}."
        )
    report += [
        "",
        "## Overall Survival",
        "Hazard ratios are per 1 SD higher score. Adjusted models include TMB, enrollment PD-L1 immune-cell level, and ECOG.",
    ]
    for s in selected:
        base = cox[s].get("score_only", {})
        adj = cox[s].get("score_plus_tmb_ic_ecog", {})
        report.append(
            f"- {s}: unadjusted HR {base.get('hr_per_sd', math.nan):.3f}, p={base.get('p', math.nan):.4g}; "
            f"adjusted HR {adj.get('hr_per_sd', math.nan):.3f}, p={adj.get('p', math.nan):.4g}."
        )
    report += [
        "",
        "## Clinical-Covariate Check",
        "AIC compares logistic non-response models. Lower AIC is better; this checks whether the score adds signal beyond TMB, PD-L1 IC level, and ECOG.",
    ]
    for s in selected:
        lm = logistic[s]
        clinical = lm.get("clinical_tmb_ic_ecog", {})
        plus = lm.get("score_plus_tmb_ic_ecog", {})
        score_p = plus.get("pvalues", {}).get(s, math.nan)
        report.append(
            f"- {s}: clinical AIC {clinical.get('aic', math.nan):.2f}; "
            f"clinical+score AIC {plus.get('aic', math.nan):.2f}; score p={score_p:.4g}."
        )
    report += [
        "",
        "## Interpretation",
        "This is a much stronger validation layer than the small melanoma cohort because it uses hundreds of clinical trial samples and known covariates.",
        "",
        "The result should be interpreted as a biomarker/stability-state test, not as evidence for a treatment. A lab-replicable next step is to select high-score vs low-score tumor models from this axis and test whether perturbations move the full trajectory rather than merely kill cells.",
    ]
    report_path = OUT / "imvigor210_large_reset_validation_report.md"
    report_path.write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
