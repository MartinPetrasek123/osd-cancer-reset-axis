#!/usr/bin/env python3
import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent

RNG_SEED = 20260910
MIN_LINEAGE_N = 12
N_PERM = 5000
N_RANDOM_SETS = 2000

CANDIDATE_GROUPS = {
    "DDR_checkpoint": ["ATR", "ATM", "CHEK1", "CHEK2", "WEE1", "CLSPN", "TOPBP1", "RAD51", "BRCA1", "BRCA2", "PARP1", "PRKDC"],
    "mitosis_CIN_tolerance": ["BUB1", "BUB1B", "BUB3", "MAD2L1", "AURKA", "AURKB", "PLK1", "TTK", "KIF11", "CENPE", "CDC20"],
    "proteostasis_stress": ["PSMA1", "PSMB5", "PSMC1", "PSMD1", "HSP90AA1", "HSP90AB1", "HSPA5", "HYOU1", "XBP1", "ERN1", "ATF4", "DDIT3"],
    "autophagy_metabolic_stress": ["MTOR", "ULK1", "BECN1", "ATG5", "ATG7", "MAP1LC3B", "SQSTM1", "PRKAA1"],
    "apoptosis_reset": ["BCL2", "BCL2L1", "MCL1", "BAX", "BAK1", "CASP3", "CASP8", "TP53"],
    "immune_visibility": ["B2M", "HLA-A", "HLA-B", "HLA-C", "TAP1", "TAP2", "NLRC5", "JAK1", "JAK2", "STING1", "TMEM173", "MB21D1"],
}


def gene_symbol(header_name):
    return header_name.split(" (", 1)[0]


def rank_norm(x):
    x = np.asarray(x, dtype=float)
    mask = np.isfinite(x)
    out = np.full(x.shape, np.nan)
    if mask.sum() < 3:
        return out
    ranks = stats.rankdata(x[mask], method="average")
    u = (ranks - 0.5) / mask.sum()
    out[mask] = stats.norm.ppf(u)
    return out


def bh_fdr(pvals):
    p = np.asarray(pvals, dtype=float)
    q = np.full(p.shape, np.nan)
    mask = np.isfinite(p)
    vals = p[mask]
    order = np.argsort(vals)
    ranked = vals[order]
    n = len(ranked)
    adj = np.empty(n, dtype=float)
    prev = 1.0
    for i in range(n - 1, -1, -1):
        val = min(prev, ranked[i] * n / (i + 1))
        adj[i] = val
        prev = val
    restored = np.empty(n, dtype=float)
    restored[order] = adj
    q[mask] = restored
    return q


def load_lineage():
    out = {}
    with open(ROOT / "Model.csv", newline="") as f:
        for row in csv.DictReader(f):
            lineage = row.get("OncotreeLineage") or row.get("OncotreePrimaryDisease") or "Unknown"
            out[row["ModelID"]] = lineage
    return out


def load_cn_instability():
    scores = {}
    frac_alt = {}
    mean_abs_dev = {}
    high_amp = {}
    with open(ROOT / "OmicsAbsoluteCNGene.csv", newline="") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            mid = row[0]
            vals = np.array([float(x) if x else np.nan for x in row[1:]], dtype=float)
            finite = np.isfinite(vals)
            if finite.sum() < 1000:
                continue
            v = vals[finite]
            frac = float(np.mean(np.abs(v - 2.0) >= 0.5))
            mad = float(np.mean(np.abs(v - 2.0)))
            amp = float(np.mean((v <= 1.0) | (v >= 4.0)))
            scores[mid] = float(np.mean([rank_norm(np.array([frac]))[0] if False else frac, mad, amp]))
            frac_alt[mid] = frac
            mean_abs_dev[mid] = mad
            high_amp[mid] = amp
    return scores, frac_alt, mean_abs_dev, high_amp


def load_crispr_matrix(common_models):
    common_set = set(common_models)
    with open(ROOT / "CRISPRGeneEffect.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        genes = [gene_symbol(h) for h in header[1:]]
        rows = {}
        for row in reader:
            mid = row[0]
            if mid not in common_set:
                continue
            arr = np.array([float(x) if x else np.nan for x in row[1:]], dtype=float)
            rows[mid] = arr
    model_order = [m for m in common_models if m in rows]
    matrix = np.vstack([rows[m] for m in model_order])
    return genes, model_order, matrix


def lineage_residualize(values, lineages):
    values = np.asarray(values, dtype=float)
    lineages = np.asarray(lineages)
    out = np.full(values.shape, np.nan)
    for lineage in sorted(set(lineages)):
        idx = np.where(lineages == lineage)[0]
        if len(idx) < MIN_LINEAGE_N:
            continue
        v = values[idx]
        mask = np.isfinite(v)
        if mask.sum() < MIN_LINEAGE_N:
            continue
        mu = np.nanmean(v)
        sd = np.nanstd(v)
        if np.isfinite(sd) and sd > 0:
            out[idx] = (v - mu) / sd
    return out


def residualize_matrix(matrix, lineages):
    out = np.full(matrix.shape, np.nan)
    for lineage in sorted(set(lineages)):
        idx = np.where(lineages == lineage)[0]
        if len(idx) < MIN_LINEAGE_N:
            continue
        block = matrix[idx, :]
        mu = np.nanmean(block, axis=0)
        sd = np.nanstd(block, axis=0)
        ok = np.isfinite(sd) & (sd > 0)
        out[np.ix_(idx, ok)] = (block[:, ok] - mu[ok]) / sd[ok]
    return out


def safe_spearman(x, y):
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 100:
        return math.nan, math.nan, int(mask.sum())
    r, p = stats.spearmanr(x[mask], y[mask])
    return float(r), float(p), int(mask.sum())


def permutation_p(x, y, lineages, observed_r, rng):
    mask = np.isfinite(x) & np.isfinite(y)
    x0 = x[mask]
    y0 = y[mask]
    lin0 = np.asarray(lineages)[mask]
    obs = abs(observed_r)
    hits = 0
    for _ in range(N_PERM):
        yp = y0.copy()
        for lineage in sorted(set(lin0)):
            idx = np.where(lin0 == lineage)[0]
            yp[idx] = rng.permutation(yp[idx])
        rp, _ = stats.spearmanr(x0, yp)
        if abs(rp) >= obs:
            hits += 1
    return float((hits + 1) / (N_PERM + 1))


def lineage_meta(x, y, lineages):
    zs = []
    details = []
    for lineage in sorted(set(lineages)):
        idx = np.where(np.asarray(lineages) == lineage)[0]
        mask = np.isfinite(x[idx]) & np.isfinite(y[idx])
        n = int(mask.sum())
        if n < MIN_LINEAGE_N:
            continue
        r, p = stats.spearmanr(x[idx][mask], y[idx][mask])
        if np.isfinite(r) and abs(r) < 1:
            z = np.arctanh(r) * math.sqrt(max(n - 3, 1))
            zs.append(z)
            details.append({"lineage": lineage, "n": n, "spearman_r": float(r), "p": float(p)})
    if not zs:
        return math.nan, math.nan, []
    z_meta = float(np.sum(zs) / math.sqrt(len(zs)))
    p_meta = float(2 * stats.norm.sf(abs(z_meta)))
    pos = sum(1 for d in details if d["spearman_r"] > 0)
    return z_meta, p_meta, [{"positive_lineages": pos, "tested_lineages": len(details)}] + details


def group_dependency(dep_z, gene_to_idx, genes):
    idx = [gene_to_idx[g] for g in genes if g in gene_to_idx]
    if not idx:
        return None, []
    return np.nanmean(dep_z[:, idx], axis=1), [g for g in genes if g in gene_to_idx]


def main():
    rng = np.random.default_rng(RNG_SEED)
    lineage_map = load_lineage()
    cn_score, frac_alt, mean_abs_dev, high_amp = load_cn_instability()
    common = sorted(set(lineage_map) & set(cn_score))
    genes, models, effect = load_crispr_matrix(common)
    lineages = np.array([lineage_map[m] for m in models])

    cn_raw = np.array([cn_score[m] for m in models], dtype=float)
    cn_z = lineage_residualize(rank_norm(cn_raw), lineages)
    dep_z = residualize_matrix(-effect, lineages)
    gene_to_idx = {}
    for i, g in enumerate(genes):
        gene_to_idx.setdefault(g, i)

    group_rows = []
    random_universe = np.array([i for i, g in enumerate(genes) if np.isfinite(dep_z[:, i]).sum() >= 500])
    random_results = {}

    for group, wanted in CANDIDATE_GROUPS.items():
        y, found = group_dependency(dep_z, gene_to_idx, wanted)
        if y is None:
            continue
        r, p, n = safe_spearman(cn_z, y)
        pp = permutation_p(cn_z, y, lineages, r, rng)
        z_meta, p_meta, lineage_details = lineage_meta(cn_z, y, lineages)

        rand_rs = []
        size = len(found)
        for _ in range(N_RANDOM_SETS):
            idx = rng.choice(random_universe, size=size, replace=False)
            yr = np.nanmean(dep_z[:, idx], axis=1)
            rr, _, _ = safe_spearman(cn_z, yr)
            if np.isfinite(rr):
                rand_rs.append(rr)
        rand_rs = np.array(rand_rs, dtype=float)
        random_empirical = float((np.sum(np.abs(rand_rs) >= abs(r)) + 1) / (len(rand_rs) + 1))
        random_results[group] = {
            "candidate_r": r,
            "random_gene_sets": int(len(rand_rs)),
            "random_abs_r_ge_candidate_empirical_p": random_empirical,
            "random_r_mean": float(np.nanmean(rand_rs)),
            "random_r_sd": float(np.nanstd(rand_rs)),
        }

        group_rows.append({
            "group": group,
            "genes_found": found,
            "n": n,
            "pooled_spearman_r": r,
            "pooled_spearman_p": p,
            "within_lineage_permutation_p": pp,
            "lineage_meta_z": z_meta,
            "lineage_meta_p": p_meta,
            "lineage_meta_summary": lineage_details[0] if lineage_details else {},
            "random_gene_set_empirical_p": random_empirical,
        })

    qs = bh_fdr([row["pooled_spearman_p"] for row in group_rows])
    for row, q in zip(group_rows, qs):
        row["pooled_spearman_bh_fdr"] = float(q)
    group_rows.sort(key=lambda row: row["pooled_spearman_p"])

    gene_rows = []
    candidate_genes = sorted({g for group in CANDIDATE_GROUPS.values() for g in group if g in gene_to_idx})
    for gene in candidate_genes:
        y = dep_z[:, gene_to_idx[gene]]
        r, p, n = safe_spearman(cn_z, y)
        gene_rows.append({"gene": gene, "n": n, "pooled_spearman_r": r, "pooled_spearman_p": p})
    gq = bh_fdr([row["pooled_spearman_p"] for row in gene_rows])
    for row, q in zip(gene_rows, gq):
        row["pooled_spearman_bh_fdr"] = float(q)
    gene_rows.sort(key=lambda row: row["pooled_spearman_p"])

    out = {
        "data_source": "DepMap 24Q4 Public Figshare bulk files: Model.csv, OmicsAbsoluteCNGene.csv, CRISPRGeneEffect.csv.",
        "pre_specified_primary_test": "Within-lineage rank-normalized copy-number instability versus candidate module CRISPR dependency. Dependency is -DepMap gene effect, so higher means stronger dependency.",
        "copy_number_instability_metric": "Mean of fraction genes altered from diploid by >=0.5 copies, mean absolute deviation from 2 copies, and fraction genes with CN<=1 or CN>=4.",
        "controls": {
            "lineage_residualization_min_n": MIN_LINEAGE_N,
            "within_lineage_permutations": N_PERM,
            "random_gene_sets_per_group": N_RANDOM_SETS,
            "multiple_testing": "Benjamini-Hochberg FDR over pre-specified modules and separately over candidate genes.",
        },
        "n_models_with_cn_and_crispr": len(models),
        "n_lineages": int(len(set(lineages))),
        "group_results": group_rows,
        "top_candidate_gene_results": gene_rows[:50],
        "random_gene_set_controls": random_results,
    }
    (ROOT / "rigorous_depmap_onco_reset_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
