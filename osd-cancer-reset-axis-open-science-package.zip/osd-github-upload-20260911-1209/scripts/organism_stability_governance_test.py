#!/usr/bin/env python3
import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent
MIN_LINEAGE_N = 12
MIN_NONCANCER_N = 8

GOVERNANCE_MODULES = {
    "hippo_yap_taz": ["YAP1", "WWTR1", "TEAD1", "TEAD2", "TEAD3", "TEAD4", "LATS1", "LATS2", "MST1", "MST2", "SAV1", "NF2"],
    "tgfb_smad_context": ["TGFB1", "TGFBR1", "TGFBR2", "SMAD2", "SMAD3", "SMAD4", "SMAD7", "SKI", "SKIL"],
    "wnt_beta_catenin": ["CTNNB1", "APC", "AXIN1", "AXIN2", "GSK3B", "TCF7", "TCF7L1", "TCF7L2", "LEF1", "WNT5A"],
    "notch_fate": ["NOTCH1", "NOTCH2", "NOTCH3", "NOTCH4", "RBPJ", "MAML1", "MAML2", "DLL1", "DLL4", "JAG1", "JAG2"],
    "cell_polarity": ["PARD3", "PARD6A", "PRKCI", "PRKCZ", "SCRIB", "DLG1", "LLGL1", "CRB3", "VANGL1", "VANGL2"],
    "adhesion_ecm_integrin": ["CDH1", "CDH2", "ITGA5", "ITGB1", "ITGAV", "ITGB3", "VCL", "TLN1", "PXN", "PTK2", "FERMT2"],
    "gap_junction_coordination": ["GJA1", "GJB1", "GJB2", "GJC1", "PANX1"],
    "bioelectric_ion_homeostasis": ["ATP1A1", "ATP1B1", "KCNH2", "KCNJ2", "KCNQ1", "SCN5A", "CACNA1C", "CLCN3", "SLC9A1", "VDAC1"],
    "redox_mitochondrial_state": ["NFE2L2", "KEAP1", "SOD1", "SOD2", "GPX4", "GCLC", "GCLM", "TXN", "TXNRD1", "PRDX1", "VDAC1", "BAX", "BAK1"],
    "differentiation_retinoid": ["RARA", "RARB", "RARG", "RXRA", "RXRB", "RXRG", "CEBPA", "GATA3", "PPARG", "KLF4"],
    "senescence_checkpoint": ["CDKN1A", "CDKN2A", "RB1", "TP53", "MDM2", "ATM", "ATR", "CHEK1", "CHEK2"],
}


def gene_symbol(x):
    return x.split(" (", 1)[0]


def bh_fdr(pvals):
    p = np.asarray(pvals, dtype=float)
    q = np.full(p.shape, np.nan)
    mask = np.isfinite(p)
    vals = p[mask]
    order = np.argsort(vals)
    ranked = vals[order]
    n = len(ranked)
    adj = np.empty(n)
    prev = 1.0
    for i in range(n - 1, -1, -1):
        val = min(prev, ranked[i] * n / (i + 1))
        adj[i] = val
        prev = val
    restored = np.empty(n)
    restored[order] = adj
    q[mask] = restored
    return q


def load_model_meta():
    meta = {}
    with open(ROOT / "Model.csv", newline="") as f:
        for row in csv.DictReader(f):
            disease = row.get("OncotreePrimaryDisease") or ""
            lineage = row.get("OncotreeLineage") or "Unknown"
            is_noncancer = disease == "Non-Cancerous" or lineage == "Normal"
            meta[row["ModelID"]] = {"lineage": lineage, "is_cancer": not is_noncancer}
    return meta


def residualize_matrix(mat, groups):
    groups = np.asarray(groups)
    out = np.full(mat.shape, np.nan)
    for g in sorted(set(groups)):
        idx = np.where(groups == g)[0]
        if len(idx) < MIN_LINEAGE_N:
            continue
        block = mat[idx]
        mu = np.nanmean(block, axis=0)
        sd = np.nanstd(block, axis=0)
        ok = np.isfinite(sd) & (sd > 0)
        out[np.ix_(idx, ok)] = (block[:, ok] - mu[ok]) / sd[ok]
    return out


def safe_spearman(x, y):
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 100:
        return math.nan, math.nan, int(mask.sum())
    r, p = stats.spearmanr(x[mask], y[mask])
    return float(r), float(p), int(mask.sum())


def module_mean(mat, idxs):
    return np.nanmean(mat[:, idxs], axis=1)


def main():
    meta_map = load_model_meta()
    wanted = sorted({g for genes in GOVERNANCE_MODULES.values() for g in genes})
    with open(ROOT / "CRISPRGeneEffect.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        genes = [gene_symbol(h) for h in header[1:]]
        gene_to_idx = {g: i for i, g in enumerate(genes)}
        available = sorted(set(wanted) & set(gene_to_idx))
        needed_idx = [gene_to_idx[g] for g in available]
        mids, lineages, is_cancer, rows = [], [], [], []
        for row in reader:
            mid = row[0]
            if mid not in meta_map:
                continue
            vals = np.array([float(row[i + 1]) if row[i + 1] else np.nan for i in needed_idx], dtype=float)
            mids.append(mid)
            lineages.append(meta_map[mid]["lineage"])
            is_cancer.append(meta_map[mid]["is_cancer"])
            rows.append(vals)
    dependency = -np.vstack(rows)
    lineages = np.array(lineages)
    is_cancer = np.array(is_cancer, dtype=bool)
    local_idx = {g: i for i, g in enumerate(available)}

    cancer_dep_z = residualize_matrix(dependency[is_cancer], lineages[is_cancer])
    cancer_lineages = lineages[is_cancer]
    raw_cancer = dependency[is_cancer]
    raw_nonc = dependency[~is_cancer]

    module_rows = []
    module_scores = {}
    for name, genes0 in GOVERNANCE_MODULES.items():
        found = [g for g in genes0 if g in local_idx]
        idxs = [local_idx[g] for g in found]
        if not idxs:
            continue
        score = module_mean(cancer_dep_z, idxs)
        module_scores[name] = score
        lineage_means = []
        pos = 0
        tested = 0
        for lin in sorted(set(cancer_lineages)):
            mask = cancer_lineages == lin
            if mask.sum() < MIN_LINEAGE_N:
                continue
            m = float(np.nanmean(score[mask]))
            tested += 1
            pos += int(m > 0)
            lineage_means.append({"lineage": lin, "mean_z": m, "n": int(mask.sum())})
        cancer_raw = module_mean(raw_cancer, idxs)
        nonc_raw = module_mean(raw_nonc, idxs)
        t, p = stats.ttest_ind(cancer_raw[np.isfinite(cancer_raw)], nonc_raw[np.isfinite(nonc_raw)], equal_var=False)
        module_rows.append({
            "module": name,
            "genes_found": found,
            "mean_dependency_cancer": float(np.nanmean(cancer_raw)),
            "mean_dependency_noncancer": float(np.nanmean(nonc_raw)),
            "cancer_minus_noncancer_dependency": float(np.nanmean(cancer_raw) - np.nanmean(nonc_raw)),
            "welch_p_cancer_vs_noncancer": float(p),
            "lineages_positive_after_residualization": int(pos),
            "lineages_tested": int(tested),
            "fraction_lineages_positive": float(pos / tested) if tested else math.nan,
            "top_lineages": sorted(lineage_means, key=lambda r: r["mean_z"], reverse=True)[:8],
            "bottom_lineages": sorted(lineage_means, key=lambda r: r["mean_z"])[:8],
        })
    qs = bh_fdr([r["welch_p_cancer_vs_noncancer"] for r in module_rows])
    for r, q in zip(module_rows, qs):
        r["bh_fdr_cancer_vs_noncancer"] = float(q)
    module_rows.sort(key=lambda r: r["cancer_minus_noncancer_dependency"], reverse=True)

    corr = []
    names = list(module_scores)
    for i, a in enumerate(names):
        for j in range(i + 1, len(names)):
            b = names[j]
            r, p, n = safe_spearman(module_scores[a], module_scores[b])
            corr.append({"a": a, "b": b, "spearman_r": r, "p": p, "n": n})
    corr.sort(key=lambda r: abs(r["spearman_r"]), reverse=True)

    gene_rows = []
    for g in available:
        i = local_idx[g]
        cancer = raw_cancer[:, i]
        nonc = raw_nonc[:, i]
        if np.isfinite(nonc).sum() < MIN_NONCANCER_N:
            continue
        t, p = stats.ttest_ind(cancer[np.isfinite(cancer)], nonc[np.isfinite(nonc)], equal_var=False)
        pos = 0
        tested = 0
        z = cancer_dep_z[:, i]
        for lin in sorted(set(cancer_lineages)):
            mask = cancer_lineages == lin
            if mask.sum() < MIN_LINEAGE_N:
                continue
            tested += 1
            pos += int(np.nanmean(z[mask]) > 0)
        gene_rows.append({
            "gene": g,
            "mean_dependency_cancer": float(np.nanmean(cancer)),
            "mean_dependency_noncancer": float(np.nanmean(nonc)),
            "cancer_minus_noncancer_dependency": float(np.nanmean(cancer) - np.nanmean(nonc)),
            "welch_p": float(p),
            "fraction_lineages_positive_z": float(pos / tested) if tested else math.nan,
        })
    gq = bh_fdr([r["welch_p"] for r in gene_rows])
    for r, q in zip(gene_rows, gq):
        r["bh_fdr"] = float(q)
    gene_rows.sort(key=lambda r: (-r["cancer_minus_noncancer_dependency"], r["bh_fdr"]))

    out = {
        "question": "Did we miss an organism-level governance/stability layer that is broadly dependency-relevant in cancer?",
        "data_source": "DepMap 24Q4 CRISPRGeneEffect and Model.csv.",
        "interpretation_warning": "CRISPR dependency in cell lines cannot capture full organism-level regulation, immune context, ECM architecture, or normal-tissue safety. This is only a first data screen.",
        "n_models": int(len(mids)),
        "n_cancer_models": int(is_cancer.sum()),
        "n_noncancer_models": int((~is_cancer).sum()),
        "module_results": module_rows,
        "top_module_correlations_after_lineage_residualization": corr[:40],
        "top_governance_genes_by_cancer_vs_noncancer_dependency": gene_rows[:80],
    }
    (ROOT / "organism_stability_governance_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
