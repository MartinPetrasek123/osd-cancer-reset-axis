#!/usr/bin/env python3
import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent
MIN_LINEAGE_N = 12
TARGET_GENES = {"AMD1", "ODC1", "SRM", "SMS", "SAT1", "SMOX", "OAZ1", "OAZ2", "PAOX"}
POLYAMINE_TERMS = ["polyamine", "spermid", "spermine", "ornithine", "eflornithine", "dfmo", "besm", "amd1"]


def gene_symbol(header_name):
    return header_name.split(" (", 1)[0]


def load_models():
    out = {}
    with open(ROOT / "Model.csv", newline="") as f:
        for row in csv.DictReader(f):
            disease = row.get("OncotreePrimaryDisease") or ""
            lineage = row.get("OncotreeLineage") or "Unknown"
            is_noncancer = disease == "Non-Cancerous" or lineage == "Normal"
            out[row["ModelID"]] = {"lineage": lineage, "is_cancer": not is_noncancer, "disease": disease}
    return out


def load_gene_list(path):
    genes = set()
    with open(path, newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            for cell in row:
                cell = cell.strip()
                if cell and cell.lower() not in {"gene", "genes"}:
                    genes.add(gene_symbol(cell))
    return genes


def load_expression(models, genes):
    model_set = set(models)
    result = {}
    with open(ROOT / "OmicsExpressionProteinCodingGenesTPMLogp1.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        idx = {i: gene_symbol(h) for i, h in enumerate(header[1:], 1) if gene_symbol(h) in genes}
        for row in reader:
            if row[0] not in model_set:
                continue
            result[row[0]] = {}
            for i, g in idx.items():
                try:
                    result[row[0]][g] = float(row[i])
                except Exception:
                    result[row[0]][g] = math.nan
    return result


def main():
    models = load_models()
    common_essential = load_gene_list(ROOT / "CRISPRInferredCommonEssentials.csv")
    nonessential = load_gene_list(ROOT / "AchillesNonessentialControls.csv")

    with open(ROOT / "CRISPRGeneEffect.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        genes = [gene_symbol(h) for h in header[1:]]
        gene_to_idx = {g: i for i, g in enumerate(genes)}
        mids = []
        effects = []
        meta = []
        for row in reader:
            mid = row[0]
            if mid not in models:
                continue
            vals = np.array([float(x) if x else np.nan for x in row[1:]], dtype=float)
            mids.append(mid)
            effects.append(vals)
            meta.append(models[mid])
    effects = np.vstack(effects)
    deps = -effects
    is_cancer = np.array([m["is_cancer"] for m in meta])
    lineages = np.array([m["lineage"] for m in meta])

    cancer_mean = np.nanmean(deps[is_cancer], axis=0)
    cancer_median = np.nanmedian(deps[is_cancer], axis=0)
    cancer_frac_strong = np.nanmean(deps[is_cancer] >= 0.5, axis=0)
    nonc_mean = np.nanmean(deps[~is_cancer], axis=0) if np.sum(~is_cancer) else np.full(len(genes), np.nan)

    all_rows = []
    for g, i in gene_to_idx.items():
        lin_pos = 0
        lin_tested = 0
        lin_mean = []
        for lin in sorted(set(lineages[is_cancer])):
            idx = is_cancer & (lineages == lin)
            if np.sum(idx) < MIN_LINEAGE_N:
                continue
            v = deps[idx, i]
            if np.isfinite(v).sum() < MIN_LINEAGE_N:
                continue
            lin_tested += 1
            m = float(np.nanmean(v))
            lin_mean.append(m)
            if m > 0:
                lin_pos += 1
        all_rows.append({
            "gene": g,
            "idx": i,
            "cancer_mean_dependency": float(cancer_mean[i]),
            "cancer_median_dependency": float(cancer_median[i]),
            "cancer_fraction_dependency_ge_0.5": float(cancer_frac_strong[i]),
            "noncancer_mean_dependency": float(nonc_mean[i]),
            "cancer_minus_noncancer": float(cancer_mean[i] - nonc_mean[i]),
            "lineages_positive_mean_dependency": lin_pos,
            "lineages_tested": lin_tested,
            "fraction_lineages_positive": float(lin_pos / lin_tested) if lin_tested else math.nan,
            "is_common_essential": g in common_essential,
            "is_nonessential_control": g in nonessential,
        })

    by_mean = sorted(all_rows, key=lambda r: r["cancer_mean_dependency"], reverse=True)
    by_frac = sorted(all_rows, key=lambda r: r["cancer_fraction_dependency_ge_0.5"], reverse=True)
    by_selective = sorted(all_rows, key=lambda r: r["cancer_minus_noncancer"], reverse=True)
    rank_mean = {r["gene"]: k + 1 for k, r in enumerate(by_mean)}
    rank_frac = {r["gene"]: k + 1 for k, r in enumerate(by_frac)}
    rank_selective = {r["gene"]: k + 1 for k, r in enumerate(by_selective)}

    target_rows = []
    for g in sorted(TARGET_GENES):
        if g in gene_to_idx:
            row = next(r for r in all_rows if r["gene"] == g)
            row = dict(row)
            row["rank_by_cancer_mean_dependency"] = rank_mean[g]
            row["rank_by_cancer_fraction_dependency_ge_0.5"] = rank_frac[g]
            row["rank_by_cancer_minus_noncancer"] = rank_selective[g]
            target_rows.append(row)

    expr = load_expression(mids, TARGET_GENES)
    expr_dep_rows = []
    for g in sorted(TARGET_GENES & set(gene_to_idx)):
        x = np.array([expr.get(m, {}).get(g, math.nan) for m in mids], dtype=float)
        y = deps[:, gene_to_idx[g]]
        mask = is_cancer & np.isfinite(x) & np.isfinite(y)
        r, p = stats.spearmanr(x[mask], y[mask]) if mask.sum() >= 50 else (math.nan, math.nan)
        expr_dep_rows.append({"gene": g, "n": int(mask.sum()), "expression_dependency_spearman_r": float(r), "p": float(p)})

    prism_treatments = {}
    with open(ROOT / "prism_primary_treatment_info.csv", newline="") as f:
        for row in csv.DictReader(f):
            text = " ".join(str(v).lower() for v in row.values())
            if any(t in text for t in POLYAMINE_TERMS):
                prism_treatments[row["column_name"]] = row

    prism_rows = []
    if prism_treatments:
        with open(ROOT / "prism_primary_collapsed_lfc.csv", newline="") as f:
            reader = csv.reader(f)
            header = next(reader)
            col_to_idx = {c: i for i, c in enumerate(header)}
            for col, info in prism_treatments.items():
                if col not in col_to_idx:
                    continue
                vals = []
                for row in reader:
                    try:
                        vals.append(float(row[col_to_idx[col]]))
                    except Exception:
                        pass
                vals = np.array(vals, dtype=float)
                vals = vals[np.isfinite(vals)]
                prism_rows.append({
                    "name": info.get("name"),
                    "moa": info.get("moa"),
                    "target": info.get("target"),
                    "phase": info.get("phase"),
                    "dose": info.get("dose"),
                    "n": int(len(vals)),
                    "mean_log2_fold_change": float(np.mean(vals)) if len(vals) else math.nan,
                    "median_log2_fold_change": float(np.median(vals)) if len(vals) else math.nan,
                    "fraction_lfc_le_-0.5": float(np.mean(vals <= -0.5)) if len(vals) else math.nan,
                    "fraction_lfc_le_-1.0": float(np.mean(vals <= -1.0)) if len(vals) else math.nan,
                })
                f.seek(0)
                next(reader)

    common_vals = np.array([r["cancer_mean_dependency"] for r in all_rows if r["is_common_essential"]], dtype=float)
    nonessential_vals = np.array([r["cancer_mean_dependency"] for r in all_rows if r["is_nonessential_control"]], dtype=float)

    out = {
        "question": "Is AMD1/polyamine metabolism a stronger universal cancer key after broadness, common-essential, expression, and PRISM polyamine checks?",
        "data_sources": [
            "DepMap 24Q4 CRISPRGeneEffect, Model, expression, common-essential and nonessential controls.",
            "PRISM Repurposing 19Q4 primary screen treatment info and log-fold-change.",
        ],
        "limitations": [
            "Only 14 non-cancerous DepMap CRISPR models are available, so cancer-vs-noncancer selectivity remains weakly powered.",
            "PRISM polyamine compounds are mostly pathway-adjacent; this is not direct AMD1 inhibitor pharmacology across normal tissues.",
        ],
        "n_models": int(len(mids)),
        "n_cancer_models": int(np.sum(is_cancer)),
        "n_noncancer_models": int(np.sum(~is_cancer)),
        "n_genes": int(len(genes)),
        "common_essential_summary": {
            "n": int(len(common_vals)),
            "mean_cancer_dependency": float(np.nanmean(common_vals)),
            "median_cancer_dependency": float(np.nanmedian(common_vals)),
        },
        "nonessential_control_summary": {
            "n": int(len(nonessential_vals)),
            "mean_cancer_dependency": float(np.nanmean(nonessential_vals)),
            "median_cancer_dependency": float(np.nanmedian(nonessential_vals)),
        },
        "polyamine_gene_dependency_rows": target_rows,
        "polyamine_expression_dependency_rows": expr_dep_rows,
        "prism_polyamine_related_treatments": prism_rows,
        "top_20_cancer_mean_dependencies": [
            {k: r[k] for k in ["gene", "cancer_mean_dependency", "cancer_fraction_dependency_ge_0.5", "fraction_lineages_positive", "is_common_essential"]}
            for r in by_mean[:20]
        ],
    }
    (ROOT / "amd1_polyamine_key_validation_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
