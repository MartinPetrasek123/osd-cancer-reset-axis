#!/usr/bin/env python3
import csv
import gzip
import json
import math
import re
from pathlib import Path

import numpy as np
import pandas as pd
import rdata
import statsmodels.api as sm
from lifelines import CoxPHFitter
from rdata.parser import RObjectType
from scipy import stats
from sklearn.metrics import roc_auc_score


ROOT = Path(__file__).resolve().parents[3]
WORK = ROOT / "work" / "onco_psi"
OUT = ROOT / "outputs" / "osd-github-upload-20260911-1209"
RESULTS = OUT / "results"
REPORTS = OUT / "reports"


MODULES = {
    "proliferation": ["MKI67", "TOP2A", "PCNA", "MCM2", "MCM4", "MCM6", "CCNB1", "CDK1"],
    "inflammatory_alarm": ["IL6", "IL1B", "TNF", "NFKB1", "NFKB2", "RELA", "STAT3", "PTGS2", "CXCL8", "CCL2", "CXCL1", "CXCL2"],
    "interferon_alarm": ["IFNG", "IRF7", "STAT1", "ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "CXCL10", "GBP1"],
    "wound_ecm_fibrosis": ["TGFB1", "TGFBR1", "SMAD2", "SMAD3", "COL1A1", "COL1A2", "COL3A1", "FN1", "VIM", "ACTA2", "MMP2", "MMP9", "TIMP1"],
    "coagulation_complement": ["C3", "C5", "CFB", "CFH", "F2", "F3", "FGA", "FGB", "FGG", "SERPINE1", "PLAU", "PLAT"],
    "hypoxia_redox_stress": ["HIF1A", "VEGFA", "SLC2A1", "CA9", "LDHA", "NFE2L2", "HMOX1", "NQO1", "SOD2", "TXN", "PRDX1"],
    "proteostasis_er_stress": ["HSPA5", "XBP1", "ATF4", "DDIT3", "HSP90AA1", "PSMA1", "PSMB5", "PSMC1", "PSMD1"],
    "bioelectric_junction_order": ["GJA1", "GJB1", "GJB2", "PANX1", "ATP1A1", "ATP1B1", "KCNJ2", "KCNQ1", "CLCN3", "SLC9A1", "VDAC1"],
    "polarity_adhesion_order": ["PARD3", "PARD6A", "PRKCI", "SCRIB", "DLG1", "LLGL1", "CDH1", "ITGA5", "ITGB1", "VCL", "TLN1", "PXN"],
    "circadian_order": ["CLOCK", "ARNTL", "PER1", "PER2", "PER3", "CRY1", "CRY2", "NR1D1", "NR1D2", "RORA", "DBP"],
    "mitochondrial_homeostasis": ["PPARGC1A", "PPARGC1B", "NDUFS1", "NDUFV1", "SDHA", "UQCRC1", "COX4I1", "ATP5F1A", "TFAM", "SIRT3"],
    "differentiation_order": ["NOTCH1", "NOTCH2", "RBPJ", "CTNNB1", "APC", "YAP1", "WWTR1", "TEAD1", "TEAD4", "LATS1", "LATS2"],
}

COMPARATORS = {
    "emt": ["VIM", "CDH2", "SNAI1", "SNAI2", "TWIST1", "TWIST2", "ZEB1", "ZEB2", "FN1", "MMP2", "MMP9", "ITGA5"],
    "hypoxia_only": ["HIF1A", "VEGFA", "SLC2A1", "CA9", "LDHA", "PDK1", "ALDOA", "ENO1", "PGK1", "BNIP3", "NDRG1"],
    "tgfb_caf_stroma": ["TGFB1", "TGFBR1", "TGFBR2", "SMAD2", "SMAD3", "ACTA2", "FAP", "PDGFRB", "COL1A1", "COL1A2", "COL3A1", "FN1", "THY1", "TAGLN"],
    "immune_infiltration": ["CD3D", "CD3E", "CD8A", "GZMB", "PRF1", "IFNG", "CXCL9", "CXCL10", "STAT1", "LST1", "CSF1R", "CD68", "MS4A1"],
}


def zscore(v):
    v = np.asarray(v, dtype=float)
    sd = np.nanstd(v)
    if not np.isfinite(sd) or sd == 0:
        return np.zeros_like(v, dtype=float)
    return (v - np.nanmean(v)) / sd


def residualize(y, covariates):
    y = np.asarray(y, dtype=float)
    X = np.column_stack([zscore(c) for c in covariates])
    mask = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    out = np.full(len(y), np.nan)
    if mask.sum() <= X.shape[1] + 5:
        return out
    Xm = sm.add_constant(X[mask])
    fit = sm.OLS(y[mask], Xm).fit()
    out[mask] = fit.resid
    return out


def bh(pvals):
    items = [(k, p) for k, p in pvals.items() if np.isfinite(p)]
    items.sort(key=lambda x: x[1])
    m = len(items)
    q = {}
    prev = 1.0
    for i in range(m, 0, -1):
        k, p = items[i - 1]
        val = min(prev, p * m / i)
        q[k] = val
        prev = val
    return q


def module_score(gene_vectors, genes):
    present = [g for g in genes if g in gene_vectors]
    if not present:
        return np.full(len(next(iter(gene_vectors.values()))), np.nan), []
    return np.nanmean(np.vstack([zscore(gene_vectors[g]) for g in present]), axis=0), present


def compute_scores(gene_vectors):
    scores, found = {}, {}
    for name, genes in {**MODULES, **COMPARATORS}.items():
        scores[name], found[name] = module_score(gene_vectors, genes)
    instability = sum(zscore(scores[k]) for k in [
        "inflammatory_alarm", "interferon_alarm", "wound_ecm_fibrosis",
        "coagulation_complement", "hypoxia_redox_stress", "proteostasis_er_stress"
    ])
    order = sum(zscore(scores[k]) for k in [
        "bioelectric_junction_order", "polarity_adhesion_order", "circadian_order",
        "mitochondrial_homeostasis", "differentiation_order"
    ])
    scores["instability_load"] = instability
    scores["order_capacity"] = order
    scores["osd_raw"] = instability - order
    scores["osd_residual"] = residualize(scores["osd_raw"], [scores["proliferation"]])
    scores["repair_stress_composite"] = np.nanmean(np.vstack([
        zscore(scores["wound_ecm_fibrosis"]),
        zscore(scores["hypoxia_redox_stress"]),
        zscore(scores["proteostasis_er_stress"]),
    ]), axis=0)
    return scores, found


def cox_fit(df, covariates, strata=None):
    cols = ["time", "event"] + covariates + ([strata] if strata else [])
    sub = df[cols].dropna().copy()
    for c in covariates:
        sub[c] = zscore(sub[c].to_numpy())
    if len(sub) < 50 or sub["event"].sum() < 10:
        return None
    cph = CoxPHFitter()
    cph.fit(sub, duration_col="time", event_col="event", strata=[strata] if strata else None)
    ll = float(cph.log_likelihood_)
    k = len(covariates)
    out = {
        "n": int(len(sub)),
        "events": int(sub["event"].sum()),
        "log_likelihood": ll,
        "aic_partial": float(-2 * ll + 2 * k),
        "concordance_index": float(cph.concordance_index_),
        "covariates": {},
    }
    for c in covariates:
        row = cph.summary.loc[c]
        out["covariates"][c] = {
            "hr_per_sd": float(row["exp(coef)"]),
            "coef": float(row["coef"]),
            "p": float(row["p"]),
            "ci95_low": float(row["exp(coef) lower 95%"]),
            "ci95_high": float(row["exp(coef) upper 95%"]),
        }
    return out


def lrt(full, reduced, df=1):
    stat = 2 * (full["log_likelihood"] - reduced["log_likelihood"])
    return {"lr_stat": float(stat), "df": int(df), "p": float(stats.chi2.sf(stat, df))}


def logistic_fit(df, covariates):
    cols = ["y"] + covariates
    sub = df[cols].dropna().copy()
    if len(sub) < 40 or sub["y"].nunique() < 2:
        return None
    for c in covariates:
        sub[c] = zscore(sub[c].to_numpy())
    X = sm.add_constant(sub[covariates])
    fit = sm.Logit(sub["y"], X).fit(disp=False, maxiter=200)
    pred = fit.predict(X)
    out = {
        "n": int(len(sub)),
        "events_nonresponse": int(sub["y"].sum()),
        "aic": float(fit.aic),
        "log_likelihood": float(fit.llf),
        "auc": float(roc_auc_score(sub["y"], pred)),
        "covariates": {},
    }
    for c in covariates:
        out["covariates"][c] = {
            "odds_ratio_per_sd": float(math.exp(fit.params[c])),
            "coef": float(fit.params[c]),
            "p": float(fit.pvalues[c]),
        }
    return out


def auc_univariable(df, score_col):
    sub = df[["y", score_col]].dropna()
    if len(sub) < 10 or sub["y"].nunique() < 2:
        return None
    return float(roc_auc_score(sub["y"], zscore(sub[score_col].to_numpy())))


def bootstrap_auc_ci(df, score_col, n_boot=2000, seed=20260911):
    sub = df[["y", score_col]].dropna().reset_index(drop=True)
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n_boot):
        ix = rng.integers(0, len(sub), len(sub))
        b = sub.iloc[ix]
        if b["y"].nunique() == 2:
            vals.append(roc_auc_score(b["y"], b[score_col]))
    return {
        "n_boot": len(vals),
        "ci95_low": float(np.percentile(vals, 2.5)),
        "ci95_high": float(np.percentile(vals, 97.5)),
    }


def random_signature_auc(df, gene_vectors, labels, size, n=1000, seed=20260911):
    genes = sorted(gene_vectors)
    rng = np.random.default_rng(seed)
    aucs = []
    for _ in range(n):
        pick = list(rng.choice(genes, size=min(size, len(genes)), replace=False))
        if isinstance(next(iter(gene_vectors.values())), pd.Series):
            mat = pd.concat([gene_vectors[g] for g in pick], axis=1)
            vec = mat.apply(lambda row: np.nanmean(row.to_numpy(dtype=float)), axis=1)
            vec = zscore(vec.reindex(df.index).to_numpy(dtype=float))
        else:
            vec, _ = module_score(gene_vectors, pick)
            if len(vec) != len(df):
                continue
        tmp = pd.DataFrame({"y": labels, "rand": vec})
        val = auc_univariable(tmp, "rand")
        if val is not None:
            aucs.append(val)
    return np.asarray(aucs, dtype=float)


def random_signature_survival_null(df, gene_vectors, size, n=300, seed=20260911, strata=None, target_col="osd_residual"):
    genes = sorted(gene_vectors)
    rng = np.random.default_rng(seed)
    target = cox_fit(df, [target_col], strata=strata)
    vals = []
    for _ in range(n):
        pick = list(rng.choice(genes, size=min(size, len(genes)), replace=False))
        if isinstance(next(iter(gene_vectors.values())), pd.Series):
            mat = pd.concat([gene_vectors[g] for g in pick], axis=1)
            vec = mat.apply(lambda row: np.nanmean(row.to_numpy(dtype=float)), axis=1)
            vec = zscore(vec.reindex(df.index).to_numpy(dtype=float))
        else:
            vec, _ = module_score(gene_vectors, pick)
            if len(vec) != len(df):
                continue
        tmp = df.copy()
        tmp["random_signature"] = vec
        fit = cox_fit(tmp, ["random_signature"], strata=strata)
        if fit:
            vals.append({
                "p": fit["covariates"]["random_signature"]["p"],
                "c_index": fit["concordance_index"],
                "hr": fit["covariates"]["random_signature"]["hr_per_sd"],
            })
    if not vals or not target:
        return None
    pvals = np.array([v["p"] for v in vals], dtype=float)
    cidx = np.array([v["c_index"] for v in vals], dtype=float)
    target_p = target["covariates"][target_col]["p"]
    target_c = target["concordance_index"]
    return {
        "n": int(len(vals)),
        "signature_size": int(size),
        "target": target_col,
        "target_univariable_p": float(target_p),
        "target_univariable_c_index": float(target_c),
        "median_random_p": float(np.median(pvals)),
        "random_c_index_ci95_low": float(np.percentile(cidx, 2.5)),
        "random_c_index_ci95_high": float(np.percentile(cidx, 97.5)),
        "fraction_random_p_le_target": float(np.mean(pvals <= target_p)),
        "fraction_random_c_index_ge_target": float(np.mean(cidx >= target_c)),
    }


def tcga_data():
    base = WORK / "xena_cir"
    gene_map = {}
    with open(base / "gencode.v23.annotation.gene.probemap") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            gene_map.setdefault(row["id"], row["gene"])
    expr_files = [base / "selected_organism_reset_gene_expression.tsv.gz", base / "selected_module_gene_expression.tsv.gz"]
    sample_names = None
    raw = {}
    wanted = set(sum(MODULES.values(), []) + sum(COMPARATORS.values(), []))
    for expr_path in expr_files:
        with gzip.open(expr_path, "rt") as f:
            header = f.readline().rstrip("\n").split("\t")
            samples = header[1:]
            if sample_names is None:
                sample_names = samples
            for line in f:
                parts = line.rstrip("\n").split("\t")
                gene = gene_map.get(parts[0])
                if gene in wanted and gene not in raw:
                    raw[gene] = np.array([float(x) for x in parts[1:]], dtype=float)

    surv = {}
    for path in WORK.glob("*_tcga_pan_can_atlas_2018.patient_clinical.json"):
        records = json.loads(path.read_text())
        tmp = {}
        for r in records:
            if r.get("clinicalAttributeId") in {"OS_MONTHS", "OS_STATUS"}:
                tmp.setdefault(r.get("patientId"), {})[r.get("clinicalAttributeId")] = r.get("value")
        for patient, vals in tmp.items():
            try:
                time = float(vals.get("OS_MONTHS"))
            except Exception:
                continue
            status = str(vals.get("OS_STATUS", "")).upper()
            event = 1 if status.startswith("1:") or "DEAD" in status or "DECEASED" in status else 0
            if np.isfinite(time) and time > 0:
                surv[patient] = {"time": time, "event": event, "study": path.name.replace(".patient_clinical.json", "")}

    keep = []
    for i, sample in enumerate(sample_names):
        if not sample.startswith("TCGA-") or sample[13:15] != "01":
            continue
        patient = "-".join(sample.split("-")[:3])
        if patient in surv:
            keep.append((i, patient))
    idx = [i for i, _ in keep]
    gene_vectors = {g: pd.Series(v[idx], index=range(len(keep))) for g, v in raw.items()}
    scores, found = compute_scores(gene_vectors)
    df = pd.DataFrame({k: v for k, v in scores.items()})
    df["time"] = [surv[p]["time"] for _, p in keep]
    df["event"] = [surv[p]["event"] for _, p in keep]
    df["study"] = [surv[p]["study"] for _, p in keep]
    return df, gene_vectors, found


def imvigor_data():
    pkg = WORK / "IMvigor210CoreBiologies"
    parsed = rdata.parser.parse_file(pkg / "data" / "cds.RData")
    cds = parsed.object.value[0]

    def deref(o):
        while o is not None and o.info.type == RObjectType.REF and o.referenced_object is not None:
            o = o.referenced_object
        return o

    def r_char(o):
        o = deref(o)
        if o is None:
            return None
        if o.info.type == RObjectType.SYM:
            return r_char(o.value)
        if o.info.type == RObjectType.CHAR:
            return None if o.value is None else (o.value.decode() if isinstance(o.value, bytes) else o.value)
        if o.info.type == RObjectType.STR:
            return [r_char(x) for x in o.value]
        return None

    def list_items(o, limit=100000):
        items, cur, n = [], deref(o), 0
        while cur is not None and cur.info.type != RObjectType.NILVALUE and n < limit:
            cur = deref(cur)
            if cur.info.type not in (RObjectType.LIST, RObjectType.LANG):
                break
            items.append((r_char(cur.tag), deref(cur.value[0])))
            cur = cur.value[1]
            n += 1
        return items

    def attrs(o):
        o = deref(o)
        return dict(list_items(o.attributes)) if o.attributes is not None else {}

    def convert_column(o):
        o = deref(o)
        a = attrs(o)
        levels = r_char(a.get("levels")) if a.get("levels") is not None else None
        if o.info.type in (RObjectType.INT, RObjectType.REAL, RObjectType.LGL):
            vals = np.asarray(o.value)
            if levels:
                out = []
                for v in vals:
                    if np.ma.is_masked(v) or pd.isna(v) or int(v) <= 0:
                        out.append(np.nan)
                    else:
                        out.append(levels[int(v) - 1])
                return out
            return [np.nan if np.ma.is_masked(v) else float(v) for v in vals]
        if o.info.type == RObjectType.STR:
            return r_char(o)
        return list(o.value)

    slots = dict(list_items(cds.attributes))
    pheno_obj = attrs(slots["phenoData"])["data"]
    pheno_attrs = attrs(pheno_obj)
    pheno = pd.DataFrame({name: convert_column(col) for name, col in zip(r_char(pheno_attrs["names"]), pheno_obj.value)}, index=r_char(pheno_attrs["row.names"]))
    feature_obj = attrs(slots["featureData"])["data"]
    feature_attrs = attrs(feature_obj)
    features = pd.DataFrame({name: convert_column(col) for name, col in zip(r_char(feature_attrs["names"]), feature_obj.value)}, index=r_char(feature_attrs["row.names"]))
    counts = None
    for bucket in slots["assayData"].value.hash_table.value:
        for key, value in list_items(bucket):
            if key == "counts":
                ca = attrs(value)
                dim = tuple(ca["dim"].value)
                dimnames = ca["dimnames"].value
                counts = pd.DataFrame(np.asarray(value.value, dtype=float).reshape(dim, order="F"), index=r_char(dimnames[0]), columns=r_char(dimnames[1]))
                break
    sample_ids = list(pheno.index)
    size_factor = pheno["sizeFactor"].astype(float).reindex(sample_ids).to_numpy()
    counts = counts.reindex(columns=sample_ids)
    symbol_by_entrez = features["Symbol"].fillna(features["symbol"]).astype(str).to_dict()
    wanted = set(sum(MODULES.values(), []) + sum(COMPARATORS.values(), []))
    gene_to_rows = {g: [] for g in wanted}
    for entrez, symbol in symbol_by_entrez.items():
        if symbol in gene_to_rows and entrez in counts.index:
            gene_to_rows[symbol].append(entrez)
    norm = np.log2(counts.to_numpy(dtype=float) / size_factor.reshape(1, -1) + 1.0)
    row_index = {gene_id: i for i, gene_id in enumerate(counts.index)}
    gene_vectors = {}
    for gene, row_ids in gene_to_rows.items():
        rows = [row_index[r] for r in row_ids if r in row_index]
        if rows:
            gene_vectors[gene] = pd.Series(np.nanmean(norm[rows, :], axis=0), index=sample_ids)
    scores, found = compute_scores(gene_vectors)
    df = pheno.copy()
    for k, v in scores.items():
        df[k] = v
    df["time"] = pd.to_numeric(df["os"], errors="coerce")
    df["event"] = pd.to_numeric(df["censOS"], errors="coerce")
    df["y"] = df["binaryResponse"].map({"SD/PD": 1, "CR/PR": 0})
    return df, gene_vectors, found


def gse78220_data():
    base = WORK / "validation_gse78220"
    meta_rows = {}
    with gzip.open(base / "GSE78220_series_matrix.txt.gz", "rt", errors="replace") as f:
        titles = None
        for line in f:
            if line.startswith("!Sample_title"):
                titles = [p.strip().strip('"') for p in line.rstrip("\n").split("\t")[1:]]
                meta_rows = {t: {"title": t} for t in titles}
            elif titles and line.startswith("!Sample_source_name_ch1"):
                vals = [p.strip().strip('"') for p in line.rstrip("\n").split("\t")[1:]]
                for title, val in zip(titles, vals):
                    if "_" in val:
                        meta_rows[title]["response"] = val.rsplit("_", 1)[1]
            elif titles and line.startswith("!Sample_characteristics_ch1"):
                vals = [p.strip().strip('"') for p in line.rstrip("\n").split("\t")[1:]]
                for title, val in zip(titles, vals):
                    if ": " in val:
                        key, raw = val.split(": ", 1)
                        meta_rows[title][key.lower().replace(" ", "_").replace("-", "_")] = raw
    fpkm = pd.read_excel(base / "GSE78220_PatientFPKM.xlsx", sheet_name="FPKM")
    fpkm = fpkm.groupby("Gene", as_index=True).mean(numeric_only=True)
    baseline_cols = [c for c in fpkm.columns if c.endswith(".baseline")]
    expr = np.log2(fpkm[baseline_cols] + 1.0)
    sample_patients = [re.sub(r"[A-Z]$", "", col.split(".", 1)[0]) for col in baseline_cols]
    gene_vectors = {}
    for gene in expr.index:
        vals = pd.Series(expr.loc[gene].to_numpy(dtype=float), index=sample_patients)
        gene_vectors[gene] = vals.groupby(level=0).mean()
    scores, found = compute_scores(gene_vectors)
    patient_response = {}
    for col in baseline_cols:
        sample = col.split(".", 1)[0]
        patient = re.sub(r"[A-Z]$", "", sample)
        m = meta_rows.get(sample, {})
        resp = m.get("anti_pd_1_response") or m.get("response")
        if resp in {"Complete Response", "Partial Response"}:
            y = 0
        elif resp == "Progressive Disease":
            y = 1
        else:
            continue
        patient_response[patient] = y
    patients = list(next(iter(gene_vectors.values())).index)
    df = pd.DataFrame(index=patients)
    df["y"] = pd.Series(patient_response)
    for k, v in scores.items():
        df[k] = v
    df = df.dropna(subset=["y"]).copy()
    return df, gene_vectors, found


def analyze_survival(name, df, gene_vectors, random_n=100, include_random_null=True):
    base_cov = ["proliferation", "emt", "hypoxia_only", "tgfb_caf_stroma", "immune_infiltration"]
    base = cox_fit(df, base_cov, strata="study" if "study" in df.columns else None)
    plus_osd = cox_fit(df, base_cov + ["osd_residual"], strata="study" if "study" in df.columns else None)
    plus_repair = cox_fit(df, base_cov + ["repair_stress_composite"], strata="study" if "study" in df.columns else None)
    univ = {}
    pvals = {}
    for col in base_cov + ["osd_residual", "repair_stress_composite", "wound_ecm_fibrosis"]:
        fit = cox_fit(df, [col], strata="study" if "study" in df.columns else None)
        univ[col] = fit
        if fit:
            pvals[col] = fit["covariates"][col]["p"]
    for col, fit in univ.items():
        if fit:
            fit["covariates"][col]["fdr_q"] = bh(pvals).get(col)
    strata = "study" if "study" in df.columns else None
    random_osd = None
    random_repair = None
    if include_random_null:
        random_osd = random_signature_survival_null(
            df, gene_vectors, size=12, n=random_n, strata=strata, target_col="osd_residual"
        )
        random_repair = random_signature_survival_null(
            df, gene_vectors, size=12, n=random_n, seed=20260912, strata=strata,
            target_col="repair_stress_composite"
        )
    return {
        "base_comparator_model": base,
        "base_plus_osd_residual": plus_osd,
        "base_plus_repair_stress": plus_repair,
        "incremental_osd_vs_base": lrt(plus_osd, base) if base and plus_osd else None,
        "incremental_repair_vs_base": lrt(plus_repair, base) if base and plus_repair else None,
        "univariable": univ,
        "random_gene_set_survival_null_for_osd": random_osd,
        "random_gene_set_survival_null_for_repair_stress": random_repair,
    }


def analyze_response(name, df, gene_vectors):
    base_cov = ["proliferation", "emt", "hypoxia_only", "tgfb_caf_stroma", "immune_infiltration"]
    base = logistic_fit(df, base_cov)
    plus_osd = logistic_fit(df, base_cov + ["osd_residual"])
    plus_repair = logistic_fit(df, base_cov + ["repair_stress_composite"])
    univ = {}
    for col in base_cov + ["osd_residual", "repair_stress_composite", "wound_ecm_fibrosis"]:
        auc = auc_univariable(df, col)
        if auc is not None:
            univ[col] = {"auc_nonresponse_higher": auc, **bootstrap_auc_ci(df, col)}
    target = univ.get("repair_stress_composite", {}).get("auc_nonresponse_higher")
    rand = random_signature_auc(df, gene_vectors, df["y"].to_numpy(), size=12, n=1000)
    return {
        "base_comparator_model": base,
        "base_plus_osd_residual": plus_osd,
        "base_plus_repair_stress": plus_repair,
        "incremental_osd_vs_base": lrt(plus_osd, base) if base and plus_osd else None,
        "incremental_repair_vs_base": lrt(plus_repair, base) if base and plus_repair else None,
        "univariable_auc": univ,
        "random_gene_set_auc_null": {
            "n": int(len(rand)),
            "signature_size": 12,
            "mean_auc": float(np.mean(rand)),
            "ci95_low": float(np.percentile(rand, 2.5)),
            "ci95_high": float(np.percentile(rand, 97.5)),
            "fraction_random_auc_ge_repair_stress": float(np.mean(rand >= target)) if target is not None and len(rand) else None,
        },
    }


def main():
    RESULTS.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    tcga_df, tcga_genes, tcga_found = tcga_data()
    imv_df, imv_genes, imv_found = imvigor_data()
    gse_df, gse_genes, gse_found = gse78220_data()

    res = {
        "analysis_name": "Locked OSD comparator and negative-control benchmark",
        "guardrail": "This is a retrospective benchmark. Positive incremental performance supports construct validity, but does not prove causality or treatment-specific prediction.",
        "tcga_survival": analyze_survival("tcga", tcga_df, tcga_genes, random_n=100, include_random_null=True),
        "imvigor210_response": analyze_response("imvigor210", imv_df.dropna(subset=["y"]).copy(), imv_genes),
        "imvigor210_survival": analyze_survival("imvigor210", imv_df, imv_genes, include_random_null=False),
        "gse78220_response": analyze_response("gse78220", gse_df, gse_genes),
        "genes_found": {"tcga": tcga_found, "imvigor210": imv_found, "gse78220": gse_found},
        "limitations": [
            "TCGA benchmark uses the locally available selected-gene expression matrix, not a full-transcriptome universe.",
            "IMvigor210 is single-arm; response/survival associations are not treatment-interaction evidence.",
            "GSE78220 is small and should be interpreted as an external signal check rather than a definitive validation.",
        ],
    }
    (RESULTS / "osd_locked_benchmark_controls_results.json").write_text(json.dumps(res, indent=2), encoding="utf-8")

    lines = [
        "# Locked OSD Comparator and Negative-Control Benchmark",
        "",
        "This benchmark tests whether OSD-derived scores add information beyond simpler competing signatures: proliferation, EMT, hypoxia-only, TGF-beta/CAF/stroma and immune-infiltration proxies.",
        "",
        "## Headline",
    ]
    t = res["tcga_survival"]
    imr = res["imvigor210_response"]
    ims = res["imvigor210_survival"]
    gse = res["gse78220_response"]
    def p(x):
        return "NA" if x is None else f"{x:.4g}"
    lines += [
        f"- TCGA survival: adding residual OSD to the comparator model LRT p={p(t['incremental_osd_vs_base']['p'])}; adding repair-stress composite p={p(t['incremental_repair_vs_base']['p'])}.",
        f"- IMvigor210 response: adding residual OSD p={p(imr['incremental_osd_vs_base']['p'])}; adding repair-stress composite p={p(imr['incremental_repair_vs_base']['p'])}.",
        f"- IMvigor210 survival: adding residual OSD p={p(ims['incremental_osd_vs_base']['p'])}; adding repair-stress composite p={p(ims['incremental_repair_vs_base']['p'])}.",
        f"- GSE78220 response: repair-stress AUC={p(gse['univariable_auc'].get('repair_stress_composite',{}).get('auc_nonresponse_higher'))}; random-set fraction >= repair-stress={p(gse['random_gene_set_auc_null']['fraction_random_auc_ge_repair_stress'])}.",
        "",
        "## Interpretation",
        "The benchmark is a construct-validity test, not a clinical treatment claim. OSD is strengthened only where it improves outcome modeling beyond the simpler signatures; otherwise the manuscript should emphasize the repair/stress components rather than a single universal axis.",
        "",
        "## Limitations",
    ] + [f"- {x}" for x in res["limitations"]]
    (REPORTS / "osd_locked_benchmark_controls_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
