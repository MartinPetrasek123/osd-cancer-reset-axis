#!/usr/bin/env python3
import csv
import json
import math
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent

CANDIDATE_GENES = {
    "DDR_checkpoint": ["ATR", "ATM", "CHEK1", "CHEK2", "WEE1", "CLSPN", "TOPBP1", "RAD51", "BRCA1", "BRCA2", "PARP1", "PRKDC"],
    "mitosis_CIN_tolerance": ["BUB1", "BUB1B", "BUB3", "MAD2L1", "AURKA", "AURKB", "PLK1", "TTK", "KIF11", "CENPE", "CDC20"],
    "proteostasis_stress": ["PSMA1", "PSMB5", "PSMC1", "PSMD1", "HSP90AA1", "HSP90AB1", "HSPA5", "HYOU1", "XBP1", "ERN1", "ATF4", "DDIT3"],
    "autophagy_metabolic_stress": ["MTOR", "ULK1", "BECN1", "ATG5", "ATG7", "MAP1LC3B", "SQSTM1", "AMPK"],
    "apoptosis_reset": ["BCL2", "BCL2L1", "MCL1", "BAX", "BAK1", "CASP3", "CASP8", "TP53"],
    "immune_visibility": ["B2M", "HLA-A", "HLA-B", "HLA-C", "TAP1", "TAP2", "NLRC5", "JAK1", "JAK2", "STING1", "TMEM173", "CGAS", "MB21D1"],
}

ALIASES = {
    "AMPK": ["PRKAA1", "PRKAA2"],
    "STING1": ["STING1", "TMEM173"],
    "CGAS": ["CGAS", "MB21D1"],
}


def gene_symbol(header_name):
    return header_name.split(" (", 1)[0]


def load_lineage():
    lineage = {}
    with open(ROOT / "Model.csv", newline="") as f:
        for row in csv.DictReader(f):
            mid = row["ModelID"]
            lin = row.get("OncotreeLineage") or row.get("TissueOrigin") or "Unknown"
            lineage[mid] = lin
    return lineage


def load_mutation_burden():
    burden = {}
    with open(ROOT / "OmicsSomaticMutationsMatrixDamaging.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        for row in reader:
            mid = row[0]
            vals = []
            for x in row[1:]:
                try:
                    vals.append(float(x))
                except Exception:
                    pass
            burden[mid] = float(np.nansum(vals))
    return burden


def find_candidate_columns(header):
    sym_to_idx = {}
    for i, h in enumerate(header[1:], start=1):
        sym_to_idx.setdefault(gene_symbol(h), i)
    wanted = {}
    for group, genes in CANDIDATE_GENES.items():
        for g in genes:
            choices = ALIASES.get(g, [g])
            for c in choices:
                if c in sym_to_idx:
                    wanted.setdefault(group, {})[c] = sym_to_idx[c]
                    break
    return wanted


def rank_norm(x):
    x = np.asarray(x, dtype=float)
    ranks = stats.rankdata(x, method="average")
    u = (ranks - 0.5) / len(ranks)
    return stats.norm.ppf(u)


def lineage_residualize(values, lineage, min_n=12):
    values = np.asarray(values, dtype=float)
    out = np.full(values.shape, np.nan)
    lineage = np.asarray(lineage)
    for lin in sorted(set(lineage)):
        idx = np.where(lineage == lin)[0]
        if len(idx) < min_n:
            continue
        v = values[idx]
        m = np.nanmean(v)
        s = np.nanstd(v)
        if np.isfinite(s) and s > 0:
            out[idx] = (v - m) / s
    return out


def main():
    lineage_map = load_lineage()
    burden_map = load_mutation_burden()

    with open(ROOT / "CRISPRGeneEffect.csv", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        wanted = find_candidate_columns(header)
        flat = sorted({idx for cols in wanted.values() for idx in cols.values()})
        gene_by_idx = {idx: gene_symbol(header[idx]) for idx in flat}
        effects = {}
        for row in reader:
            mid = row[0]
            if mid not in burden_map or mid not in lineage_map:
                continue
            vals = {}
            for idx in flat:
                try:
                    vals[gene_by_idx[idx]] = float(row[idx])
                except Exception:
                    vals[gene_by_idx[idx]] = math.nan
            effects[mid] = vals

    common = sorted(effects)
    mut_burden = np.array([burden_map[m] for m in common], dtype=float)
    lin = np.array([lineage_map[m] for m in common])
    # Higher score means more damaging alterations within that cell-line model.
    burden_z = lineage_residualize(rank_norm(mut_burden), lin)

    gene_results = []
    group_results = []
    for group, cols in wanted.items():
        group_matrix = []
        for gene in sorted(cols):
            dep = np.array([effects[m].get(gene, math.nan) for m in common], dtype=float)
            # DepMap gene effect: more negative means stronger dependency.
            dependency = -dep
            dep_z = lineage_residualize(dependency, lin)
            mask = np.isfinite(burden_z) & np.isfinite(dep_z)
            if mask.sum() < 100:
                continue
            r, p = stats.spearmanr(burden_z[mask], dep_z[mask])
            hi = burden_z >= np.nanmedian(burden_z)
            lo = burden_z < np.nanmedian(burden_z)
            t, tp = stats.ttest_ind(dep_z[hi & np.isfinite(dep_z)], dep_z[lo & np.isfinite(dep_z)], equal_var=False)
            gene_results.append({
                "group": group,
                "gene": gene,
                "n": int(mask.sum()),
                "spearman_r_burden_vs_dependency": float(r),
                "spearman_p": float(p),
                "high_minus_low_dependency_z": float(np.nanmean(dep_z[hi]) - np.nanmean(dep_z[lo])),
                "welch_p": float(tp),
            })
            group_matrix.append(dep_z)
        if group_matrix:
            gdep = np.nanmean(np.vstack(group_matrix), axis=0)
            mask = np.isfinite(burden_z) & np.isfinite(gdep)
            r, p = stats.spearmanr(burden_z[mask], gdep[mask])
            hi = burden_z >= np.nanmedian(burden_z)
            lo = burden_z < np.nanmedian(burden_z)
            t, tp = stats.ttest_ind(gdep[hi & np.isfinite(gdep)], gdep[lo & np.isfinite(gdep)], equal_var=False)
            group_results.append({
                "group": group,
                "genes_found": sorted(cols),
                "n": int(mask.sum()),
                "spearman_r_burden_vs_group_dependency": float(r),
                "spearman_p": float(p),
                "high_minus_low_group_dependency_z": float(np.nanmean(gdep[hi]) - np.nanmean(gdep[lo])),
                "welch_p": float(tp),
            })

    gene_results.sort(key=lambda x: x["spearman_p"])
    group_results.sort(key=lambda x: x["spearman_p"])
    out = {
        "data_source": "DepMap 24Q4 Public Figshare bulk files: Model.csv, OmicsSomaticMutationsMatrixDamaging.csv, CRISPRGeneEffect.csv.",
        "design": "Lineage-residualized test. Genomic damage proxy = within-lineage rank-normalized damaging mutation burden. Dependency = negative CRISPR gene effect.",
        "n_models_with_effects_and_burden": len(common),
        "candidate_groups": CANDIDATE_GENES,
        "group_results": group_results,
        "top_gene_results": gene_results[:40],
    }
    (ROOT / "depmap_resilience_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
