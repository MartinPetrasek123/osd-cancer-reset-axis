# Reproducibility Notes

## What Is Included

This package includes manuscript source, analysis scripts, generated JSON/CSV result summaries, and human-readable reports.

## What Is Not Included

Large raw data files are deliberately excluded. Reasons:

- file size;
- source license restrictions;
- preference for accession-based reproducibility;
- avoiding redistribution of controlled or third-party data.

## Recommended Final Submission Workflow

1. Create a public GitHub repository.
2. Push this package as the first public reproducibility release.
3. Add exact download scripts for each source dataset.
4. Run the workflow from a clean machine or container.
5. Confirm that all manuscript statistics regenerate.
6. Archive the GitHub release on Zenodo.
7. Insert the Zenodo DOI into the manuscript Data and Code Availability section.

## Reporting Standards

The manuscript is framed around:

- REMARK for tumor-marker prognostic studies;
- TRIPOD for prediction models;
- MIQE for qPCR assays;
- ARRIVE 2.0 for animal or PDX work.

## Minimal Audit Checklist

- All manuscript numbers trace to result JSON/CSV files.
- Every figure can be regenerated from scripts or is embedded as TikZ in the manuscript.
- No hidden manual threshold tuning after outcome inspection.
- Public data sources are identified by accession, source repository, or portal.
- Environment versions are pinned before DOI release.
