#!/usr/bin/env bash
set -euo pipefail

echo "OSD reproducibility scaffold"
echo "This script is a submission scaffold. Add dataset download steps before final Zenodo DOI release."
echo
echo "Available scripts:"
find scripts -maxdepth 1 -type f -name '*.py' | sort
echo
echo "Available result summaries:"
find results -maxdepth 1 -type f | sort
