# Klinické ukotvení osy organismické stability

Datum: 2026-09-10

## Cíl

Ukotvit hypotézu “resetu organismické stability” mimo pouhou teorii.

Testovaná otázka:

**Souvisí vyšší zaseknutí organismu v režimu alarm/stres/hojení se skutečným klinickým výsledkem, tedy s přežitím pacientů?**

## Data

Použité zdroje:

- UCSC Xena Toil TCGA/TARGET/GTEx exprese pro vybrané organism-reset geny
- cBioPortal TCGA PanCancer Atlas klinická data

Výběr:

- TCGA primární nádory
- pacienti s dostupným overall survival

Celkem:

- spárované TCGA primární nádory: 8 893
- úmrtí / OS events: 2 619
- pro Cox model použito: 8 726 vzorků
- použité cancer-type strata: 29

## Testovaná osa

Organism Stability Disruption:

> instability load - order capacity

Instability load:

- inflammatory alarm
- interferon alarm
- wound/ECM/fibrosis
- coagulation/complement
- hypoxia/redox stress
- proteostasis/ER stress

Order capacity:

- bioelectric/junction order
- polarity/adhesion order
- circadian order
- mitochondrial homeostasis
- differentiation order

Tvrdší verze:

> Organism Stability Disruption Residual = osa stability po odečtení proliferace uvnitř každého typu rakoviny

## Hlavní výsledek

Stratifikovaný Cox model podle typu rakoviny:

### Raw organism stability disruption

- HR na 1 SD = 1.179
- z = 5.811
- p = 6.22e-09

### Residual po odečtení proliferace

- HR na 1 SD = 1.110
- z = 5.253
- p = 1.50e-07

To znamená:

**Vyšší zaseknutí organismické stability souvisí s horším přežitím i po odečtení prosté proliferace.**

## Srovnání modulů

Proliferace:

- HR = 1.317
- p = 3.65e-17

Hypoxia/redox stress:

- HR = 1.270
- p = 3.88e-15

Instability load:

- HR = 1.245
- p = 7.61e-14

Proteostasis/ER stress:

- HR = 1.151
- p = 7.14e-08

Interferon alarm:

- HR = 1.025
- p = 0.274

Circadian order:

- HR = 0.967
- p = 0.173

## Význam

Nejsilnější klinicky ukotvené složky nejsou “jeden gen”.

Jsou to:

- proliferace,
- hypoxie/redox stres,
- proteostatická/ER stresová adaptace,
- celková instability load,
- reziduální organismická porucha po odečtení proliferace.

## Per-cancer signál

Nejsilnější pozitivní signál residual osy:

- KIRC: HR = 1.685, p = 2.30e-11
- LGG: HR = 1.497, p = 5.79e-06
- KIRP: HR = 1.991, p = 7.79e-05
- PAAD: HR = 1.334, p = 7.44e-03
- HNSC: HR = 1.170, p = 2.39e-02

Opačný signál:

- OV: HR = 0.856, p = 1.46e-02

To znamená:

Obecná osa existuje, ale její klinická interpretace závisí na orgánovém kontextu.

## Ukotvený vzorec

Nejpřesnější formulace:

> Rakovina je patologicky stabilizovaný stav, ve kterém organismus nedokončí přechod z alarmu/hojení/stresu zpět do homeostázy. Čím více tento stav přetrvává nad rámec samotné proliferace, tím horší je u části nádorů klinický výsledek.

## Co je “reset”

Reset by neměl být chápán jako jeden zásah nebo jedna látka.

Reset znamená měřitelný posun systému:

1. snížení hypoxia/redox stresu,
2. snížení proteostasis/ER stresové závislosti,
3. ukončení falešného hojivě-fibrotického programu,
4. návrat cirkadiánního a metabolického řádu,
5. obnovení imunitní a tkáňové čitelnosti,
6. pokles residual stability-disruption score.

## Klinický význam

Tento test neříká, jak léčit pacienta.

Ale říká, že hypotéza stability má klinický otisk:

**není to jen metafora.**

Osa stability:

- odlišuje nádory od normálních tkání,
- částečně přežívá odečtení proliferace,
- souvisí s přežitím pacientů v TCGA.

## Další nejtvrdší test

Potřebujeme longitudinální data:

- před léčbou,
- během léčby,
- po léčbě,
- při remisi nebo relapsu.

Skutečný reset by měl být definován takto:

> Pacient / nádor se posune z vysoké organism stability disruption osy směrem k normálnímu homeostatickému pásmu a tento posun predikuje delší remisi.

To je testovatelná definice resetu.

