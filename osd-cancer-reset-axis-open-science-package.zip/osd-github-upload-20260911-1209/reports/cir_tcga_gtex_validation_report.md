# CIR validace na TCGA/GTEx

Datum: 2026-09-10

## Cíl

Otestovat tvrdší hypotézu:

**Cancer Irreversibility Residual, CIR = zbytková rakovinová autonomie po odečtení běžné proliferace.**

Tedy neptáme se jen, zda nádor roste. Ptáme se, zda po odečtení růstu zůstává signál narušené tkáňové kompatibility / stability.

## Data

Zdroj: UCSC Xena Toil recompute TCGA/TARGET/GTEx RNA-seq.

Výběr:

- TCGA primární nádory
- GTEx normální tkáně
- pouze tkáně s alespoň 20 nádory a 20 normály

Celkem:

- vzorky: 8 790
- nádory: 5 688
- normály: 3 102
- tkáňové kontexty: 13

Tkáňové kontexty:

- Brain
- Breast
- Colon
- Esophagus
- Liver
- Lung
- Ovary
- Pancreas
- Prostate
- Skin
- Stomach
- Testis
- Uterus

## Metoda

Předem dané moduly:

- proliferation
- stress_flow
- polyamine_flow
- tissue_governance
- polarity_adhesion
- junction_bioelectric
- immune_visibility

Raw autonomy:

> stress_flow + polyamine_flow - tissue_governance - polarity_adhesion - junction_bioelectric - immune_visibility

CIR:

> raw_autonomy residualizovaná proti proliferation

Každá tkáň byla vyhodnocena samostatně: nádor vs normál.

## Výsledky

### Proliferace

Proliferace odlišila nádor od normálu ve všech 13/13 tkáních.

- medián tumor-minus-normal = 1.424
- pozitivní směr: 13/13
- medián AUC = 0.980
- FDR < 0.05 pozitivně: 13/13

To je očekávané a není to nový klíč.

### Raw autonomie

Raw autonomie nebyla univerzální.

- medián tumor-minus-normal = -0.134
- pozitivní směr: 4/13
- negativní směr: 9/13
- medián AUC = 0.451

Bez odečtení proliferace není kompozit spolehlivý.

### CIR

CIR po odečtení proliferace ukázal silnější, ale stále ne univerzální signál.

- medián tumor-minus-normal = 1.439
- pozitivní směr: 9/13
- negativní směr: 4/13
- medián AUC = 0.767
- FDR < 0.05 pozitivně: 8/13
- FDR < 0.05 negativně: 3/13

Silně pozitivní CIR:

- Uterus: delta 4.483, AUC 0.994
- Lung: delta 2.672, AUC 0.928
- Prostate: delta 2.561, AUC 0.902
- Skin: delta 2.540, AUC 0.959
- Colon: delta 1.611, AUC 0.876
- Ovary: delta 1.468, AUC 0.767
- Breast: delta 1.439, AUC 0.784
- Testis: delta 0.651, AUC 0.641

Slabé/neutrální:

- Liver: delta 0.348, AUC 0.543
- Esophagus: delta -0.001, AUC 0.508

Opačný režim:

- Stomach: delta -0.750, AUC 0.368
- Brain: delta -1.020, AUC 0.243
- Pancreas: delta -3.217, AUC 0.050

## Závěr

CIR není univerzální klíč ke všem rakovinám.

Ale CIR není mrtvá hypotéza. Test ukázal, že po odečtení proliferace zůstává silný rakovinový reziduální režim v části nádorových tkání.

Nejdůležitější závěr:

**Rakovina pravděpodobně nemá jeden globální “restartovací klíč”. Má více stabilních patologických režimů. CIR zachycuje jeden z nich, silný hlavně u dělohy, plic, prostaty, kůže, tlustého střeva, vaječníku a prsu.**

U mozku, slinivky a žaludku je signál opačný. To může znamenat:

- jiný biologický režim autonomie,
- nevhodné normální kontrolní tkáně z GTEx,
- rozdíl mezi bulk RNA a skutečnou prostorovou hranicí,
- nebo chybu ve formulaci modulu pro tyto nádory.

## Další test

Další krok by neměl hledat jednu léčbu pro všechny nádory.

Měl by rozdělit rakoviny na stabilitní režimy:

1. CIR-high režim
2. CIR-neutral režim
3. CIR-inverted režim

Potom testovat, zda každý režim má vlastní zranitelnost v DepMap/PRISM:

- CIR-high: ztráta tkáňové kompatibility + stresový tok
- CIR-inverted: jiný typ autonomie, možná nízkoimunitní/metabolický/lineage-locked režim
- CIR-neutral: závislost na klasické proliferaci bez silného reziduálního signálu

Praktický závěr:

**Máme testovat “léčbu podle režimu stability”, ne jednu univerzální látku.**

