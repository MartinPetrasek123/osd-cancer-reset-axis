# Remaining OSD Validation Layers

## Single-cell compartmentation
Dataset: GSE165897 HGSOC single-cell RNA-seq; cells: 51786; patients: 11; cell types: 3.
Top cell types by mean single-cell OSD:
- Stromal: n=8045, mean OSD=0.423, wound/ECM=0.921, hypoxia/redox=0.473
- Immune: n=34935, mean OSD=0.028, wound/ECM=-0.147, hypoxia/redox=-0.150
- EOC: n=8806, mean OSD=-0.497, wound/ECM=-0.257, hypoxia/redox=0.162

## TCGA module-label permutation
Target residual OSD: p=0.0014, HR=1.084, C-index=0.530.
Permutations: n=200; fraction with p <= target=0.380; fraction with C-index >= target=0.225.

## Multisample spatial summary
Tumor sections: 5; controls: 1.
- malignant_pressure: 5/5 tumor sections with negative gradient; median r=-0.383; control r=-0.371.
- tissue_governance: 5/5 tumor sections with negative gradient; median r=-0.218; control r=-0.107.
- polarity_adhesion: 5/5 tumor sections with negative gradient; median r=-0.347; control r=-0.156.
- junction_bioelectric: 5/5 tumor sections with negative gradient; median r=-0.245; control r=-0.080.
- proteostasis_flow: 5/5 tumor sections with negative gradient; median r=-0.385; control r=-0.218.
- autonomy_composite: 4/5 tumor sections with negative gradient; median r=-0.005; control r=-0.153.
- autonomy_residual_after_malignant_pressure: 2/5 tumor sections with negative gradient; median r=0.091; control r=0.003.
