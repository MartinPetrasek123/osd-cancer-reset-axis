# Hledání resetu: pan-cancer páky stability

Datum: 2026-09-11

## Otázka

Hledali jsme praktický začátek resetu:

**Které zásahy jsou zranitelností buněk s vysokou organismickou poruchou stability, po odečtení proliferace a typu nádoru?**

## Data

Použité zdroje:

- DepMap 24Q4 expression
- DepMap 24Q4 CRISPR gene effect
- PRISM Repurposing drug screen

Výběr:

- nádorové buněčné linie s dostatečně velkým lineage zastoupením
- score residualizováno uvnitř lineage proti proliferaci
- drug/gene sensitivity centrována uvnitř lineage

Celkem:

- modelů s expresí: 1 545
- CRISPR genů testováno: 17 787
- PRISM perturbací testováno: 4 686

## Výsledek CRISPR

Po FDR korekci se objevila řada genů, jejichž knockout více poškozuje buňky s vysokou poruchou stability.

Nejsilnější:

- RELA, NF-kB osa: r = -0.226, q = 3.43e-10
- ZFP36L1: r = -0.208, q = 1.17e-08
- MYH9: r = -0.206, q = 1.47e-08
- TLN1: r = -0.201, q = 3.19e-08
- JUN, AP-1 osa: r = -0.200, q = 3.19e-08
- UFM1: r = -0.197, q = 5.74e-08
- PKN2: r = -0.194, q = 1.02e-07
- PTPN1: r = -0.189, q = 2.34e-07
- FERMT2: r = -0.183, q = 6.22e-07
- WWTR1/TAZ: r = -0.169, q = 5.41e-06

Interpretace:

Vysoká porucha stability není citlivá na jeden klasický onkogen.

Je citlivější na uzly:

- NF-kB / AP-1 alarm,
- mechanotransdukce a adheze,
- Hippo/TAZ/YAP-like řízení,
- proteotoxická/stresová adaptace,
- fosfatázové/metabolické ladění.

## Výsledek PRISM

Po FDR korekci se objevily lékové třídy, které více inhibují high-OSD buňky.

Nejsilnější:

- NMS-E973, HSP inhibitor: r = -0.203, q = 5.48e-03
- LY2606368, CHK1 inhibitor: r = -0.194, q = 1.29e-02
- BRD4770, EHMT2/histone methyltransferase inhibitor: r = -0.194, q = 1.29e-02
- AZD7762, CHK1/CHK2 inhibitor: r = -0.186, q = 2.35e-02
- alvespimycin, HSP90 inhibitor: r = -0.171, q = 3.46e-02
- SNX-5422, HSP90 inhibitor: r = -0.169, q = 3.46e-02
- NVP-AUY922, HSP90 inhibitor: r = -0.168, q = 3.93e-02
- rubitecan/topotecan, TOP1 inhibitors: q ~ 0.04–0.08
- AS-703026, MEK inhibitor: q = 0.076
- dacinostat, HDAC inhibitor: q = 0.092

MOA enrichment mezi nominálními PRISM stopami:

- HSP inhibitors: 10 výskytů
- CHK inhibitors: 2
- topoisomerase inhibitors: 2
- PI3K inhibitors: 2
- CDK inhibitors: 2

## Vzorec

Data ukazují:

**Reset nebude jedna páka. Reset musí zasáhnout stavovou architekturu, která drží patologickou stabilitu.**

Nejpravděpodobnější společné páky:

1. **Control/alarm gate**
   - RELA / NF-kB
   - JUN / AP-1

2. **Stress tolerance gate**
   - HSP90 / HSP
   - proteostasis / ER stress

3. **Damage checkpoint gate**
   - CHK1/CHK2
   - TOP1/topoisomerase

4. **Mechanical identity gate**
   - TLN1
   - MYH9
   - FERMT2
   - WWTR1/TAZ

5. **Epigenetic state gate**
   - EHMT2
   - HDAC-like modulace

## Resetovací model

Pracovní model:

> Patologická stabilita rakoviny je držena smyčkou alarm → stresová tolerance → mechanická identita → checkpoint přežití → epigenetická fixace.

Proto reset není “vypnout nádor”.

Reset znamená:

> rozpojit stabilizační smyčku tak, aby se buňka/tkáň nemohla vrátit do patologického atraktoru.

## Praktická implikace

Kandidátní resetová strategie by nebyla jedna látka, ale sekvence:

1. aktivovat/obnovit kontrolu,
2. snížit proliferaci,
3. zasáhnout stresovou toleranci,
4. narušit mechanicko-adhezní patologickou identitu,
5. zabránit epigenetickému návratu do starého stavu,
6. měřit návrat řádu v čase.

## Bezpečnostní hranice

Toto není léčebné doporučení.

Mnoho nalezených tříd, například HSP, CHK, TOP1 nebo HDAC inhibitory, může být toxických a klinicky složitých.

Výsledek znamená:

**máme kandidátní biologické páky pro laboratorní ověření resetu, ne hotovou terapii.**

## Další experiment

Nejbližší laboratorně testovatelný experiment:

Vzít organoidy nebo buněčné linie s high-OSD stavem a porovnat:

- standardní cytotoxický zásah,
- HSP/CHK/MEK/epigenetický zásah,
- sekvenční kombinaci,
- a měřit ne jen přežití buněk, ale trajektorii resetu:
  - proliferace dolů,
  - proteostasis/ER stress dolů,
  - hypoxia/redox dolů,
  - NF-kB/AP-1 alarm normalizace,
  - circadian/order moduly nahoru,
  - návrat mimo patologický atraktor.

