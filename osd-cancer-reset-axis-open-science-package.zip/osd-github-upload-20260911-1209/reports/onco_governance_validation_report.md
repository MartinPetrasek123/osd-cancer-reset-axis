# Validace hypotézy: nádor jako porucha tkáňové stability

Datum: 2026-09-10

## Otázka

Testovali jsme, zda se v prostorových transcriptomických datech opakuje hranice mezi:

- nádorovým/proliferačním tlakem,
- buněčným stresovým tokem,
- tkáňovou regulací,
- polaritou/adhezí,
- junkční/bioelektrickou koordinací,
- imunitní viditelností.

Pracovní hypotéza: rakovina není jen součet mutací, ale stabilizovaný autonomní režim, který narušuje vazbu buňky na tkáňový řád.

## Data

Použité veřejné datasety 10x Genomics Visium/CytAssist:

- V1_Breast_Cancer_Block_A_Section_1
- V1_Breast_Cancer_Block_A_Section_2
- Visium_FFPE_Human_Breast_Cancer
- Visium_FFPE_Human_Prostate_Cancer
- CytAssist_FFPE_Human_Breast_Cancer
- V1_Human_Lymph_Node jako negativní technická kontrola

Celkem:

- nádorové vzorky: 5
- nádorové prostorové body: 19 666
- všechny analyzované body včetně kontroly: 23 701

## Metoda

Ve všech vzorcích bylo použito stejné pravidlo:

1. Spočítat fixní genové moduly.
2. Označit top kvartil clusterů podle malignant_pressure jako tumor-like oblast.
3. Spočítat vzdálenost směrem ven od této oblasti.
4. Testovat, zda moduly tvoří opakovatelný prostorový gradient.
5. Poté odečíst malignant_pressure a znovu otestovat zbytkovou autonomii.

## Hlavní výsledky v nádorových vzorcích

Robustní napříč 5/5 nádorovými vzorky:

- malignant_pressure: medián Spearman r = -0.383
- proteostasis_flow: medián r = -0.385
- tissue_governance: medián r = -0.218
- polarity_adhesion: medián r = -0.347
- junction_bioelectric: medián r = -0.245
- polyamine_flow: medián r = -0.113

Kompozitní autonomie:

- stejný směr ve 4/5 nádorových vzorcích
- medián core-to-outside rozdílu = -1.148
- kombinovaná Stouffer p-hodnota = 8.86e-41

Po odečtení malignant_pressure:

- směr už není konzistentní
- 2/5 negativní, 3/5 pozitivní
- medián core-to-outside rozdílu = -0.108

## Negativní kontrola

Lymfatická uzlina vytvořila podobný falešný signál v základním kompozitním skóre:

- autonomy_composite r = -0.153
- core-to-outside rozdíl = -4.837

Po odečtení malignant_pressure však prostorová korelace prakticky zmizela:

- residual autonomy r = 0.003

## Závěr

Validace podporuje existenci silného prostorového režimu růst/stres/tkáňová organizace.

Nepodporuje zatím tvrzení, že máme univerzální čistě rakovinový klíč nebo léčbu všech rakovin.

Nejdůležitější zjištění:

**Původní signatura zachycuje obecný stav proliferující a reorganizující se tkáně. To je biologicky zásadní, ale není to samo o sobě specifické pro rakovinu.**

Silnější hypotéza pro další krok:

**Rakovinový klíč nebude pouhá proliferace, ale stav, kde proliferace/stres pokračuje při současném selhání návratu do tkáňové kompatibility.**

## Další tvrdý test

Další validace musí použít:

- patologicky anotované tumor/normal/boundary masky,
- více typů nádorů,
- scRNA nebo spatial deconvolution pro oddělení nádorových, stromálních a imunitních buněk,
- odečtení běžné regenerace/proliferace,
- test, zda reziduální autonomie predikuje invazi, relaps nebo rezistenci na léčbu.

Pracovní název další metriky:

**Cancer Irreversibility Residual, CIR**

Definice:

> CIR = pokračující růstový/stresový režim po odečtení normální proliferace a regenerace, při současném poklesu návratu k tkáňové kompatibilitě.

