# Reset není stav: první longitudinální experimenty

Datum: 2026-09-11

## Cíl

Otestovat přímo hypotézu:

**Úspěšná léčba rakoviny není jen zmenšení nádoru, ale posun systému po trajektorii zpět ke stabilitě.**

Nechtěli jsme další statický nádor-vs-normál test.

Testovali jsme skutečné změny v čase:

- před léčbou,
- během léčby,
- po léčbě.

## Experiment 1: melanoma anti-PD-1, GSE91061

Dataset:

- GSE91061 / Riaz et al.
- melanoma anti-PD-1 / nivolumab
- 109 RNA-seq vzorků
- 43 použitelných párových pacientů Pre → On

Odpovědi:

- PRCR: 9
- SD: 15
- PD: 18

### Výsledek

U pacientů s klinickou kontrolou, tedy PRCR+SD:

- proliferace klesá oproti PD: p = 0.00918
- interferon/alarm roste: median change = +0.200, p = 0.0269
- celková organism_stability_disruption roste víc než u PD: p = 0.036

U PRCR responderů:

- proteostasis/ER stress klesá: median change = -0.303, p = 0.0195

### Interpretace

Anti-PD-1 neukazuje okamžité ztišení systému.

Ukazuje:

**reaktivaci kontroly.**

To znamená, že během účinné imunoterapie může alarm dočasně stoupnout, protože systém znovu rozpoznává a napadá patologický stav.

## Experiment 2: ovariální karcinom po chemoterapii, GSE165897

Dataset:

- GSE165897 / longitudinal scRNA-seq HGSOC
- high-grade serous ovarian cancer
- treatment-naive vs post-NACT
- analyzovány pouze EOC malignant tumor cells

Vzorek:

- EOC nádorové buňky: 8 806
- párovaní pacienti: 11

### Výsledek v EOC nádorových buňkách

Post-NACT vs treatment-naive:

- proliferace klesá: median change = -0.271, p = 0.00977
- interferon_alarm klesá: median change = -0.269, p = 0.0137
- circadian_order roste: median change = +0.116, p = 0.00293
- celková organism_stability_disruption nemá jednotný posun: p = 0.465

### Interpretace

Chemoterapie v nádorových buňkách ukazuje jinou fázi než imunoterapie:

- přímý pokles proliferace,
- pokles interferonového/alarm signálu v nádorových buňkách,
- růst cirkadiánního/časového řádu,
- bez jednotného celkového resetu napříč pacienty.

To může znamenat:

**chemoterapie potlačí růstovou složku, ale sama nemusí dokončit systémový reset.**

## Společný vzorec

Tyto dva experimenty společně ukazují:

**Reset není jedno číslo a není jeden okamžik. Reset je trajektorie.**

### Fáze A: Reaktivace kontroly

Typicky vidět u imunoterapie.

- imunitní/interferonový alarm může stoupnout,
- organism_stability_disruption může dočasně stoupnout,
- proliferace začíná klesat u klinické kontroly.

### Fáze B: Kolaps růstového programu

Vidět u imunoterapie i chemoterapie.

- proliferace klesá,
- nádor ztrácí růstovou dynamiku.

### Fáze C: Pokles stresové závislosti

Vidět částečně u PRCR responderů v GSE91061.

- proteostasis/ER stress klesá,
- nádor ztrácí schopnost držet patologický stresový stav.

### Fáze D: Obnova řádu

Vidět částečně v GSE165897.

- circadian_order roste,
- systém se může přibližovat k časové organizaci.

### Fáze E: Skutečný homeostatický reset

Zatím přímo nedokázáno.

Potřebujeme data:

- pre-treatment,
- early on-treatment,
- post-treatment/remise,
- relapse.

Predikce:

V remisi by mělo nastat:

- proliferace nízko,
- proteostasis/ER stress nízko,
- hypoxia/redox nízko,
- chronický alarm nízko,
- circadian/order moduly obnovené,
- organism_stability_disruption blízko normálnímu pásmu.

Před relapsem by se osa měla znovu zvedat nebo změnit směrem k patologické stabilizaci.

## Nejdůležitější závěr

Jednoduchá hypotéza:

> léčba = okamžitý pokles celkové poruchy stability

je špatně.

Silnější hypotéza:

> léčba = průchod několika fázemi resetu, kde se nejdřív aktivuje kontrola, potom klesá růst a stresová tolerance, a teprve později se může obnovit homeostáza

je slučitelná se dvěma nezávislými longitudinálními datasety.

## Formální vzorec

Navržený model:

> Reset(t) = ControlActivation(t) - TumorGrowth(t) - StressTolerance(t) + OrderRecovery(t)

Kde:

- ControlActivation = interferon/immune activation
- TumorGrowth = proliferation
- StressTolerance = proteostasis/ER stress + hypoxia/redox
- OrderRecovery = circadian + mitochondrial + polarity/bioelectric order

Klíč:

**nesmí se měřit jen absolutní stav; musí se měřit směr změny v čase.**

## Co dál

Další experiment musí být vybrán tak, aby měl minimálně 3 časové body:

1. pre-treatment,
2. on-treatment,
3. remission nebo relapse.

Tam už lze testovat tvrdou predikci:

**úspěšný reset není jen odpověď na léčbu; je to dokončený návrat stability.**

