# LINCS/CMap reversal test: hledání resetovacích perturbací

Datum: 2026-09-11

## Cíl

Ověřit kvalitněji, zda existují perturbace, které **obracejí pan-cancer signaturu organismické poruchy stability**.

Tedy ne pouze:

> která látka zabíjí nádorové buňky?

Ale:

> která perturbace posouvá transcriptomický stav opačným směrem než patologická osa alarm/stres/falešné hojení/ztráta řádu?

## Data

Použité zdroje:

- UCSC Xena Toil TCGA/GTEx
- L1000CDS2 / LINCS L1000 characteristic direction signatures
- DepMap/PRISM jako nezávislý překryv citlivosti

## Konstrukce signatury

Z TCGA/GTEx jsme vytvořili pan-cancer tumor-vs-normal genovou signaturu.

Pravidlo:

- 13 tkáňových kontextů
- vyloučeny proliferation geny
- `up_genes`: gen zvýšený v nádorech alespoň v 9/13 tkáních
- `down_genes`: gen snížený v nádorech alespoň v 9/13 tkáních
- potom dotaz do L1000CDS2 v reverse módu

Výsledná signatura:

- up genes: 56
- down genes: 24

## LINCS reverse výsledky

Použili jsme dvě nezávislé varianty dotazu:

1. gene-set reverse query
2. weighted cosine/CD reverse query

Mechanismy, které se opakovaly v obou dotazech:

- MEK inhibition:
  - PD-0325901
  - AZD-8330

- PI3K/mTOR axis:
  - NVP-BEZ235
  - torin-2
  - MK-2206

- mechanická/adhezní osa:
  - Rho kinase inhibitor III / rockout

- epigenetická osa:
  - PFI-1
  - JQ1-like BET inhibition

- HSP/proteostasis:
  - tanespimycin
  - NVP-AUY922

Poznámka:

LINCS vracel také položku `-666`; tu neinterpretujeme biologicky, protože nejde o jasně pojmenovaný perturbagen.

## Překryv s PRISM

Nejdůležitější nezávislý překryv:

- NVP-AUY922:
  - LINCS reverse hit
  - PRISM high-OSD sensitive hit
  - MOA: HSP inhibitor
  - PRISM q = 0.039

- tanespimycin:
  - LINCS reverse hit
  - PRISM high-OSD sensitive nominal/near hit
  - MOA: HSP inhibitor
  - PRISM q = 0.141

To je velmi důležité:

**HSP90/proteostasis není jen citlivostní korelace. Objevuje se i jako transcriptomický reversal kandidát.**

## Konvergence s předchozím DepMap/PRISM testem

Předchozí high-OSD vulnerability test ukázal:

- HSP inhibitors
- CHK inhibitors
- TOP1/topoisomerase inhibitors
- MEK/RTK signály
- HDAC/EHMT2 epigenetické zásahy
- RELA/JUN/NF-kB/AP-1
- TLN1/MYH9/FERMT2 mechanická identita
- WWTR1/TAZ

LINCS reversal přidal nezávisle:

- MEK
- PI3K/mTOR
- ROCK/mechanika
- BET/epigenetika
- HSP90/proteostasis

Společný vzorec:

> resetovací kandidáti se shlukují kolem stresové tolerance, mechanické identity, růstově-signálního přepínače a epigenetické fixace.

## Nejlépe ukotvený kandidát

Nejlépe datově ukotvená osa teď je:

**HSP90 / proteostasis stress tolerance**

Proč:

1. Proteostasis/ER stress je zvýšený pan-cancer v TCGA/GTEx.
2. Proteostasis/ER stress predikuje horší přežití v TCGA.
3. High-OSD buňky jsou citlivější na HSP inhibitory v PRISM.
4. HSP90 inhibitory obracejí OSD signaturu v LINCS.
5. U PRCR responderů v GSE91061 klesá proteostasis/ER stress během léčby.

To je zatím nejsilnější konvergentní důkaz.

## Resetovací vzorec po LINCS testu

Aktualizovaný vzorec:

> patologická stabilita = alarm/signaling + proteostasis tolerance + mechanická identita + epigenetická paměť

Resetovací páky:

1. HSP90/proteostasis gate
2. MEK/RTK growth-signal gate
3. PI3K/mTOR metabolic-growth gate
4. ROCK/YAP/TAZ/mechanical identity gate
5. BET/HDAC/EHMT2 epigenetic memory gate

## Klinická opatrnost

Toto není léčebné doporučení.

HSP90, MEK, PI3K/mTOR, CHK, TOP1, HDAC a podobné zásahy mohou být toxické a klinicky složité.

Výsledek znamená:

**máme kandidátní laboratorní resetové osy, ne hotovou terapii.**

## Kvalitnější další ověření

Nejlepší další ověření by bylo:

1. Vzít organoidy nebo PDX modely s vysokým OSD.
2. Změřit baseline OSD.
3. Aplikovat nízkodávkově/sekvenčně:
   - HSP90/proteostasis perturbaci,
   - MEK nebo PI3K/mTOR perturbaci,
   - mechanickou/ROCK perturbaci,
   - epigenetickou perturbaci.
4. Měřit ne jen smrt buněk, ale trajektorii:
   - proliferace dolů,
   - proteostasis/ER stress dolů,
   - hypoxia/redox dolů,
   - patologický alarm normalizovaný,
   - circadian/order moduly nahoru,
   - návrat mimo high-OSD atraktor.

## Hlavní závěr

Ano, dá se to ověřit kvalitněji na datech.

LINCS reversal test ukázal, že naše patologická stabilitní signatura není izolovaná konstrukce.

Nezávislé perturbace, které ji obracejí, spadají do biologicky smysluplných os:

**HSP90/proteostasis, MEK, PI3K/mTOR, ROCK/mechanika a epigenetická paměť.**

Nejsilnější první kandidát pro laboratorní resetový experiment:

**proteostasis/HSP90 gate jako centrální páka stresové tolerance patologického atraktoru.**

