# Locked OSD Comparator and Negative-Control Benchmark

This benchmark tests whether OSD-derived scores add information beyond simpler competing signatures: proliferation, EMT, hypoxia-only, TGF-beta/CAF/stroma and immune-infiltration proxies.

## Headline
- TCGA survival: adding residual OSD to the comparator model LRT p=2.921e-14; adding repair-stress composite p=0.2069.
- IMvigor210 response: adding residual OSD p=0.5287; adding repair-stress composite p=0.7366.
- IMvigor210 survival: adding residual OSD p=0.2367; adding repair-stress composite p=0.3661.
- GSE78220 response: repair-stress AUC=0.6905; random-set fraction >= repair-stress=0.064.

## Interpretation
The benchmark is a construct-validity test, not a clinical treatment claim. OSD is strengthened only where it improves outcome modeling beyond the simpler signatures; otherwise the manuscript should emphasize the repair/stress components rather than a single universal axis.

## Limitations
- TCGA benchmark uses the locally available selected-gene expression matrix, not a full-transcriptome universe.
- IMvigor210 is single-arm; response/survival associations are not treatment-interaction evidence.
- GSE78220 is small and should be interpreted as an external signal check rather than a definitive validation.
