# Kompletní test: breast CIR a hledání vzorce

Datum: 2026-09-10

## Otázka

Vybrali jsme rakovinu prsu a testovali jsme, zda se z CIR dá najít konkrétní vzorec:

- subtypový,
- stabilitně-režimový,
- geneticky zranitelný,
- lékově zranitelný.

## Data

Použité lokální zdroje:

- DepMap 24Q4 model metadata
- DepMap 24Q4 expression
- DepMap 24Q4 CRISPR gene effect
- PRISM Repurposing drug screen

Po vyřazení non-cancer breast linií:

- breast cancer linií s expresí: 69
- CRISPR překryv: 50
- PRISM překryv: 26

Subtypy:

- TNBC/basal: 34
- HER2: 23
- ER/luminal: 9
- other/unknown: 3

## Definice CIR

Raw autonomy:

> stress_flow + polyamine_flow - tissue_governance - polarity_adhesion - junction_bioelectric - immune_visibility

CIR:

> raw_autonomy po odečtení proliferation

Praktický význam:

**CIR má zachytit zbytkovou autonomii po odstranění prostého růstu.**

## Subtypový vzorec

### ER/luminal

- n = 9
- CIR = 1.229
- immune_visibility = -0.399
- tissue_governance = -0.251

Interpretace:

ER/luminal část vypadá jako CIR-high režim: nízká imunitní viditelnost, slabší tkáňová regulace, autonomie není vysvětlená pouze proliferací.

### HER2

- n = 23
- CIR = 0.715
- stress_flow = 0.210
- immune_visibility = -0.257

Interpretace:

HER2 část je také spíše CIR-high, ale s větší stresovou složkou.

### TNBC/basal

- n = 34
- CIR = -0.849
- immune_visibility = 0.303
- tissue_governance = 0.110
- polarity_adhesion = 0.059

Interpretace:

TNBC/basal není CIR-high. Vypadá jako jiný režim: imunitně viditelnější, tkáňově/stromálně aktivnější, méně “tichá autonomie”.

## Stabilitní režimy

Datově vyšly 3 režimy:

### Regime 0

- n = 5
- vysoký CIR
- nízká immune_visibility
- nízká junction_bioelectric
- složení: hlavně TNBC/basal, ale velmi malé n

Interpretace:

Malý extrémní CIR-high/immune-low ostrov. Zatím příliš malý pro závěr.

### Regime 1

- n = 27
- vysoká immune_visibility
- vysoká tissue_governance
- vysoká polarity_adhesion
- složení: hlavně TNBC/basal

Interpretace:

Tkáňově aktivní / imunitně viditelný basal-TNBC režim.

### Regime 2

- n = 37
- vysoký CIR
- mírně vyšší proliferation
- mírně vyšší stress_flow
- složení: hlavně HER2 a ER/luminal

Interpretace:

CIR-high luminal/HER2-like režim.

## CRISPR test

Po korekci přes všechny testované geny:

**žádný CRISPR zásah nebyl potvrzen při FDR < 0.10.**

Nejsilnější nominální směry v celém breast souboru:

- IGF1R: r = -0.54, q = 0.46
- PELI1: r = -0.53, q = 0.46
- SYNE1: r = -0.51, q = 0.46
- DENND4A: r = -0.48, q = 0.47
- PNMA3: r = -0.48, q = 0.47

TNBC nominální směry:

- CARS1: r = -0.70, q = 0.16
- GIMAP4: r = -0.70, q = 0.16
- GOLM1: r = -0.67, q = 0.20
- LIN9: r = -0.67, q = 0.20

Interpretace:

CRISPR zatím nepotvrdil robustní jeden genový klíč.

## PRISM lékový test

V celém breast souboru:

**žádný lék nebyl potvrzen při FDR < 0.25.**

V TNBC/basal podskupině se objevila slabší, ale zajímavá PRISM stopa:

- TAS-103, topoisomerase inhibitor: r = -0.83, q = 0.23
- 7-methoxytacrine: r = -0.83, q = 0.23
- 3-alpha-bis-(4-fluorophenyl)-methoxytropane: r = -0.81, q = 0.23
- tivozanib, VEGFR inhibitor: r = -0.81, q = 0.23
- CYT-997, tubulin polymerization inhibitor: r = -0.80, q = 0.23

Interpretace:

To není potvrzená léčba. Je to slabý screenový signál v malém PRISM překryvu.

## Vzorec

Nejlepší vzorec, který testy podporují:

> Breast cancer = nejméně dva stabilitní režimy, ne jedna nemoc.

### Režim A: CIR-high / immune-low / governance-low

Typicky:

- ER/luminal
- HER2

Možný význam:

- nádor se stabilizuje jako tichá autonomní identita,
- méně imunitní viditelnosti,
- méně tkáňového korektivního signálu,
- zranitelnost nemusí být v jednom esenciálním genu, ale v regulačním stavu.

### Režim B: CIR-low / immune-high / governance-active

Typicky:

- TNBC/basal

Možný význam:

- nádor není tichý autonomní ostrov,
- je více zánětlivý/stromálně aktivní,
- může být zranitelnější na stres DNA/topoisomerázu, mikrotubuly, angiogenní/RTK signály,
- ale zatím jen slabě a v malém PRISM překryvu.

## Hlavní závěr

**Smysl se objevuje, ale ne jako “jeden lék”.**

Vzorec je:

**nejdřív určit stabilitní režim, teprve potom hledat resetovací zásah.**

Pro rakovinu prsu to zatím vypadá takto:

> CIR-high prsa nejsou primárně “více proliferující”; jsou spíš imunitně tišší a tkáňově méně korigovaná. TNBC/basal je naopak odlišný, imunitně/stromálně aktivnější režim.

## Co tím padá

Padá hypotéza:

> Jeden CIR score okamžitě odhalí jeden univerzální lék.

## Co zůstává

Zůstává silnější hypotéza:

> Rakovina má společný princip poruchy stability, ale léčebný zásah musí odpovídat konkrétnímu stabilitnímu režimu.

## Další test

Další nejlepší test:

1. Vzít větší breast cohort se subtypy ER/HER2/TNBC.
2. Spočítat CIR a spatial/bulk stabilitní režimy.
3. Přidat klinickou odpověď na léčbu.
4. Testovat, zda CIR-high predikuje odpověď na hormonální/RTK/epigenetické zásahy a zda TNBC režim predikuje odpověď na DNA-stress/tubulin/RTK kombinace.

To už by nebylo jen hledání korelací, ale test prediktivního vzorce.

