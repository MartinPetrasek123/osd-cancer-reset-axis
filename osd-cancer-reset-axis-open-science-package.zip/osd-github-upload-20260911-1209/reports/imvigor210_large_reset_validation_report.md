# IMvigor210 Large Reset-Axis Validation

## Question
Does the pre-specified organism stability / reset axis predict real immunotherapy outcome in a substantially larger clinical cohort?

## Dataset
- IMvigor210CoreBiologies `cds.RData`, metastatic urothelial carcinoma treated with atezolizumab.
- Samples: 348.
- Genes: 31286.
- Best overall response counts: {'PD': 167, 'SD': 63, 'NE': 50, 'PR': 43, 'CR': 25}.
- Binary response counts: {'SD/PD': 230, 'CR/PR': 68, nan: 50}.

## Primary Response Test
Positive delta means the score is higher in SD/PD non-responders than CR/PR responders.
- osd_raw: delta -0.403, AUC nonresponder-higher 0.455, p=0.2611, q=0.359.
- osd_residual_vs_proliferation: delta -0.327, AUC nonresponder-higher 0.481, p=0.6371, q=0.6371.
- instability_load: delta 0.475, AUC nonresponder-higher 0.540, p=0.321, q=0.3923.
- order_capacity: delta 1.096, AUC nonresponder-higher 0.631, p=0.0009979, q=0.005489.
- wound_ecm_fibrosis: delta 0.244, AUC nonresponder-higher 0.575, p=0.05883, q=0.1294.
- proteostasis_er_stress: delta -0.011, AUC nonresponder-higher 0.451, p=0.2231, q=0.3506.
- hypoxia_redox_stress: delta 0.083, AUC nonresponder-higher 0.576, p=0.0584, q=0.1294.
- interferon_alarm: delta -0.281, AUC nonresponder-higher 0.393, p=0.007595, q=0.02785.
- circadian_order: delta 0.036, AUC nonresponder-higher 0.559, p=0.1416, q=0.2597.
- mitochondrial_homeostasis: delta 0.084, AUC nonresponder-higher 0.528, p=0.4904, q=0.5395.
- proliferation: delta -0.561, AUC nonresponder-higher 0.337, p=4.305e-05, q=0.0004736.

## Overall Survival
Hazard ratios are per 1 SD higher score. Adjusted models include TMB, enrollment PD-L1 immune-cell level, and ECOG.
- osd_raw: unadjusted HR 1.013, p=0.8382; adjusted HR 1.160, p=0.03836.
- osd_residual_vs_proliferation: unadjusted HR 1.032, p=0.6237; adjusted HR 1.178, p=0.02197.
- wound_ecm_fibrosis: unadjusted HR 1.100, p=0.1393; adjusted HR 1.142, p=0.03537.
- proteostasis_er_stress: unadjusted HR 1.054, p=0.411; adjusted HR 1.109, p=0.1238.
- hypoxia_redox_stress: unadjusted HR 1.173, p=0.01674; adjusted HR 1.196, p=0.008604.
- proliferation: unadjusted HR 0.901, p=0.09806; adjusted HR 0.926, p=0.2417.

## Clinical-Covariate Check
AIC compares logistic non-response models. Lower AIC is better; this checks whether the score adds signal beyond TMB, PD-L1 IC level, and ECOG.
- osd_raw: clinical AIC 309.81; clinical+score AIC 311.80; score p=0.9622.
- osd_residual_vs_proliferation: clinical AIC 309.81; clinical+score AIC 311.50; score p=0.5777.
- wound_ecm_fibrosis: clinical AIC 309.81; clinical+score AIC 307.18; score p=0.03369.
- proteostasis_er_stress: clinical AIC 309.81; clinical+score AIC 311.02; score p=0.3754.
- hypoxia_redox_stress: clinical AIC 309.81; clinical+score AIC 309.02; score p=0.09987.
- proliferation: clinical AIC 309.81; clinical+score AIC 299.76; score p=0.0008478.

## Interpretation
This is a much stronger validation layer than the small melanoma cohort because it uses hundreds of clinical trial samples and known covariates.

The result should be interpreted as a biomarker/stability-state test, not as evidence for a treatment. A lab-replicable next step is to select high-score vs low-score tumor models from this axis and test whether perturbations move the full trajectory rather than merely kill cells.
