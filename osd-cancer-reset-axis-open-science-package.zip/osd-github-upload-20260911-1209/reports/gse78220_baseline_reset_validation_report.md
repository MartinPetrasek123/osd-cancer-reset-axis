# GSE78220 Independent Baseline Reset Validation

## Question
Does the same organism-stability / reset-axis signature, without retuning genes to this cohort, mark real anti-PD-1 resistance in pretreatment melanoma biopsies?

## Dataset
- Source: GSE78220 / Hugo et al., pretreatment melanoma biopsies treated with pembrolizumab.
- Baseline biopsies analyzed: 27.
- Patients after averaging duplicate baseline biopsies: 26.
- Response groups: {'progressor': 12, 'responder': 14}.

## Primary Result
- osd_raw: progressor median 1.834, responder median -0.063, delta 1.896, AUC progressor-higher 0.649, permutation p=0.4038.
- osd_residual_vs_proliferation: progressor median 2.179, responder median 0.181, delta 1.998, AUC progressor-higher 0.673, permutation p=0.4188.
- wound_ecm_fibrosis: progressor median 0.358, responder median -0.369, delta 0.727, AUC progressor-higher 0.762, permutation p=0.0204.
- proteostasis_er_stress: progressor median 0.014, responder median -0.155, delta 0.169, AUC progressor-higher 0.613, permutation p=0.1748.
- hypoxia_redox_stress: progressor median 0.056, responder median -0.117, delta 0.172, AUC progressor-higher 0.589, permutation p=0.2415.
- proliferation: progressor median 0.426, responder median -0.004, delta 0.430, AUC progressor-higher 0.661, permutation p=0.1722.

## Survival Anchor
- osd_raw: Spearman score vs OS days rho=-0.137, permutation p=0.5173; median OS high-score 387 days vs low-score 578 days, delta -190 days, permutation p=0.2567.
- osd_residual_vs_proliferation: Spearman score vs OS days rho=-0.201, permutation p=0.3322; median OS high-score 387 days vs low-score 578 days, delta -190 days, permutation p=0.2567.
- wound_ecm_fibrosis: Spearman score vs OS days rho=-0.123, permutation p=0.5575; median OS high-score 548 days vs low-score 439 days, delta 109 days, permutation p=0.5081.
- proteostasis_er_stress: Spearman score vs OS days rho=-0.098, permutation p=0.6387; median OS high-score 387 days vs low-score 578 days, delta -190 days, permutation p=0.2665.
- proliferation: Spearman score vs OS days rho=-0.376, permutation p=0.06629; median OS high-score 427 days vs low-score 656 days, delta -228 days, permutation p=0.1689.

## Interpretation
The result is partially supportive, not decisive. The full OSD score is higher in progressive disease than in responders, including after residualizing against proliferation, but the small cohort does not make that omnibus score statistically secure.

The strongest replicated component is wound/ECM/fibrosis: it is clearly higher in progressive disease. That matters because it is one of the proposed organism-level stability-failure modules and matches the published biology of this cohort, where innate anti-PD-1 resistance was linked to mesenchymal, adhesion, ECM, wound-healing, and angiogenesis programs.

Survival trends are weak in this small cohort. Proliferation shows the clearest adverse survival trend, while OSD and wound/ECM point in the expected direction but are not independently strong.

So this is not a proof of a treatment. It is a real-patient anchor showing that the reset hypothesis should probably focus on a measurable tissue-repair/pathological-healing axis, then ask whether perturbing proteostasis/mechanics/epigenetic fixation can move that state.

A strong finding here would be especially useful for attracting labs because it connects the theory to baseline clinical response, not only cell lines.
