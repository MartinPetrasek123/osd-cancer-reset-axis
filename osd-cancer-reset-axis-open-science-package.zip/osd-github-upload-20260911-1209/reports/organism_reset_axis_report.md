# Organism Reset Axis: pan-cancer test

Datum: 2026-09-10

## Výchozí myšlenka

Korekce směru:

Nejde primárně o typ rakoviny ani o jeden nádorový gen.

Jde o otázku:

**Existuje společný stav narušení celistvé organismické stability, který se objevuje napříč nádory?**

Analogie k míše:

Po úrazu míchy nejde jen o opravu jednoho spoje. Systém se musí vrátit do stabilního funkčního režimu.

U rakoviny může být podobný princip:

**organismus zůstane zaseknutý v patologickém režimu růst / alarm / hojení / stres a nedokáže provést návrat do stabilní tkáňové kompatibility.**

## Data

Zdroj:

- UCSC Xena Toil TCGA/TARGET/GTEx RNA-seq
- TCGA primární nádory
- GTEx normální tkáně

Výběr:

- pouze tkáně s alespoň 20 nádory a 20 normály

Celkem:

- vzorky: 8 790
- nádory: 5 688
- normály: 3 102
- tkáňové kontexty: 13

Tkáňové kontexty:

- Brain
- Breast
- Colon
- Esophagus
- Liver
- Lung
- Ovary
- Pancreas
- Prostate
- Skin
- Stomach
- Testis
- Uterus

## Testované moduly

Instability load:

- inflammatory_alarm
- interferon_alarm
- wound_ecm_fibrosis
- coagulation_complement
- hypoxia_redox_stress
- proteostasis_er_stress

Order capacity:

- bioelectric_junction_order
- polarity_adhesion_order
- circadian_order
- mitochondrial_homeostasis
- differentiation_order

Výsledná osa:

> organism_stability_disruption_raw = instability_load - order_capacity

Tvrdší osa:

> organism_stability_disruption_residual = raw osa po odečtení proliferation

## Hlavní výsledky

### Raw organism stability disruption

Silný pan-cancer signál:

- medián tumor-minus-normal = 2.098
- pozitivní směr: 11/13 tkání
- negativní směr: 2/13
- medián AUC = 0.780
- FDR < 0.05 pozitivně: 11/13

To znamená:

**nádory obecně nesou vyšší zátěž alarm/stres/hojení vůči řádovým modulům.**

### Po odečtení proliferace

Signál zeslábl, ale nezmizel:

- medián tumor-minus-normal = 0.199
- pozitivní směr: 9/13 tkání
- negativní směr: 4/13
- medián AUC = 0.553
- FDR < 0.05 pozitivně: 7/13
- FDR < 0.05 negativně: 2/13

Interpretace:

Velká část společného signálu je spojená s růstem. Ale část stabilitní poruchy zůstává i po odečtení proliferace.

## Nejrobustnější společné moduly

### Proliferation

- pozitivní ve 13/13 tkáních
- medián AUC = 0.980

To je očekávané a samo o sobě není resetovací klíč.

### Interferon alarm

- pozitivní ve 13/13 tkáních
- medián AUC = 0.852

Silný společný prvek:

**organismus / tkáň vnímá nádor jako chronický alarmový stav.**

### Proteostasis / ER stress

- pozitivní ve 13/13 tkáních
- medián AUC = 0.802

Silný společný prvek:

**nádorový stav je stabilizován zvýšenou tolerancí stresu a proteostatickou adaptací.**

### Hypoxia / redox stress

- pozitivní v 11/13 tkáních
- medián AUC = 0.836

Silný společný prvek:

**tkáň je v režimu nedostatku, oxidativního stresu a kompenzace.**

### Circadian order

- negativní v 11/13 tkáních
- medián AUC = 0.136

Velmi důležitý prvek:

**nádorový stav je spojený se ztrátou rytmického časového řádu.**

To je jeden z nejsilnějších kandidátů pro “reset” na úrovni organismu.

## Co je překvapivé

Bioelectric/junction order vyšel vyšší ve 12/13 nádorech.

To znamená:

Není pravda, že rakovina jednoduše “ztratí všechny vazby”.

Spíš:

**rakovina si vytváří vlastní patologický řád.**

To je zásadní rozdíl.

Nejde jen o chaos. Jde o chybnou stabilitu.

## Vzorec

Nejlepší formulace vzorce:

> Rakovina = stabilizovaný patologický režim, kde organismus zůstává uvězněn mezi růstem, chronickým alarmem, hojením, hypoxií, proteostatickou adaptací a ztrátou časového řádu.

Jinak řečeno:

**organismus se nepřepne z alarmu zpět do stabilní homeostázy.**

## Resetovací hypotéza

Reset by neměl znamenat “zabít nádor jedním jedem”.

Reset by měl znamenat:

1. ukončit chronický alarm,
2. obnovit časový/cirkadiánní řád,
3. snížit toleranci patologického stresu,
4. přerušit falešný hojivě-fibrotický program,
5. vrátit buňky do čitelnosti pro imunitní a tkáňovou kontrolu,
6. obnovit kompatibilní bioelektrické a mechanické hranice.

## Klíčový závěr

Tento test podporuje tvou hlavní intuici lépe než předchozí breast-only test.

**Společný základ napříč rakovinami existuje, ale nevypadá jako jeden gen nebo jeden lék. Vypadá jako zaseknutý organismický program: růst + alarm + stres + falešné hojení + ztráta rytmu.**

Nejsilnější kandidát na obecný “resetovací prvek” z tohoto testu:

**obnova časového/cirkadiánního řádu spolu s ukončením chronického alarm-stress programu.**

## Omezení

Toto není důkaz léčby.

Toto není klinický protokol.

GTEx normály nejsou pacientsky párované normální tkáně.

Bulk RNA-seq míchá nádorové, stromální, imunitní a normální buňky.

Ale jako test společné organismické osy je výsledek silnější než hledání jednoho breast léku.

## Další test

Další krok:

Vzít nádory s klinickým přežitím / odpovědí na léčbu a testovat:

> kdo má vysoký organism_stability_disruption_residual, má horší návrat do stability, horší odpověď nebo vyšší relaps?

Pokud ano, máme metriku “zaseknutí systému”.

