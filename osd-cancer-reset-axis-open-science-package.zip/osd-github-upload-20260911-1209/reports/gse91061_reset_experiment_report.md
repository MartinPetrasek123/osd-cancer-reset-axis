# Reset experiment: GSE91061 melanoma anti-PD-1

Datum: 2026-09-10

## Cíl

Otestovat přímo experimentální předpověď:

**Pokud léčba vrací organismus/nádor do stabilnějšího režimu, měla by se osa organismické stability změnit mezi pre-treatment a on-treatment biopsií.**

Použitý dataset:

- GSE91061 / Riaz et al.
- melanoma anti-PD-1 / nivolumab
- 109 RNA-seq vzorků
- 51 pre-treatment
- 58 on-treatment
- použitelné páry Pre/On: 43 pacientů

Odpovědi:

- PRCR: 9
- SD: 15
- PD: 18
- UNK: 1

## Test

Pro každého pacienta:

> change = On-treatment score - Pre-treatment score

Testované moduly:

- organism_stability_disruption
- instability_load
- order_capacity
- interferon_alarm
- hypoxia_redox_stress
- proteostasis_er_stress
- wound_ecm_fibrosis
- circadian_order
- proliferation

Původní jednoduchá predikce:

> Respondéři by měli mít pokles organism_stability_disruption.

## Výsledek

### Celková organism stability disruption

Respondéři PRCR:

- n = 9
- median change = +1.113
- p vs 0 = 0.496

Stable disease SD:

- n = 15
- median change = +1.686
- p vs 0 = 0.018

Progressive disease PD:

- n = 18
- median change = -0.268
- p vs 0 = 0.609

PRCR+SD vs PD:

- median difference = +1.393
- p = 0.036

## Interpretace

Jednoduchá představa byla špatně:

**Úspěšná/on-treatment fáze anti-PD-1 nevypadá jako okamžité ztišení alarmu.**

Naopak:

**u pacientů s klinickou kontrolou se během léčby osa organism_stability_disruption zvyšuje více než u progresorů.**

To pravděpodobně znamená, že on-treatment biopsie zachycuje aktivní imunitní zásah, ne finální homeostatický reset.

## Důležité dílčí výsledky

### Proliferace

PRCR+SD:

- median change = -0.270
- p vs 0 = 0.0249

PD:

- median change = +0.163

PRCR+SD vs PD:

- p = 0.00918

Interpretace:

**u klinicky kontrolovaných pacientů proliferace klesá, u progresorů neklesá.**

To je silná a biologicky správná kotva.

### Proteostasis / ER stress

PRCR:

- median change = -0.303
- p vs 0 = 0.0195

PD:

- median change = +0.0067

Interpretace:

**u skutečných responderů klesá stresová/proteostatická závislost nádoru.**

To je kandidát na jednu z komponent resetu.

### Interferon alarm

PRCR+SD:

- median change = +0.200
- p vs 0 = 0.0269

PD:

- median change = +0.062

Interpretace:

Anti-PD-1 zvyšuje imunitní/interferonový signál hlavně u klinicky kontrolovaných pacientů.

To není “selhání resetu”; je to pravděpodobně přechodová fáze.

## Nový vzorec

Experiment říká, že reset není jednokrokový:

### Fáze 1: Reaktivace kontroly

- imunitní/interferonový alarm stoupá,
- celková disruption osa může dočasně stoupnout,
- nádor je napaden systémovou kontrolou.

### Fáze 2: Kolaps nádorové proliferace

- proliferace klesá,
- růstový režim slábne.

### Fáze 3: Snížení stresové závislosti

- proteostasis/ER stress klesá,
- nádor ztrácí schopnost tolerovat patologický stav.

### Fáze 4: Skutečný homeostatický reset

Tuto fázi dataset GSE91061 pravděpodobně nezachycuje, protože on-treatment biopsie je příliš brzy.

Skutečný reset by se měl testovat až:

- po léčbě,
- v remisi,
- při dlouhodobé kontrole,
- nebo před relapsem.

## Hlavní závěr

Tento experiment nezabil hypotézu resetu.

Ale zabil její příliš jednoduchou verzi.

Správnější formulace:

> Reset organismické stability není okamžité ztišení všech alarmů. Je to dynamická sekvence: nejprve se reaktivuje kontrolní alarm, potom klesá proliferace a stresová tolerance, a teprve následně se systém může vrátit do stabilní homeostázy.

## Nejtvrdší zjištění

V reálných párových biopsiích anti-PD-1:

- klinická kontrola má větší změnu organism_stability_disruption než progrese,
- proliferace klesá u klinické kontroly a neklesá u progrese,
- proteostasis/ER stress klesá u PRCR responderů.

To znamená:

**reset musíme měřit jako trajektorii, ne jako jedno číslo.**

## Další experiment

Potřebujeme dataset se třemi časy:

1. před léčbou,
2. během léčby,
3. remise / relaps.

Predikce:

- během účinné léčby může alarm stoupnout,
- proliferace a proteostasis musí klesnout,
- v remisi musí klesnout i celková organism_stability_disruption,
- před relapsem se disruption znovu zvýší.

To je přesná, testovatelná definice resetu.

