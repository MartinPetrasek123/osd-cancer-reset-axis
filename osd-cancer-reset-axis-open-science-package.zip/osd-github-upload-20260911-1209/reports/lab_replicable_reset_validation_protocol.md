# Replication-ready protocol: Cancer Stability Reset

Datum: 2026-09-11

## Jednověté tvrzení

Rakovina není pouze nekontrolovaný růst, ale patologicky stabilizovaný stav, ve kterém buňky/tkáň zůstávají zaseknuté v režimu alarmu, stresové tolerance, mechanické identity a epigenetické paměti; úspěšný reset musí tento stav měřitelně posunout zpět směrem k homeostatickému řádu.

## Proč to stojí za zopakování

Hypotéza se opírá o čtyři nezávislé datové vrstvy:

1. TCGA/GTEx tumor-vs-normal:
   - organism stability disruption je zvýšený v 11/13 tkáních.
   - po odečtení proliferace zůstává pozitivní v 9/13 tkáních.

2. TCGA survival:
   - residual stability disruption predikuje horší přežití.
   - HR = 1.110 na 1 SD.
   - p = 1.50e-07.
   - bootstrap 95% CI HR = 1.074 až 1.157.
   - permutační p = 0.001996.

3. Longitudinální léčebná data:
   - GSE91061 anti-PD-1 melanoma: klinická kontrola ukazuje pokles proliferace a u PRCR také pokles proteostasis/ER stress.
   - GSE165897 ovariální scRNA post-NACT: malignant EOC buňky ukazují pokles proliferace a růst circadian/order složky.

4. Perturbační data:
   - DepMap/PRISM high-OSD citlivost ukazuje hlavně HSP/proteostasis, CHK, TOP1, MEK/RTK, HDAC/EHMT2.
   - LINCS reversal ukazuje HSP90/proteostasis, MEK, PI3K/mTOR, ROCK/mechanika, BET/epigenetika.
   - nejsilnější konvergence: HSP90/proteostasis gate.

## Hlavní testovatelná hypotéza

High-OSD nádorové modely nejsou pouze více proliferující. Jsou závislé na stresové toleranci a stavové stabilizaci.

Pokud zasáhneme správnou resetovou páku, nemá se měřit jen buněčná smrt.

Má se měřit trajektorie:

```text
 ControlActivation
- TumorGrowth
- StressTolerance
+ OrderRecovery
```

## Minimální laboratorní experiment

### Modely

Vybrat alespoň 8 až 12 nádorových modelů:

- 4 až 6 high-OSD modelů
- 4 až 6 low-OSD kontrolních modelů

Preferované modely:

- pacientské organoidy,
- PDX-derived organoidy,
- nebo buněčné linie s dostupnou RNA-seq baseline.

Nejlepší první nádory:

- ledvina/KIRC,
- gliom/LGG,
- pankreas/PAAD,
- head and neck/HNSC,
- případně melanoma kvůli GSE91061 návaznosti.

### Baseline měření

Před zásahem změřit:

- RNA-seq nebo targeted expression panel,
- proliferace,
- proteostasis/ER stress,
- hypoxia/redox,
- NF-kB/AP-1 alarm,
- circadian/order,
- mitochondrial/order,
- polarity/bioelectric/order.

### Primární index

```text
OSD =
  inflammatory_alarm
+ interferon_alarm
+ wound_ecm_fibrosis
+ coagulation_complement
+ hypoxia_redox_stress
+ proteostasis_er_stress
- bioelectric_junction_order
- polarity_adhesion_order
- circadian_order
- mitochondrial_homeostasis
- differentiation_order
```

Tvrdší verze:

```text
OSD_residual = OSD po odečtení proliferation
```

### Zásahy k testování

Ne jako klinická doporučení, pouze in-vitro/in-organoid screening:

1. HSP90/proteostasis gate:
   - NVP-AUY922-like,
   - tanespimycin-like,
   - jiný bezpečně dostupný laboratorní HSP90 perturbagen.

2. MEK/RTK gate:
   - PD-0325901-like,
   - AZD-8330-like.

3. PI3K/mTOR gate:
   - BEZ235-like,
   - torin-2-like.

4. ROCK/mechanical gate:
   - rockout / ROCK inhibition-like.

5. Epigenetic memory gate:
   - BET/JQ1-like,
   - HDAC/EHMT2-like.

### Design

Každý model:

- vehicle control,
- single perturbation,
- sekvenční kombinace:
  - den 0: kontrolní/standardní cytotoxický nebo relevantní léčebný tlak,
  - den 1-2: HSP90/proteostasis perturbace,
  - den 2-4: MEK/PI3K nebo ROCK/epigenetická perturbace podle modelu,
  - den 4-7: recovery bez léčiva.

Časové body:

- T0 baseline,
- T1 24 h,
- T2 72 h,
- T3 7 dní recovery,
- T4 re-challenge / relapse test, pokud model přežije.

## Primární endpoint

Experiment podporuje hypotézu, pokud high-OSD modely po resetové perturbaci ukážou:

1. pokles proliferation,
2. pokles proteostasis/ER stress,
3. pokles hypoxia/redox stress,
4. pokles nebo normalizaci NF-kB/AP-1 alarmu,
5. růst circadian/order nebo mitochondrial/order složky,
6. pokles OSD_residual po recovery,
7. nižší schopnost návratu do high-OSD stavu po re-challenge.

Nejdůležitější není okamžitá cytotoxicita.

Nejdůležitější je:

```text
failure_to_return_to_pathological_attractor
```

## Kritérium potvrzení

Silné potvrzení:

- high-OSD modely mají větší reset trajectory shift než low-OSD modely,
- efekt se replikuje alespoň ve 2 nezávislých laboratořích,
- efekt není vysvětlen pouze poklesem viability,
- po recovery zůstává OSD_residual nižší,
- re-challenge nevrátí model snadno do high-OSD atraktoru.

Slabé potvrzení:

- pokles proliferation a proteostasis bez obnovy order modulů.

Nepotvrzení:

- perturbace jen zabíjí buňky, ale nepřesouvá transcriptomický stav,
- nebo OSD_residual po recovery zůstává stejný/vyšší,
- nebo low-OSD modely reagují stejně jako high-OSD.

## Minimální qPCR/panelová verze

Pokud laboratoř nechce hned RNA-seq, lze začít menším panelem.

Proliferation:

- MKI67
- TOP2A
- PCNA
- MCM2

Proteostasis/ER stress:

- HSPA5
- XBP1
- HSP90AA1
- DDIT3

Hypoxia/redox:

- HIF1A
- VEGFA
- SLC2A1
- NQO1

Alarm/signaling:

- RELA
- JUN
- FOSL1
- STAT1

Order recovery:

- ARNTL
- PER1
- CRY1
- PPARGC1A
- SIRT3
- GJA1
- CDH1

Mechanical identity:

- TLN1
- MYH9
- WWTR1
- VCL

## Krátký pitch pro laboratoř

Navrhujeme testovat rakovinu jako patologicky stabilizovaný atraktor, nikoli pouze jako proliferující masu. Ve veřejných pan-cancer datech je osa organismické stability zvýšená v nádorech, predikuje přežití po odečtení proliferace a její perturbace konvergují v LINCS/PRISM zejména na HSP90/proteostasis, MEK/PI3K, ROCK/mechaniku a epigenetickou paměť. Laboratorní validace nevyžaduje novou léčbu pacientů: stačí organoidový nebo buněčný model, časová řada po perturbaci a měření, zda high-OSD stav ztrácí schopnost návratu do patologického atraktoru.

## Bezpečnostní hranice

Tento protokol není léčebné doporučení.

Je určen pro:

- in-vitro experiment,
- organoidový experiment,
- PDX-derived model,
- retrospektivní datovou validaci.

Není určen k samostatnému klinickému použití u pacienta.

